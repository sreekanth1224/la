﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using itextSharpText = iTextSharp.text;
using System.Text.RegularExpressions;
using iTextSharp.text;
using System.Net;

namespace Medicaid_AdminReviewMerge
{
    public class ARMerge : SPJobDefinition
    {
        public ARMerge() : base() { }

        public ARMerge(SPWebApplication webApp)
            : base("ARTimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "ARTimerJob";
        }

        public ARMerge(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public ARMerge(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            ARMergeDocs();
        }

        public void ARMergeDocs()
        {
            List<String> lstFiles = new List<String>();
            String fileName = String.Empty;
            String fileScanPath = String.Empty;
            String fileScanMergeDocPath = String.Empty;
            string fileScanAddDocPath = string.Empty;
            String fileUrl = String.Empty;
            String siteUrl = String.Empty;
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["syssupport"];
            siteUrl = currentWeb.Site.Url + "/syssupport";
            //Scan Merge Doc List
            SPList ARGridMergeLib = currentWeb.Lists["AR Merge Doc"];
            //Scan OPR List
            SPList ARGridLib = currentWeb.Lists["AR Grid"];
            SPList ARGridList = currentWeb.Lists["AR Grid List"];
            Uri ARGRidLibFolder = new Uri(siteUrl + "/" + ARGridLib.RootFolder);
            Uri ARGRidMergeLibFolder = new Uri(siteUrl + "/" + ARGridMergeLib.RootFolder);

            foreach (SPFile file in ARGridMergeLib.RootFolder.Files)
            {
                fileUrl = file.Url;
                fileName = fileUrl.Remove(0, (fileUrl.IndexOf('/') + 1));
                fileScanPath = siteUrl + "/" + ARGridMergeLib.RootFolder + "/" + fileName;
                fileScanMergeDocPath = siteUrl + "/" + ARGridLib.RootFolder + "/" + fileName;
                fileScanAddDocPath = siteUrl + "/" + ARGridLib.RootFolder;

                Boolean IsfileExists = currentWeb.GetFile(siteUrl + "/" + ARGridLib.RootFolder + "/" + fileName).Exists;
                if (IsfileExists)
                {
                    lstFiles.Add(fileScanMergeDocPath);
                    lstFiles.Add(fileScanPath);
                    //Method to merge file fetched from AR Merge & AR Merge Doc Document Libraries
                    ARMergeDocuments(lstFiles, fileName, siteUrl);
                }
                else if (IsRecordAvailable(currentWeb, fileName))
                {
                    Uri srcUrl = new Uri(fileScanPath);
                    //SPFolder dstFolder = currentWeb.GetFolder(ARGRidLibFolder.AbsolutePath);
                    SPFile srcFile = currentWeb.GetFile(srcUrl.AbsolutePath);
                    //srcFile.MoveTo(fileScanAddDocPath);
                    srcFile.MoveTo(ARGRidLibFolder.AbsolutePath + "/" + fileName, true);
                    //dstFolder.Files.Add(ARGRidLibFolder.AbsolutePath, srcFile.OpenBinary());
                }
                //update property document updated with scanned docs
                //UpdateARScanDocProp(siteUrl, fileName);
            }
        }

        public static void ARMergeDocuments(List<String> lstFiles, String fileName, String siteUrl)
        {
            PdfReader reader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage;
            string outputPdfPath = @"C:/AdminReviews/" + fileName; //AdminReviews Folder
            sourceDocument = new Document();
            pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));

            //Open the output file
            sourceDocument.Open();

            try
            {
                //Loop through the files list
                int pages = 0;
                foreach (String file in lstFiles)
                {
                    pages = get_pageCcount(file, siteUrl);
                    reader = new PdfReader(file);
                    //Add pages of current file
                    for (int i = 1; i <= pages; i++)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                lstFiles.Clear();
                //At the end save the output file
                pdfCopyProvider.Dispose();
                sourceDocument.Close();
                //OverWrite merged document back to Scan OPR Document Library
                SaveARMergedDocument(fileName, siteUrl);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static void SaveARMergedDocument(String fileName, String siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanARLib = currentWeb.Lists["AR Grid"];
                    String outputPdfPath = @"C:/AdminReviews/" + fileName;
                    Byte[] fileArrayMerge = File.ReadAllBytes(outputPdfPath);
                    SPFile file = currentWeb.Files.Add(scanARLib.RootFolder + "/" + fileName, fileArrayMerge, true);
                    file.Update();
                    scanARLib.Update();

                    ////Delete file from Merge Document Library
                    DeleteFileFromARMergeDocLib(siteUrl, fileName);
                }
            }
        }

        public static void DeleteFileFromARMergeDocLib(String siteUrl, String fileName)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPFile file = currentWeb.GetFile(siteUrl + "/AR Merge Doc/" + fileName);
                    file.Delete();
                }
            }

            //Delete file from Merge Document Library
            String networkFolderPath = @"C:/AdminReviews";
            String[] files = Directory.GetFiles(networkFolderPath);
            foreach (String filePath in files)
            {
                if (filePath.Contains(fileName))
                {
                    File.Delete(filePath);
                }
            }
        }

        public static Boolean IsRecordAvailable(SPWeb currentWeb, String ARID)
        {
            ARID = ARID.Substring(0, ARID.LastIndexOf('.'));
            SPList ARGridList = currentWeb.Lists["AR Grid List"];
            SPQuery query = new SPQuery();
            String strQuery = "";
            strQuery = "<Where>" +
                        "<Or>" +
                           "<Eq>" +
                                "<FieldRef Name='Title'/>" +
                                 "<Value Type='Text'>" + ARID + "</Value>" +
                            "</Eq>" +
                            "<Eq>" +
                                "<FieldRef Name='ARVersion'/>" +
                                 "<Value Type='Text'>" + ARID + "</Value>" +
                            "</Eq>" +
                         "</Or>" +
                       "</Where>";
            query.Query = strQuery;
            SPListItemCollection CRLcoll = ARGridList.GetItems(query);
            return CRLcoll.Count > 0 ? true : false;
        }

        //public static void UpdateARScanDocProp(String siteUrl, String fileName)
        //{
        //    using (SPSite site = new SPSite(siteUrl)) //dev Site - C
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            SPList ARLibrary = currentWeb.Lists["AR Grid"];
        //            SPFolder folder = currentWeb.Folders["AdminReviews"];
        //            SPFile file = folder.Files[fileName];
        //            file.Item.Properties["fileUpdated"] = true;
        //            file.Update();
        //        }
        //    }
        //}

        private static int get_pageCcount(string fileUrl, String siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site - C
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPFile file = web.GetFile(fileUrl);

                    using (StreamReader sr = new StreamReader(file.OpenBinaryStream()))
                    {
                        Regex regex = new Regex(@"/Type\s*/Page[^s]");
                        MatchCollection matches = regex.Matches(sr.ReadToEnd());

                        return matches.Count;
                    }
                }
            }
        }

        //private static int get_pageCcount(string fileUrl, SPWeb currentWeb)
        //{
        //    Stream fileStream = null;
        //    //SPList HPEList = web.Lists["HPE"];
        //    if (fileUrl.Contains("FiscalAgent/director"))
        //    {
        //        SPFile file = currentWeb.GetFile(fileUrl);
        //        fileStream = file.OpenBinaryStream();
        //    }
        //    else
        //    {
        //        fileStream = File.OpenRead(fileUrl);
        //    }

        //    using (StreamReader sr = new StreamReader(fileStream))
        //    {
        //        Regex regex = new Regex(@"/Type\s*/Page[^s]");
        //        MatchCollection matches = regex.Matches(sr.ReadToEnd());

        //        return matches.Count;
        //    }
        //    //    }
        //    //}
        //}
    }
}
