﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Medicaid_ARService.Controllers
{
    public class ProviderController : ApiController
    {
        SqlDataReader dr;
        List<String> providerList = new List<String>();
        string strConn = ConfigurationManager.ConnectionStrings["connString"].ConnectionString;
        public List<String> Get(String providerName)
        {
            using(SqlConnection con = new SqlConnection(strConn))
            {
                using(SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        cmd.CommandText = "GetProviderList";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@providerName", providerName);
                        if (cmd.Connection.State == ConnectionState.Closed)
                        {
                            con.Open();
                        }
                        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                providerList.Add(dr["NPI-PROVIDER"].ToString());
                            }
                        }
                    }
                    catch(Exception ex)
                    {
                        throw ex;
                    }
                }
            }
            return providerList;
        }
    }
}
