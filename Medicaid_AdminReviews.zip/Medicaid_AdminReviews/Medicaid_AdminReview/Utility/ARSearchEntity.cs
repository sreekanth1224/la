﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_AdminReview.Utility
{
    [Serializable()]
    public class ARSearchEntity
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string ARNumber { get; set; }
        public string ARVersion { get; set; }
        public string CRLID { get; set; }
        public string ProviderID { get; set; }
        public string Recipient { get; set; }
        public DateTime DateIn { get; set; }
        public string AssignedTo { get; set; }
        public DateTime DateCompleted { get; set; }
        public DateTime DOSFrom { get; set; }
        public DateTime DOSTo { get; set; }
        public string Result { get; set; }
        public string Outcome { get; set; }
    }
}
