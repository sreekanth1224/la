﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_AdminReview.WebParts.CRLog_Entry
{
    [ToolboxItemAttribute(false)]
    public partial class CRLog_Entry : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        public CRLog_Entry()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                txtDateIn.Text = DateTime.Today.ToShortDateString();
                SPListItemCollection listColl = GetCurrentDayItems();
                if (listColl.Count > 0)
                {
                    grvCRLDailyView.DataSource = listColl.GetDataTable();
                    grvCRLDailyView.DataBind();
                }
                else
                {
                    grvCRLDailyView.DataSource = null;
                    grvCRLDailyView.DataBind();
                }
            }
        }

        public String GetLogEntryID()
        {
            String CRLogID = String.Empty;
            DateTime todaysDate = DateTime.Now.Date;
            int CRLID = 0;
            String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2018
            String MonthFormat = String.Empty;
            SPListItemCollection listColl = GetCurrentDayItems();
            if (listColl.Count > 0)
            {
                foreach (SPListItem item in listColl) {
                    CRLogID = Convert.ToString(item["Title"]);
                    CRLogID = Convert.ToString(item["CRLID"]);
                    break;
                }
                
                CRLogID = CRLogID.Substring(CRLogID.LastIndexOf('-') + 1);
                CRLID = Convert.ToInt32(CRLogID) + 1;
                CRLogID = "CRL-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + CRLID;
            }
            else
            {
                CRLogID = "CRL-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + "1";
            }
            return CRLogID;
        }
        public void SaveCRLogEntry()
        {
            try
            {
                String errorMessage = String.Empty;

                if (txtProvider.Text == "")
                {
                    errorMessage = "Please select Provider";
                }
                else if (txtRecipientName.Text == "")
                {
                    errorMessage = "Please select Recipient";
                }
                else if (txtFirstDateOfService.Text == "")
                {
                    errorMessage = "Please enter First Date of Service";
                }
                else if (txtLastDateOfService.Text == "")
                {
                    errorMessage = "Please enter Last Date of Service";
                }

                if (String.IsNullOrEmpty(errorMessage))
                {
                    String CRLogID = GetLogEntryID();
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList CRLogList = web.Lists["Customer Review Log"];
                            SPListItemCollection listItems = CRLogList.Items;
                            SPListItem item = listItems.Add();
                            item["Title"] = CRLogID;
                            item["CRLID"] = CRLogID;
                            item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                            item["Provider"] = txtProvider.Text;
                            item["ReceipientName"] = txtRecipientName.Text;
                            item["FirstDateofService"] = Convert.ToDateTime(txtFirstDateOfService.Text);
                            item["LastDateofService"] = Convert.ToDateTime(txtLastDateOfService.Text);
                            item["AssignedTo"] = txtAssignedTo.Text;
                            item["Result"] = txtResult.Text;
                            item["DateOut"] = (Convert.ToString(txtDateOut.Text) == null) ? DateTime.MinValue : Convert.ToDateTime(txtDateOut.Text);
                            item.Update();
                        }
                    }
                }
                else
                {
                    lblErrorMessage.Text = errorMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public SPListItemCollection GetCurrentDayItems()
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        String strQuery = "<Where>" +
                                             "<Eq>" +
                                                  "<FieldRef Name='DateIn'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Today) + "</Value>" +
                                             "</Eq>" +
                                            "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                  "<FieldRef Name='CRLID' />",
                                    "<FieldRef Name='Provider' />",
                                    "<FieldRef Name='ReceipientName' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateOut' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='FirstDateofService' />",
                                    "<FieldRef Name='LastDateofService' />",
                                    "<FieldRef Name='Result' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = CRLogList.GetItems(query);
                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            SaveCRLogEntry();            
            clearentrydetails();
            SPListItemCollection listColl = GetCurrentDayItems();
            if (listColl.Count > 0)
            {
                grvCRLDailyView.DataSource = listColl.GetDataTable();
                grvCRLDailyView.DataBind();
            }
            else
            {
                grvCRLDailyView.DataSource = null;
                grvCRLDailyView.DataBind();
            }

        }

        public void clearentrydetails()
        {
            txtAssignedTo.Text = string.Empty;
            txtDateIn.Text = string.Empty;
            txtDateOut.Text = string.Empty;
            txtFirstDateOfService.Text = string.Empty;
            txtLastDateOfService.Text = string.Empty;
            txtResult.Text = string.Empty;
            txtProvider.Text = string.Empty;
            txtRecipientName.Text = string.Empty;
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clearentrydetails();
        }
    }
}
