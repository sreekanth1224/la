﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_AdminReview.Utility;

namespace Medicaid_AdminReview.WebParts.ARSearch
{
    [ToolboxItemAttribute(false)]
    public partial class ARSearch : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public ARSearch()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        Int32 pageIndex = 0;    //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        List<ARSearchEntity> searchEntity = new List<ARSearchEntity>();
        DateTime tempDate;
        DateTime tempDate1;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindARGridDetails(null);
            }
        }

        public List<ARSearchEntity> BindARGridDetails(string paging)
        {
            bool isDueDateValid = (txtDOSFrom.Text == "DOS From" || txtDOSFrom.Text.Length == 0) ? true : DateTime.TryParse(txtDOSFrom.Text, out tempDate);
            bool isDueDateValid1 = (txtDOSTo.Text == "DOS To" || txtDOSTo.Text.Length == 0) ? true : DateTime.TryParse(txtDOSTo.Text, out tempDate1);
            if (isDueDateValid && isDueDateValid1)
            {
                //SPListItemCollection listColl = null;
                try
                {
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                    pageIndex = 0;

                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList ARSearchList = web.Lists["AR Grid List"];
                            List<string> objColumns = new List<string>();
                            SPQuery query = new SPQuery();
                            String strQuery = "";

                            if (txtARNumber.Text != "AR Number" && txtARNumber.Text.Length > 0)
                            {
                                objColumns.Add("ARNumber;Text;Contains;" + txtARNumber.Text.Trim());
                            }
                            if (txtProvider.Text != "Provider" && txtProvider.Text.Length > 0)
                            {
                                objColumns.Add("ProviderID;Text;Contains;" + txtProvider.Text.Trim());
                            }
                            if (txtRecipient.Text != "Recipient" && txtRecipient.Text.Length > 0)
                            {
                                objColumns.Add("Recipient;Text;Contains;" + txtRecipient.Text.Trim());
                            }
                            if (txtOutcome.Text != "Outcome" && txtOutcome.Text.Length > 0)
                            {
                                objColumns.Add("Outcome;Text;Contains;" + txtOutcome.Text.Trim());
                            }
                            if (txtDOSFrom.Text != "DOS From" && txtDOSFrom.Text.Length > 0)
                            {
                                objColumns.Add("DOSFrom;DateTime;Geq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDOSFrom.Text)));
                            }
                            if (txtDOSTo.Text != "DOS To" && txtDOSTo.Text.Length > 0)
                            {
                                objColumns.Add("DOSTo;DateTime;Leq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDOSTo.Text)));
                            }
                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = strQuery +
                                             "<OrderBy>" +
                                                "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                             "</OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                     "<FieldRef Name='Title' />",
                                     "<FieldRef Name='ARNumber' />",
                                     "<FieldRef Name='ARVersion' />",
                                      "<FieldRef Name='CRLID' />",
                                      "<FieldRef Name='ID' />",
                                      "<FieldRef Name='Outcome' />",
                                        "<FieldRef Name='ProviderID' />",
                                        "<FieldRef Name='Recipient' />",
                                        "<FieldRef Name='DateIn' />",
                                        "<FieldRef Name='DateCompleted' />",
                                        "<FieldRef Name='AssignedTo' />",
                                        "<FieldRef Name='DOSFrom' />",
                                        "<FieldRef Name='DOSTo' />",
                                        "<FieldRef Name='Result' />");

                            //query.DatesInUtc = false;

                            //query.ViewFieldsOnly = true;
                            //listColl = CRLogList.GetItems(query);
                            //gvARSearch.DataSource = listColl.GetDataTable();
                            //gvARSearch.DataBind();

                            //query.ViewFieldsOnly = true;

                            //if (itemPoistion != null)
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}
                            SPListItemCollection listColl = ARSearchList.GetItems(query);
                            Int32 ARListCount = listColl.Count;
                            if (listColl != null && ARListCount > 0)
                            {
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = ARListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == ARListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (ARListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                //lblRecordCount.Text = Convert.ToString(scanListCollection.Count());

                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new ARSearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        ARNumber = Convert.ToString(item["ARNumber"]),
                                        ARVersion = Convert.ToString(item["ARVersion"]),
                                        AssignedTo = Convert.ToString(item["AssignedTo"]),
                                        CRLID = Convert.ToString(item["CRLID"]),
                                        ProviderID = Convert.ToString(item["ProviderID"]),
                                        Recipient = Convert.ToString(item["Recipient"]),
                                        DateIn = Convert.ToDateTime(item["DateIn"]),
                                        DOSFrom = Convert.ToDateTime(item["DOSFrom"]),
                                        DOSTo = Convert.ToDateTime(item["DOSTo"]),
                                        Outcome = Convert.ToString(item["Outcome"])
                                    });
                                }
                            }
                            else
                            {
                                gvARSearch.DataSource = null;
                                gvARSearch.DataBind();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>"); //Ascending to FALSE
            }
            return sb.ToString();
        }

        public void ClearSearchFields()
        {
            if (txtARNumber.Text == "AR Number")
            {
                txtARNumber.Text = "";
            }
            if (txtDOSFrom.Text == "DOS From")
            {
                txtDOSFrom.Text = "";
            }
            if (txtDOSTo.Text == "DOS To")
            {
                txtDOSTo.Text = "";
            }
            if (txtOutcome.Text == "Outcome")
            {
                txtOutcome.Text = "";
            }
            if (txtProvider.Text == "Provider")
            {
                txtProvider.Text = "";
            }
            if (txtRecipient.Text == "Recipient")
            {
                txtRecipient.Text = "";
            }
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtARNumber.Text = "AR Number";
            txtDOSFrom.Text = "DOS From";
            txtDOSTo.Text = "DOS To";
            txtOutcome.Text = "Outcome";
            txtProvider.Text = "Provider";
            txtRecipient.Text = "Recipient";
            Page.Response.Redirect(siteUrl + "SitePages/AR Search.aspx");
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            ClearSearchFields();
            //GetScanListData(null,null);
            gvARSearch.DataSource = BindARGridDetails(null);
            gvARSearch.DataBind();
        }

        protected void gvARSearch_Sorting(object sender, GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        public void SortColumn(String sortExpression)
        {
            List<ARSearchEntity> ARSearchEntityList = BindARGridDetails(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "ARNumber":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.ARNumber).ToList() : ARSearchEntityList.OrderByDescending(x => x.ARNumber).ToList();
                    break;
                case "ARVersion":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.ARVersion).ToList() : ARSearchEntityList.OrderByDescending(x => x.ARVersion).ToList();
                    break;
                case "AssignedTo":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.AssignedTo).ToList() : ARSearchEntityList.OrderByDescending(x => x.AssignedTo).ToList();
                    break;
                case "CRLID":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.CRLID).ToList() : ARSearchEntityList.OrderByDescending(x => x.CRLID).ToList();
                    break;
                case "DateCompleted":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.DateCompleted).ToList() : ARSearchEntityList.OrderByDescending(x => x.DateCompleted).ToList();
                    break;
                case "DateIn":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.DateIn).ToList() : ARSearchEntityList.OrderByDescending(x => x.DateIn).ToList();
                    break;
                case "DOSFrom":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.DOSFrom).ToList() : ARSearchEntityList.OrderByDescending(x => x.DOSFrom).ToList();
                    break;
                case "DOSTo":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.DOSTo).ToList() : ARSearchEntityList.OrderByDescending(x => x.DOSTo).ToList();
                    break;
                case "Outcome":
                    gvARSearch.DataSource = (sortDirection == "ASC") ? ARSearchEntityList.OrderBy(x => x.Outcome).ToList() : ARSearchEntityList.OrderByDescending(x => x.Outcome).ToList();
                    break;
            }
            gvARSearch.DataBind();
        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvARSearch.DataSource = BindARGridDetails(null);
            gvARSearch.DataBind();
        }

    }
}
