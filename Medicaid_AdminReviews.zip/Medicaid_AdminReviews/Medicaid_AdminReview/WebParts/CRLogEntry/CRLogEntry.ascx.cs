﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_AdminReview.WebParts.CRLogEntry
{
    [ToolboxItemAttribute(false)]
    public partial class CRLogEntry : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]

        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        public CRLogEntry()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetCurrentDayItems();
            }
        }

        public void SaveCRLogEntry()
        {
            try
            {
                String errorMessage = String.Empty;

                if (txtProvider.Text == "")
                {
                    errorMessage = "Please select Provider";
                }
                else if (txtRecipientName.Text == "")
                {
                    errorMessage = "Please select Recipient";
                }
                else if (txtFirstDateOfService.Text == "")
                {
                    errorMessage = "Please enter First Date of Service";
                }
                else if (txtLastDateOfService.Text == "")
                {
                    errorMessage = "Please enter Last Date of Service";
                }

                if (String.IsNullOrEmpty(errorMessage))
                {
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList CRLogList = web.Lists["Customer Review Log"];
                            SPListItemCollection listItems = CRLogList.Items;
                            SPListItem item = listItems.Add();
                            item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                            item["Provider"] = txtProvider.Text;
                            item["ReceipientName"] = txtRecipientName.Text;
                            item["FirstDateofService"] = Convert.ToDateTime(txtFirstDateOfService.Text);
                            item["LastDateofService"] = Convert.ToDateTime(txtLastDateOfService.Text);
                            item["AssignedTo"] = txtAssignedTo.Text;
                            item["Result"] = txtResult.Text;
                            item["DateOut"] = (Convert.ToString(txtDatOut.Text) == null) ? DateTime.MinValue : Convert.ToDateTime(txtDatOut.Text);
                            item.Update();
                        }
                    }
                }
                else
                {
                    lblErrorMessage.Text = errorMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetCurrentDayItems()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        String strQuery = "<Where>" +
                                             "<Geq>" +
                                                  "<FieldRef Name='DateIn'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Now.AddDays(-1).Date) + "</Value>" +
                                             "</Geq>" +
                                            "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                    "<FieldRef Name='Provider' />",
                                    "<FieldRef Name='ReceipientName' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateOut' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='FirstDateofService' />",
                                    "<FieldRef Name='LastDateofService' />",
                                    "<FieldRef Name='Result' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        SPListItemCollection listColl = CRLogList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            grvCRLDailyView.DataSource = listColl.GetDataTable();
                            grvCRLDailyView.DataBind();
                        }
                        else
                        {
                            grvCRLDailyView.DataSource = null;
                            grvCRLDailyView.DataBind();
                        }
                    }
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            SaveCRLogEntry();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {

        }
    }
}
