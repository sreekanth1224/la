﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_AdminReview.WebParts.ARGrid
{
    [ToolboxItemAttribute(false)]
    public partial class ARGrid : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        public ARGrid()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                String todaysDate = DateTime.Today.ToShortDateString();
                txtSubmittedDate.Text = todaysDate;
                SPListItemCollection listColl = GetCurrentDayItems(todaysDate, String.Empty);
                if (listColl.Count > 0)
                {
                    gvARDeatils.DataSource = listColl.GetDataTable();
                    gvARDeatils.DataBind();
                }
                else
                {
                    FirstGridViewRow();
                }
                BindCRLID();
            }
        }

        private void FirstGridViewRow() //Set First Grid Row
        {
            DataTable dt = new DataTable();
            DataRow dr = null;

            /*Start-Scan List Dev Site*/
            dt.Columns.Add(new DataColumn("Title", typeof(string))); //added
            dt.Columns.Add(new DataColumn("ARNumber", typeof(string)));
            dt.Columns.Add(new DataColumn("ARVersion", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("ProviderID", typeof(string)));
            dt.Columns.Add(new DataColumn("Recipient", typeof(string)));
            dt.Columns.Add(new DataColumn("DOSFrom", typeof(string)));
            dt.Columns.Add(new DataColumn("DOSTo", typeof(string)));
            dt.Columns.Add(new DataColumn("DateCompleted", typeof(string)));
            dt.Columns.Add(new DataColumn("DateIn", typeof(string)));
            dt.Columns.Add(new DataColumn("Outcome", typeof(string)));
            dt.Columns.Add(new DataColumn("OutcomeReason", typeof(string)));
            dt.Columns.Add(new DataColumn("ReferredTo", typeof(string)));
            dt.Columns.Add(new DataColumn("CRLID", typeof(string)));
            dt.Columns.Add(new DataColumn("AssignedTo", typeof(string)));
            dt.Columns.Add(new DataColumn("Result", typeof(string))); //IsReOpened
            dt.Columns.Add(new DataColumn("IsReOpened", typeof(string)));

            dr = dt.NewRow();

            dr["Title"] = string.Empty;
            dr["ARNumber"] = string.Empty;
            dr["ARVersion"] = string.Empty;
            dr["ID"] = string.Empty;
            dr["ProviderID"] = string.Empty;
            dr["Recipient"] = string.Empty;
            dr["DOSFrom"] = string.Empty;
            dr["DOSTo"] = string.Empty;
            dr["DateCompleted"] = string.Empty;
            dr["DateIn"] = string.Empty;
            dr["Outcome"] = string.Empty;
            dr["OutcomeReason"] = string.Empty;
            dr["ReferredTo"] = string.Empty;
            dr["CRLID"] = string.Empty;
            dr["AssignedTo"] = string.Empty;
            dr["Result"] = string.Empty;
            dr["IsReOpened"] = "1";

            dt.Rows.Add(dr);

            //ViewState["CurrentTable"] = dt;

            gvARDeatils.DataSource = dt;
            gvARDeatils.DataBind();


            //append log-in user


        }

        private void BindCRLID()
        {
            DropDownList ddlCRLID = (DropDownList)gvARDeatils.FooterRow.FindControl("ddlCRLID");
            ddlCRLID.DataSource = GetCRLogID().GetDataTable();
            ddlCRLID.DataTextField = "CRLID";
            ddlCRLID.DataValueField = "CRLID";
            ddlCRLID.DataBind();
            ddlCRLID.Items.Insert(0, "Select");
        }

        public String GetARID()
        {
            String ARID = String.Empty;
            DateTime todaysDate = DateTime.Now.Date;
            int ARNumber = 0;
            //String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2018
            String Year = DateTime.Now.Year.ToString();
            String MonthFormat = String.Empty;

            SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);

            if (listColl.Count > 0)
            {
                foreach (SPListItem item in listColl)
                {
                    ARID = Convert.ToString(item["Title"]);
                    //ARID = Convert.ToString(item["ARNumber"]);
                    break;
                }

                ARID = ARID.Substring(ARID.LastIndexOf('-') + 1);
                ARNumber = Convert.ToInt32(ARID) + 1;
                if (Convert.ToInt32(ARNumber) < 9)
                    ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-00" + ARNumber;
                else
                    ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-0" + Convert.ToInt32(ARNumber);

            }
            else
            {
                ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + "001";
            }
            return ARID;
        }

        public SPListItemCollection GetCRLogID()
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        String strQuery = "<Where>" +
                                           "<Eq>" +
                                                "<FieldRef Name='CRLStatus'/>" +
                                                 "<Value Type='Boolean'>0</Value>" +    //Get all CRLID with 'No' status
                                            "</Eq>" +
                                       "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat("<FieldRef Name='CRLID' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = CRLogList.GetItems(query);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        public SPListItemCollection GetCurrentDayItems()
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList ARGridList = web.Lists["AR Grid List"];
                        SPQuery query = new SPQuery();
                        String strQuery = "";
                        DateTime searchDate = DateTime.Parse(submittedDate);

                        if (searchDate == DateTime.Today)
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                             "<Eq>" +
                                                  "<FieldRef Name='Created'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchDate) + "</Value>" +
                                             "</Eq>" +
                                              "<Eq>" +
                                                "<FieldRef Name='IsReOpened'/>" +
                                                 "<Value Type='Boolean'>0</Value>" +
                                              "</Eq>" +
                                             "</And>" +
                                            "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtSubmittedDate.Text) && !String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='ARNumber'/>" +
                                                          "<Value Type='Text'>" + txtSearchAR.Text + "</Value>" +
                                                     "</Contains>" +
                                                     "<And>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                                     "</Geq>" +
                                                      "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                                     "</Leq>" +
                                                     "</And>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtSubmittedDate.Text) && String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                                "</Geq>" +
                                                 "<Leq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                                "</Leq>" +
                                            "</And>" +
                                        "</Where>";
                        }
                        else if (String.IsNullOrEmpty(txtSubmittedDate.Text) && !String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                           "<Contains>" +
                                                "<FieldRef Name='ARNumber'/>" +
                                                 "<Value Type='Text'>" + txtSearchAR.Text + "</Value>" +
                                            "</Contains>" +
                                       "</Where>";
                        }
                        else
                        {
                            strQuery = "<Where>" +
                                          "<And>" +
                                              "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                              "</Geq>" +
                                               "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(txtSubmittedDate.Text)) + "</Value>" +
                                              "</Leq>" +
                                          "</And>" +
                                      "</Where>";
                        }

                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                 "<FieldRef Name='ARNumber' />",
                                 "<FieldRef Name='ARVersion' />",
                                  "<FieldRef Name='CRLID' />",
                                  "<FieldRef Name='ID' />",
                                  "<FieldRef Name='Outcome' />",
                                  "<FieldRef Name='OutcomeReason' />",
                                  "<FieldRef Name='ReferredTo' />",
                                    "<FieldRef Name='ProviderID' />",
                                    "<FieldRef Name='Recipient' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateCompleted' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='DOSFrom' />",
                                    "<FieldRef Name='DOSTo' />",
                                    "<FieldRef Name='IsReOpened' />",
                                    "<FieldRef Name='Result' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = ARGridList.GetItems(query);
                        //gvARDeatils.DataSource = listColl.GetDataTable();
                        //gvARDeatils.DataBind();

                        if (searchDate < DateTime.Today)
                        {
                            gvARDeatils.FooterRow.Visible = false;
                            gvARDeatils.ShowFooter = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return listColl;
        }

        public SPListItemCollection GetItemBasedonCRLID(String CRLID)
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        String strQuery = "<Where>" +
                                             "<Contains>" +
                                                  "<FieldRef Name='CRLID'/>" +
                                                  "<Value Type='Text'>" + CRLID + "</Value>" +
                                             "</Contains>" +
                                            "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                  "<FieldRef Name='CRLID' />",
                                    "<FieldRef Name='Provider' />",
                                   "<FieldRef Name='ReceipientName' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateOut' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='FirstDateofService' />",
                                    "<FieldRef Name='LastDateofService' />",
                                    "<FieldRef Name='Result' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = CRLogList.GetItems(query);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        public void SaveAREntryDetails()
        {
            try
            {
                Label1.Text = "";
                Label2.Text = "";
                String errorMessage = String.Empty;
                GridViewRow row = gvARDeatils.FooterRow;

                DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlCRLID");
                TextBox txtARNumber = (TextBox)row.FindControl("txtARNumber");
                TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
                TextBox txtRecipient = (TextBox)row.FindControl("txtRecipientFooter");
                TextBox txtFirstDateofService = (TextBox)row.FindControl("txtFirstDateofService");
                TextBox txtLastDateofService = (TextBox)row.FindControl("txtLastDateofService");
                TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
                TextBox txtDateIn = (TextBox)row.FindControl("txtDateInFooter");
                TextBox txtDateOut = (TextBox)row.FindControl("txtDateOut");
                TextBox txtResult = (TextBox)row.FindControl("txtResult");
                DropDownList ddlOutcome = (DropDownList)row.FindControl("ddlOutcomeFooter");

                if (txtProvider.Text == "")
                {
                    errorMessage = "Please select Provider";
                }
                else if (txtRecipient.Text == "")
                {
                    errorMessage = "Please select Recipient";
                }
                else if (txtFirstDateofService.Text == "")
                {
                    errorMessage = "Please select First Date of Service";
                }
                else if (txtLastDateofService.Text == "")
                {
                    errorMessage = "Please select Last Date of Service";
                }
                else if (txtAssignedTo.Text == "")
                {
                    errorMessage = "Please select Assigned To";
                }
                else if (txtDateOut.Text == "")
                {
                    errorMessage = "Please select Date Out";
                }

                if (String.IsNullOrEmpty(errorMessage))
                {
                    String ARID = GetARID();
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {

                            SPList CRLogList = web.Lists["AR Grid List"]; //AR Grid List
                            SPListItemCollection listItems = CRLogList.Items;
                            SPListItem item = listItems.Add();
                            String strCRLID = ddlCRLID.SelectedValue;
                            item["Title"] = ARID;
                            item["ARNumber"] = ARID;
                            item["ARVersion"] = ARID;
                            item["CRLID"] = strCRLID;
                            item["ProviderID"] = txtProvider.Text;
                            item["Recipient"] = txtRecipient.Text;
                            item["DateIn"] = DateTime.Today.ToShortDateString(); //Convert.ToDateTime(txtDateIn.Text);
                            item["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                            item["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                            item["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                            item["AssignedTo"] = txtAssignedTo.Text;
                            item["Result"] = txtResult.Text;
                            item["Outcome"] = "Pending";
                            item.Update();

                            //Update CRL Status
                            SPList CRLList = web.Lists["Customer Review Log"];
                            SPQuery query = new SPQuery();
                            String strQuery = "";
                            strQuery = "<Where>" +
                                           "<Eq>" +
                                                "<FieldRef Name='CRLID'/>" +
                                                 "<Value Type='Text'>" + strCRLID + "</Value>" +
                                            "</Eq>" +
                                       "</Where>";
                            query.Query = strQuery;
                            SPListItemCollection CRLcoll = CRLList.GetItems(query);
                            //SPListItem CRLitem = CRLcoll[0];

                            foreach (SPListItem CRLitem in CRLcoll)
                            {
                                CRLitem["CRLStatus"] = true;    //Set CRLStatus to 'Yes'
                                CRLitem.Update();
                            }
                        }
                    }
                }
                else
                {
                    Label1.Text = errorMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void gvARDeatils_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {

        }

        protected void gvARDeatils_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            gvARDeatils.EditIndex = e.NewEditIndex;
            
            SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);
            if (listColl.Count > 0)
            {
                gvARDeatils.DataSource = listColl.GetDataTable();
                gvARDeatils.DataBind();
            }
            else
            {
                FirstGridViewRow();
            }
            BindCRLID();
        }

        protected void gvARDeatils_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            gvARDeatils.ShowFooter = true;
            ButtonSave.Visible = true;
            try
            {
                String errorMessage = String.Empty;
                GridViewRow row = gvARDeatils.Rows[e.RowIndex];
                Label lblID = (Label)row.FindControl("lblID");
                DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlEditCRLID");
                Label lblARNumber = (Label)row.FindControl("lblARNumber");
                TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
                TextBox txtRecipient = (TextBox)row.FindControl("txtRecipient");
                TextBox txtFirstDateofService = (TextBox)row.FindControl("txtDOSFrom");
                TextBox txtLastDateofService = (TextBox)row.FindControl("txtDOSTo");
                TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
                TextBox txtDateIn = (TextBox)row.FindControl("txtDateIn");
                TextBox txtDateOut = (TextBox)row.FindControl("txtDateCompleted");
                TextBox txtResult = (TextBox)row.FindControl("txtResult");
                DropDownList ddlOutcome = (DropDownList)row.FindControl("ddlOutcome");
                TextBox txtOutcomeReason = (TextBox)row.FindControl("txtOutcomeReason");
                TextBox txtReferredTo = (TextBox)row.FindControl("txtReferredTo");

                if (txtProvider.Text == "")
                {
                    errorMessage = "Please select Provider";
                }

                if (String.IsNullOrEmpty(errorMessage))
                {
                    //String ARID = GetARID();
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {

                            SPList ARGridList = web.Lists["AR Grid List"]; //AR Grid List
                            SPListItem item = ARGridList.GetItemById(Convert.ToInt32(lblID.Text));
                            //item["Title"] = ARID;
                            //item["ARNumber"] = ARID;
                            //item["CRLID"] = ddlCRLID.SelectedValue;
                            if ((Convert.ToString(item["Outcome"]) != "Pending") && (Convert.ToString(item["Outcome"]) != "More Info Needed") && (Convert.ToString(item["Outcome"]) != "Referred To"))
                            {

                                SPListItemCollection listItems = ARGridList.Items;
                                SPListItem itemAdd = listItems.Add();
                                String ARNumber = lblARNumber.Text;//AR-2018-12-21-002 
                                String ARNumVersion = ARNumber.Split('-')[4];
                                String ARNumVersionUpdated = String.Empty;
                                String prevARNumber = ARNumber;
                                if (ARNumVersion.Contains("."))
                                {
                                    ARNumVersionUpdated = ARNumVersion.Split('.')[0] + "." + (Convert.ToInt32(ARNumVersion.Split('.')[1]) + 1);
                                    ARNumber = ARNumber.Replace(ARNumVersion, ARNumVersionUpdated);
                                }
                                else
                                {
                                    ARNumber = ARNumber + ".1";
                                }

                                itemAdd["Title"] = ARNumber.Split('.')[0];
                                itemAdd["ARNumber"] = ARNumber;
                                itemAdd["ARVersion"] = ARNumber;
                                itemAdd["CRLID"] = ddlCRLID.SelectedValue;
                                itemAdd["ProviderID"] = txtProvider.Text;
                                itemAdd["Recipient"] = txtRecipient.Text;
                                itemAdd["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                                itemAdd["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                                itemAdd["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                                itemAdd["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                                itemAdd["AssignedTo"] = txtAssignedTo.Text;
                                itemAdd["Result"] = txtResult.Text;
                                itemAdd["Outcome"] = "Pending";
                                itemAdd["OutcomeReason"] = txtOutcomeReason.Text;
                                itemAdd["ReferredTo"] = txtReferredTo.Text;
                                //itemAdd["IsReOpened"] = false;
                                itemAdd.Update();

                                item["IsReOpened"] = true;
                                item.Update();

                                AddVersionedDocument(prevARNumber, ARNumber, web);
                            }
                            else
                            {
                                item["ProviderID"] = txtProvider.Text;
                                item["Recipient"] = txtRecipient.Text;
                                item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                                item["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                                item["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                                item["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                                item["AssignedTo"] = txtAssignedTo.Text;
                                item["Result"] = txtResult.Text;
                                item["Outcome"] = ddlOutcome.SelectedValue;
                                item["OutcomeReason"] = txtOutcomeReason.Text;
                                item["ReferredTo"] = txtReferredTo.Text;
                                item.Update();
                            }
                        }
                    }
                }
                else
                {
                    //lblErrorMessage.Text = errorMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            gvARDeatils.EditIndex = -1;
            SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);
            if (listColl.Count > 0)
            {
                gvARDeatils.DataSource = listColl.GetDataTable();
                gvARDeatils.DataBind();
                BindCRLID();
            }

        }

        protected void gvARDeatils_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            gvARDeatils.EditIndex = -1;
            SPListItemCollection listColl = GetCurrentDayItems();
            if (listColl.Count > 0)
            {
                gvARDeatils.DataSource = listColl.GetDataTable();
                gvARDeatils.DataBind();
                BindCRLID();
            }
        }

        protected void gvARDeatils_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView rowView = e.Row.DataItem as DataRowView;
                if (gvARDeatils.EditIndex == e.Row.RowIndex)
                {
                    DropDownList ddlCRLID = (DropDownList)e.Row.FindControl("ddlEditCRLID");
                    ddlCRLID.DataSource = GetCRLogID().GetDataTable();
                    ddlCRLID.DataTextField = "CRLID";
                    ddlCRLID.DataValueField = "CRLID";
                    ddlCRLID.DataBind();
                    ddlCRLID.Items.Insert(0, "Select");
                    ddlCRLID.SelectedValue = Convert.ToString(rowView["CRLID"]);

                    DropDownList ddlOutcome = (DropDownList)e.Row.FindControl("ddlOutcome");
                    ddlOutcome.SelectedValue = Convert.ToString(rowView["Outcome"]);
                    TextBox txtOutcomeReason = (TextBox)e.Row.FindControl("txtOutcomeReason");
                    TextBox txtReferredTo = (TextBox)e.Row.FindControl("txtReferredTo");
                    if (Convert.ToString(rowView["Outcome"]) != "Pending" && Convert.ToString(rowView["Outcome"]) != "Approved")
                    {
                        txtOutcomeReason.Visible = true;
                        txtOutcomeReason.Text = Convert.ToString(rowView["OutcomeReason"]);
                        txtReferredTo.Visible = false;
                    }
                    else if (Convert.ToString(rowView["Outcome"]) == "Referred To")
                    {
                        txtOutcomeReason.Visible = false;
                        txtReferredTo.Visible = true;
                        txtReferredTo.Text = Convert.ToString(rowView["ReferredTo"]);
                    }
                    else
                    {
                        txtOutcomeReason.Visible = false;
                        txtReferredTo.Visible = false;
                    }
                    Label lblARNumber = (Label)e.Row.FindControl("lblARNumber");
                    lblARNumber.Text = Convert.ToString(rowView["ARNumber"]);
                }
                
                if (!((e.Row.RowState & DataControlRowState.Edit) > 0))
                {
                    Label lblIsReOpened = (Label)e.Row.FindControl("lblIsReOpened");
                    Label lblOutcome = (Label)e.Row.FindControl("lblOutcome");
                    if (lblOutcome.Text == "Pending" && lblIsReOpened.Text == "0")
                    {
                        e.Row.Cells[0].Controls[0].Visible = true;
                    }
                    if ((lblOutcome.Text == "Approved" || lblOutcome.Text == "Denied")
                        && lblIsReOpened.Text == "0") // reopen option should be visible for appr/denial
                    {
                        Button btnReopen = (Button)e.Row.FindControl("btnReopen");
                        btnReopen.Visible = true;
                        e.Row.Cells[0].Controls[0].Visible = false;
                    }
                    if (lblIsReOpened.Text == "1")
                    {
                        Button btnReopen = (Button)e.Row.FindControl("btnReopen");
                        btnReopen.Visible = false;
                        e.Row.Cells[0].Controls[0].Visible = false;
                    }
                }
            }
        }

        protected void gvARDeatils_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {

        }

        protected void ddlCRLID_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlCRLID = (DropDownList)sender;
            if (ddlCRLID.SelectedValue != "Select")
            {
                SPListItemCollection listColl = GetItemBasedonCRLID(ddlCRLID.SelectedValue);
                if (listColl.Count > 0)
                {
                    TextBox txtProvider = (TextBox)gvARDeatils.FooterRow.FindControl("txtProvider");
                    TextBox txtRecipient = (TextBox)gvARDeatils.FooterRow.FindControl("txtRecipientFooter");
                    TextBox txtDateIn = (TextBox)gvARDeatils.FooterRow.FindControl("txtDateInFooter");
                    TextBox txtFirstDateofService = (TextBox)gvARDeatils.FooterRow.FindControl("txtFirstDateofService");
                    TextBox txtLastDateofService = (TextBox)gvARDeatils.FooterRow.FindControl("txtLastDateofService");
                    TextBox txtAssignedTo = (TextBox)gvARDeatils.FooterRow.FindControl("txtAssignedTo");
                    TextBox txtDateOut = (TextBox)gvARDeatils.FooterRow.FindControl("txtDateOut");
                    TextBox txtResult = (TextBox)gvARDeatils.FooterRow.FindControl("txtResult");

                    foreach (SPListItem item in listColl)
                    {
                        txtProvider.Text = Convert.ToString(item["Provider"]);
                        txtRecipient.Text = Convert.ToString(item["ReceipientName"]);
                        txtDateIn.Text = Convert.ToString(item["DateIn"]);
                        txtFirstDateofService.Text = Convert.ToString(item["FirstDateofService"]);
                        txtLastDateofService.Text = Convert.ToString(item["LastDateofService"]);
                        txtAssignedTo.Text = Convert.ToString(item["AssignedTo"]);
                        txtDateOut.Text = Convert.ToString(item["DateOut"]);
                        txtResult.Text = Convert.ToString(item["Result"]);
                    }
                }
            }
        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            GridViewRow row = gvARDeatils.FooterRow;

            DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlCRLID");
            TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
            TextBox txtRecipient = (TextBox)row.FindControl("txtRecipient");
            TextBox txtFirstDateofService = (TextBox)row.FindControl("txtFirstDateofService");
            TextBox txtLastDateofService = (TextBox)row.FindControl("txtLastDateofService");
            TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
            TextBox txtDateOut = (TextBox)row.FindControl("txtDateOut");
            TextBox txtResult = (TextBox)row.FindControl("txtResult");

            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            if (txtProvider.Text == "")
            {
                errorMessage = "Please select or enter a Provider";
            }
            //else if (txtRecipient.Text == "")
            //{
            //    errorMessage = "Please select or enter a Recipient";
            //}
            SaveAREntryDetails();
            SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);
            if (listColl.Count > 0)
            {
                gvARDeatils.DataSource = listColl.GetDataTable();
                gvARDeatils.DataBind();
            }
            BindCRLID();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);
            if (listColl.Count > 0)
            {
                gvARDeatils.DataSource = listColl.GetDataTable();
                gvARDeatils.DataBind();
            }
            else
            {
                FirstGridViewRow();
            }
        }

        protected void ddlOutcome_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)(sender as DropDownList).NamingContainer;
            String strOutcome = ((DropDownList)row.FindControl("ddlOutcome")).SelectedValue;
            TextBox txtOutcomeReason = (TextBox)row.FindControl("txtOutcomeReason");
            TextBox txtReferredTo = (TextBox)row.FindControl("txtReferredTo");
           
            if (strOutcome == "Approved" || strOutcome == "Denied")
            {
                txtOutcomeReason.Visible = true;
                txtReferredTo.Visible = false;
            }
            else if (strOutcome == "Referred To")
            {
                txtReferredTo.Visible = true;
                txtOutcomeReason.Visible = false;
            }
            else
            {
                txtReferredTo.Visible = false;
                txtOutcomeReason.Visible = false;
            }
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(siteUrl + "/");
        }

        protected void ddlEditCRLID_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)(sender as DropDownList).NamingContainer;
            DropDownList ddlEditCRLID = (DropDownList)sender;
            if (ddlEditCRLID.SelectedValue != "Select")
            {
                SPListItemCollection listColl = GetItemBasedonCRLID(ddlEditCRLID.SelectedValue);
                if (listColl.Count > 0)
                {
                    TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
                    TextBox txtRecipient = (TextBox)row.FindControl("txtRecipient");
                    TextBox txtDateIn = (TextBox)row.FindControl("txtDateIn");
                    TextBox txtFirstDateofService = (TextBox)row.FindControl("txtDOSFrom");
                    TextBox txtLastDateofService = (TextBox)row.FindControl("txtDOSTo");
                    TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
                    TextBox txtDateOut = (TextBox)row.FindControl("txtDateCompleted");
                    TextBox txtResult = (TextBox)row.FindControl("txtResult");

                    foreach (SPListItem item in listColl)
                    {
                        txtProvider.Text = Convert.ToString(item["Provider"]);
                        txtRecipient.Text = Convert.ToString(item["ReceipientName"]);
                        txtDateIn.Text = Convert.ToString(item["DateIn"]);
                        txtFirstDateofService.Text = Convert.ToString(item["FirstDateofService"]);
                        txtLastDateofService.Text = Convert.ToString(item["LastDateofService"]);
                        txtAssignedTo.Text = Convert.ToString(item["AssignedTo"]);
                        txtDateOut.Text = Convert.ToString(item["DateOut"]);
                        txtResult.Text = Convert.ToString(item["Result"]);
                    }
                }
            }
        }

        public void AddVersionedDocument(String prevARNumber, String ARNumber, SPWeb currentWeb)
        {
            SPList ARGridLib = currentWeb.Lists["AR Grid"];
            Boolean IsfileExists = currentWeb.GetFile(siteUrl + "/" + ARGridLib.RootFolder + "/" + prevARNumber).Exists;
            if (IsfileExists)
            {
                Uri ARGRidLibFolder = new Uri(siteUrl + ARGridLib.RootFolder);
                String filePath = siteUrl + ARGridLib.RootFolder + "/" + prevARNumber + ".pdf";
                SPFile srcFile = currentWeb.GetFile(filePath);
                SPFolder dstLibFolder = currentWeb.GetFolder(ARGRidLibFolder.AbsolutePath);
                dstLibFolder.Files.Add(ARGRidLibFolder.AbsolutePath + "/" + ARNumber + ".pdf", srcFile.OpenBinary());
            }
        }

        protected void gvARDeatils_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                //do nothing
            }
        }
    }
}        
    

