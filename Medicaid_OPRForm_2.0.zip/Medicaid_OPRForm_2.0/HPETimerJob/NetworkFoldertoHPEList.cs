﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using itextSharpText = iTextSharp.text;
using System.Text.RegularExpressions;
using iTextSharp.text;
using System.Net;
using System.Net.Mail;

namespace HPETimerJob
{
    class NetworkFoldertoHPEList : SPJobDefinition
    {
        public NetworkFoldertoHPEList() : base() { }

        public NetworkFoldertoHPEList(SPWebApplication webApp)
            : base("HPETimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "HPETimerJob";
        }

        public NetworkFoldertoHPEList(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public NetworkFoldertoHPEList(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            //Scan Merge Doc to Scan OPR library
            //MergeDocanDocLib();


            //HPE TimerJob
            AttachDocumenttoList();


            //Read Flat file(txt)
            ReadHPEFlatFile();
        }

        //Read fixed length DXC file
        public void ReadHPEFlatFile()
        {
            String networkScanOPRFolderPath = @"C:\HPE";
            //String networkScanOPRFolderPath = @"\\ms1gamftsftp\FiscalAgtIn";

            WebClient client = new WebClient();
            client.Credentials = new NetworkCredential("MS-Medicaid\\svc.sp.appservice", "@this40r");
            String[] HPEFiles = Directory.GetFiles(networkScanOPRFolderPath);
            HPEFiles = HPEFiles.Where(x => x.Contains(".txt")).ToArray();
            String EDSNumber = String.Empty;
            foreach (String HPEFile in HPEFiles)
            {
                EDSNumber = HPEFile.Substring(HPEFile.LastIndexOf("\\") + 1);
                EDSNumber = EDSNumber.Split('.')[0];
                UpdateHPEProperties(EDSNumber, HPEFile);
            }
        }

        public void UpdateHPEProperties(String EDSNumber, String HPEFile)
        {
            String HPESubject = String.Empty;
            String AuthorHPE = String.Empty;
            String OPRNumber = String.Empty;
            String DateReceived = String.Empty;
            using (StreamReader reader = new StreamReader(HPEFile))
            {
                String line = reader.ReadLine();
                if (line != null)
                {
                    HPESubject = line.Substring(9, 100); //100 Char
                    AuthorHPE = line.Substring(109, 30); //30 Char
                    OPRNumber = line.Substring(139, 15);
                    DateReceived = line.Substring(154, 10); //Date Received should be 10
                }
            }
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
            SPList HPEList = currentWeb.Lists["HPE"];
            SPQuery camlQuery = new SPQuery();
            Random random = new Random();
            var randomValue = random.Next(100, 10000000);
            camlQuery.Query = "<Where>" +
                                 "<And><Eq>" +
                                    "<FieldRef Name='EDS_Number'/>" +
                                    "<Value Type='Text'>" + EDSNumber + "</Value>" +
                                  "</Eq>" +
                                  "<Neq>" +
                                    "<FieldRef Name='Title'/>" +
                                    "<Value Type='Text'>" + randomValue + "</Value>" +
                                  "</Neq></And>" +
                              "</Where>";
            SPListItemCollection itemColl = HPEList.GetItems(camlQuery);
            if (itemColl.Count > 0)
            {
                foreach (SPListItem item in itemColl)
                {
                    currentWeb.AllowUnsafeUpdates = true;
                    item["Subject_HPE"] = HPESubject;
                    item["Author_HPE"] = AuthorHPE;
                    item["OPR_Number"] = OPRNumber;
                    item["DateReceived"] = DateReceived;
                    item.Update();
                    currentWeb.AllowUnsafeUpdates = false;
                }
            }
            //Delete file from the File System
            if (File.Exists(HPEFile))
            {
                File.Delete(HPEFile);
            }
        }

        #region "OPR Document Library commented code"
        //Merge Scanned doc from Scanner to Scan Merge Doc Library and this Timer job will pick the doc and merge it to Scan OPR based on the Doc Number
        //public void MergeDocanDocLib()
        //{
        //    List<String> lstFiles = new List<String>();
        //    String fileName = String.Empty;
        //    String fileScanOPRPath = String.Empty;
        //    String fileScanMergeDocPath = String.Empty;
        //    String fileUrl = String.Empty;
        //    String siteUrl = String.Empty;
        //    SPWebApplication webApp = this.Parent as SPWebApplication;
        //    SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
        //    siteUrl = currentWeb.Site.Url + "/director";
        //    //Scan Merge Doc List
        //    SPList scanMergeOPRLibrary = currentWeb.Lists["Scan Merge Doc"];

        //    //Scan OPR List
        //    //SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
        //    SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
        //    SPQuery queryScanOPR = new SPQuery();
        //    String strScanOPRQuery = String.Empty;
        //    SPQuery queryMergeOPR = new SPQuery();
        //    String strMergeOPRQuery = String.Empty;
        //    queryMergeOPR.ViewFields = string.Concat(
        //                "<FieldRef Name='ID' />",
        //                "<FieldRef Name='FileLeafRef' />");
        //    queryMergeOPR.Query = strMergeOPRQuery;
        //    SPListItemCollection collListItems = scanMergeOPRLibrary.GetItems(queryMergeOPR);
        //    foreach (SPListItem item in collListItems)
        //    {
        //        //fileUrl = item.File.Name;
        //        fileName = item.File.Name; //fileUrl.Remove(0, (fileUrl.IndexOf('/') + 1)); //Passing filename
        //        //strScanOPRQuery = "<Where>" +
        //        //                 "<Eq>" +
        //        //                   "<FieldRef Name=\"FileLeafRef\"/>" +
        //        //                    "<Value Type=\"Text\">" + fileName + "</Value>" +
        //        //                 "</Eq>" +
        //        //                "</Where>";
        //        //queryScanOPR.ViewFields = string.Concat(
        //        //            "<FieldRef Name='ID' />",
        //        //            "<FieldRef Name='FileLeafRef' />");
        //        //queryScanOPR.Query = strScanOPRQuery;
        //        //SPListItemCollection listItemCollection = scanOPRLibrary.GetItems(queryScanOPR);
        //        //if (listItemCollection.Count > 0)
        //        //{
        //        fileScanOPRPath = siteUrl + "/" + scanMergeOPRLibrary.RootFolder + "/" + fileName;
        //        fileScanOPRPath = siteUrl + "/Scan Merge Doc/" + fileName;
        //        fileScanMergeDocPath = siteUrl + "/Scan OPR/" + fileName;
        //        //fileScanMergeDocPath = siteUrl + "/Scan OPR/" + fileName;

        //        lstFiles.Add(fileScanMergeDocPath);
        //        lstFiles.Add(fileScanOPRPath);

        //        //Method to merge file fetched from Scan Opr & Scan Merge Doc Document Libraries
        //        ScanMergeDocuments(lstFiles, fileName, siteUrl);

        //        //update property document updated with scanned docs
        //        UpdateScanDocProp(siteUrl, fileName);
        //        //}
        //    }
        //}

        //public static void UpdateScanDocProp(String siteUrl, String fileName)
        //{
        //    using (SPSite site = new SPSite(siteUrl)) //dev Site - C
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
        //            SPFolder folder = currentWeb.Folders["Scan OPR"];
        //            SPFile file = folder.Files[fileName];
        //            //SPFile file =  currentWeb.Files[filePath];
        //            file.Item.Properties["fileUpdated"] = true;

        //            //file.Item.SystemUpdate();
        //            file.Update();
        //            //scanOPRLibrary.Update();
        //        }
        //    }
        //}

        //public static void ScanMergeDocuments(List<String> lstFiles, String fileName, String siteUrl)
        //{
        //    PdfReader reader = null;
        //    Document sourceDocument = null;
        //    PdfCopy pdfCopyProvider = null;
        //    //PdfImportedPage importedPage;
        //    string outputPdfPath = @"C:/Merge/" + fileName; //Merge Folder
        //    sourceDocument = new Document();
        //    pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));

        //    //Open the output file
        //    sourceDocument.Open();

        //    try
        //    {
        //        //Loop through the files list
        //        //int pages = 0;
        //        foreach (String file in lstFiles)
        //        {
        //            //pages = get_pageCcount(file, siteUrl);
        //            reader = new PdfReader(file);
        //            pdfCopyProvider.AddDocument(reader);
        //            //Add pages of current file
        //            //for (int i = 1; i <= pages; i++)
        //            //{
        //            //    importedPage = pdfCopyProvider.GetImportedPage(reader, i);
        //            //    pdfCopyProvider.AddPage(importedPage);
        //            //}
        //            reader.Close();
        //            reader.Dispose();
        //        }
        //        lstFiles.Clear();
        //        //At the end save the output file
        //        pdfCopyProvider.Dispose();
        //        sourceDocument.Close();
        //        //OverWrite merged document back to Scan OPR Document Library
        //        SaveScanMergedDocument(fileName, siteUrl);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        //public static void SaveScanMergedDocument(String fileName, String siteUrl)
        //{
        //    using (SPSite site = new SPSite(siteUrl)) //Dev Site
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
        //            String outputPdfPath = @"C:/Merge/" + fileName;
        //            Byte[] fileArrayMerge = File.ReadAllBytes(outputPdfPath);
        //            SPFile file = currentWeb.Files.Add(scanOPRLib.RootFolder + "/" + fileName, fileArrayMerge, true);
        //            file.Update();
        //            scanOPRLib.Update();

        //            ////Delete file from Merge Document Library
        //            DeleteFileFromScanMergeDocLib(siteUrl, fileName);
        //        }
        //    }
        //}

        //public static void DeleteFileFromScanMergeDocLib(String siteUrl, String fileName)
        //{
        //    using (SPSite site = new SPSite(siteUrl))
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //       { 
        //            SPFile file = currentWeb.GetFile(siteUrl + "/Scan Merge Doc/" + fileName);
        //            file.Delete();
        //        }
        //    }

        //    DeleteFileFromScanMergeDocLib(fileName);
        //}

        //public static void DeleteFileFromScanMergeDocLib(String fileName)
        //{
        //    //Delete file from Merge Document Library
        //    String networkFolderPath = @"C:/Merge";
        //    String[] files = Directory.GetFiles(networkFolderPath);
        //    foreach (String filePath in files)
        //    {
        //        if (filePath.Contains(fileName))
        //        {
        //            File.Delete(filePath);
        //        }
        //    }
        //}

        //private static int get_pageCcount(string fileUrl, String siteUrl)
        //{
        //    using (SPSite site = new SPSite(siteUrl)) //Dev Site - C
        //    {
        //        using (SPWeb web = site.OpenWeb())
        //        {
        //            SPFile file = web.GetFile(fileUrl);

        //            using (StreamReader sr = new StreamReader(file.OpenBinaryStream()))
        //            {
        //                Regex regex = new Regex(@"/Type\s*/Page[^s]");
        //                MatchCollection matches = regex.Matches(sr.ReadToEnd());

        //                return matches.Count;
        //            }
        //        }
        //    }
        //}
        #endregion

        #region "HPE List Attachment Merging"

        public void AttachDocumenttoList()
        {
            List<String> emailList = new List<String>();
            String EDSNumber = String.Empty;
            String filenamExt = String.Empty;
            String siteUrl = String.Empty;
            String networkScanOPRFolderPath = @"C:\HPE";
            //String networkScanOPRFolderPath = @"\\ms1gamftsftp\FiscalAgtIn";
            try
            {                
                WebClient client = new WebClient();
                client.Credentials = new NetworkCredential("MS-Medicaid\\svc.sp.appservice", "@this40r");
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
                siteUrl = currentWeb.Url;
                String[] HPEFiles = Directory.GetFiles(networkScanOPRFolderPath);
                HPEFiles = HPEFiles.Where(x => x.Contains(networkScanOPRFolderPath + "\\DXC-") && x.Contains(".pdf")).ToArray();
                foreach (String HPEFile in HPEFiles)
                {
                    byte[] fileArray = File.ReadAllBytes(HPEFile);
                    SPList HPEList = currentWeb.Lists["HPE"];
                    EDSNumber = HPEFile.Substring(HPEFile.LastIndexOf("\\") + 1);
                    EDSNumber = EDSNumber.Split('.')[0];
                    filenamExt = EDSNumber + ".pdf";
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                         "<Eq>" +
                                            "<FieldRef Name='EDS_Number'/>" +
                                            "<Value Type='Text'>" + EDSNumber + "</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = HPEList.GetItems(camlQuery);
                    List<String> lstFiles = new List<String>();
                    SPListItem item = null;
                    //Checks for files in the HPE list  and if matched then merges the folder file with list file and then updated the merged file in the list
                    //if no match found for the folder file in the list then it inserts new record into the list with folder file as an attachment,
                    if (itemColl.Count > 0)
                    {
                        SPAttachmentCollection attachCollection = itemColl[0].Attachments;
                        if (attachCollection.Count > 0)
                        {
                            String listFilePath = attachCollection.UrlPrefix + filenamExt;
                            //SPFile file = currentWeb.GetFile(listFilePath);

                            lstFiles.Add(HPEFile);
                            lstFiles.Add(listFilePath);
                            MergeDocuments(lstFiles, filenamExt, currentWeb, networkScanOPRFolderPath);
                        }
                        //Update merged file in to the List
                        String outputPdfPath = networkScanOPRFolderPath + "\\" + filenamExt;
                        String outputMergedPdfPath = networkScanOPRFolderPath + "\\1_" + filenamExt;

                        Byte[] mergedFileArray = File.ReadAllBytes(outputMergedPdfPath);
                        if (itemColl[0].Attachments.Count > 0)
                        {
                            SPAttachmentCollection attahCollection = itemColl[0].Attachments;
                            foreach (String fileAttachment in attahCollection)
                            {
                                itemColl[0].Attachments.DeleteNow(fileAttachment);
                                itemColl[0].Update();
                            }
                        }
                        item = itemColl[0];
                        item.Attachments.Add(filenamExt, mergedFileArray);
                        item.Update();

                        //Delete file from the File System
                        if (File.Exists(outputPdfPath) || File.Exists(outputMergedPdfPath))
                        {
                            File.Delete(outputPdfPath);
                            File.Delete(outputMergedPdfPath);
                        }
                    }
                    else
                    {
                        //String outputNewPdfPath = @"C:\HPE\" + filenamExt;
                        String outputNewPdfPath = networkScanOPRFolderPath + "\\" + filenamExt;

                        SPListItem listItem = HPEList.AddItem();
                        listItem["EDS_Number"] = EDSNumber;
                        listItem["Title"] = EDSNumber;
                        listItem.Attachments.Add(filenamExt, fileArray);
                        listItem.Update();
                        if (File.Exists(outputNewPdfPath))
                        {
                            File.Delete(outputNewPdfPath);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                emailList = GetEmailList(siteUrl);
                SendEmail(emailList, filenamExt);
                filenamExt = "1_" + filenamExt;
                DeleteFileFromScanMergeDocLib(filenamExt);
            }

        }

        private static int get_pageCcount(string fileUrl, SPWeb currentWeb)
        {
            Stream fileStream = null;
            //SPList HPEList = web.Lists["HPE"];
            if (fileUrl.Contains("FiscalAgent/director"))
            {
                SPFile file = currentWeb.GetFile(fileUrl);
                fileStream = file.OpenBinaryStream();
            }
            else
            {
                fileStream = File.OpenRead(fileUrl);
            }

            using (StreamReader sr = new StreamReader(fileStream))
            {
                Regex regex = new Regex(@"/Type\s*/Page[^s]");
                MatchCollection matches = regex.Matches(sr.ReadToEnd());

                return matches.Count;
            }
            //    }
            //}
        }

        public static void MergeDocuments(List<String> lstFiles, String fileName, SPWeb currentWeb, String networkScanOPRFolderPath)
        {
            PdfReader reader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage;
            string outputPdfPath = networkScanOPRFolderPath + "\\1_" + fileName;

            sourceDocument = new Document();
            pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));

            //Open the output file
            sourceDocument.Open();

            try
            {
                //Loop through the files list
                int pages = 0;
                foreach (String file in lstFiles)
                {
                    pages = get_pageCcount(file, currentWeb);
                    reader = new PdfReader(file);
                    //Add pages of current file
                    for (int i = 1; i <= pages; i++)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                lstFiles.Clear();
                //At the end save the output file
                pdfCopyProvider.Dispose();
                sourceDocument.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<String> GetEmailList(String siteUrl)
        {
            List<String> emailList = new List<String>();
            String emailAddress = String.Empty;
            using (SPSite currentSite = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = currentSite.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["DXCScanErrors"];
                    SPQuery camlQuery = new SPQuery();
                    SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);
                    if (itemColl != null && itemColl.Count > 0)
                    {
                        foreach (SPListItem item in itemColl)
                        {
                            emailAddress = Convert.ToString(item["Notification"]);
                            if (!String.IsNullOrEmpty(emailAddress))
                            {
                                emailAddress = emailAddress.Contains('#') ? emailAddress.Split('#')[1] : emailAddress;
                                emailList.Add(emailAddress);
                            }
                        }
                    }
                }
            }
            return emailList;

        }

        public static void SendEmail(List<String> emailToEmailAddress, String fileName)
        {
            try
            {
                String emailBody = String.Empty;
                String smtpServer = SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
                MailMessage mailMessage = new MailMessage();
                emailBody = "<div class='divContainer'>";
                emailBody += "<div><b>The scanned FA(s) below did not process. Please try again.</b></div><br/>";
                emailBody += "<div>" + fileName + "</div><br/>";
                foreach (String emailAddress in emailToEmailAddress)
                {
                    if (!String.IsNullOrEmpty(emailAddress))
                    {
                        mailMessage.To.Add(new MailAddress(emailAddress));
                    }
                }
                mailMessage.From = new MailAddress("no-reply@medicaid.alabama.gov");
                mailMessage.Subject = "Scanned FAs - Error";
                mailMessage.Body = emailBody;
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

    }
}
