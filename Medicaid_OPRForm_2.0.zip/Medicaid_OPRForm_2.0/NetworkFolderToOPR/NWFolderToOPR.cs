﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using itextSharpText = iTextSharp.text;
using System.Text.RegularExpressions;
using iTextSharp.text;
using System.Data;
using System.Net;
using System.Net.Mail;

namespace NetworkFolderToOPR
{
    class NWFolderToOPR : SPJobDefinition
    {

        public NWFolderToOPR() : base() { }


        string siteCollectionUrl = String.Empty;
        public NWFolderToOPR(SPWebApplication webApp)
            : base("TimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "TimerJob";
        }

        public NWFolderToOPR(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public NWFolderToOPR(string jobName, SPWebApplication webApplication, SPServer server, SPJobLockType targetType)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            //Network Folder to Scan OPR Doc Library
            NetwrokFolderToLibrary();

            //Scan OPR Library to Network Folder
            ScanLibraryToNetwrokFolder();
        }

        public void NetwrokFolderToLibrary()
        {
           //  String networkFolderPath = @"\\ms1gamftsftp\FiscalAgtIn";
            String networkFolderPath = @"C:\HPE";
            WebClient client = new WebClient();
            client.Credentials = new NetworkCredential("MS-Medicaid\\svc.sp.appservice", "@this40r");

            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
            String[] OPRDocuments = Directory.GetFiles(networkFolderPath);
            OPRDocuments = OPRDocuments.Where(x => x.StartsWith("OPR-")).ToArray();
            List<String> lstFiles = new List<String>();
            String fileName = String.Empty;
            String filePath = String.Empty;
            foreach (String OPRDocument in OPRDocuments)
            {

                SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
                String OPRNumber = OPRDocument.Substring(OPRDocument.LastIndexOf("\\") + 1);
                OPRNumber = OPRNumber.Split('.')[0];
                String OPRFileName = OPRNumber + ".pdf";
                SPQuery camlQuery = new SPQuery();
                camlQuery.Query = "<Where>" +
                                     "<Eq>" +
                                        "<FieldRef Name='LinkFilename'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                        "<Value Type='Text'>" + OPRFileName + "</Value>" +
                                      "</Eq>" +
                                  "</Where>";
                SPListItemCollection itemColl = scanOPRLibrary.GetItems(camlQuery);

                if (itemColl.Count > 0)
                {
                    foreach (SPListItem item in itemColl)
                    {
                        fileName = item.File.Name;
                        filePath = currentWeb.Site.Url + "/director/Scan%20OPR/" + fileName;
                        lstFiles.Add(filePath);
                        lstFiles.Add(OPRDocument);
                        MergeDocuments(lstFiles, fileName, networkFolderPath, currentWeb);
                    }
                }
            }
        }

        public static void MergeDocuments(List<String> lstFiles, String fileName, String networkFolderPath, SPWeb currentWeb)
        {
            PdfReader reader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage;
            string outputPdfPath = networkFolderPath + "\\1_" + fileName;
            sourceDocument = new Document();
            pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));

            //Open the output file
            sourceDocument.Open();

            try
            {
                //Loop through the files list
                int pages = 0;
                foreach (String file in lstFiles)
                {
                    pages = get_pageCcount(file, networkFolderPath, currentWeb);
                    reader = new PdfReader(file);
                    //Add pages of current file
                    for (int i = 1; i <= pages; i++)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                lstFiles.Clear();
                //At the end save the output file
                pdfCopyProvider.Dispose();
                sourceDocument.Close();
                //OverWrite merged document back to Scan OPR Document Library
                SaveMergedDocument(fileName, currentWeb, networkFolderPath);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static int get_pageCcount(String fileUrl, String networkFolderPath, SPWeb currentWeb)
        {
            MatchCollection matches = null;
            if (fileUrl.Contains(networkFolderPath))
            {
                using (StreamReader sr = new StreamReader(fileUrl))
                {
                    Regex regex = new Regex(@"/Type\s*/Page[^s]");
                    matches = regex.Matches(sr.ReadToEnd());
                    // MatchCollection matches = regex.Matches(sr.ReadToEnd());

                    //return matches.Count;
                }
            }
            else
            {
                SPFile file = currentWeb.GetFile(fileUrl);
                using (StreamReader sr = new StreamReader(file.OpenBinaryStream()))
                {
                    Regex regex = new Regex(@"/Type\s*/Page[^s]");
                    matches = regex.Matches(sr.ReadToEnd());
                    //MatchCollection matches = regex.Matches(sr.ReadToEnd());

                    //return matches.Count;
                }

            }
            return matches.Count; ;
        }

        public static void SaveMergedDocument(String fileName, SPWeb currentWeb, String networkFolderPath)
        {
            SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
            String outputPdfPath = networkFolderPath + "\\1_" + fileName;
            Byte[] fileArray = File.ReadAllBytes(outputPdfPath);
            SPFile file = currentWeb.Files.Add(scanOPRLibrary.RootFolder + "/" + fileName, fileArray, true);
            scanOPRLibrary.Update();

            //Delete file from Merge Document Library
            String[] files = Directory.GetFiles(networkFolderPath);
            foreach (String filePath in files)
            {
                if (filePath.Contains(fileName))
                {
                    File.Delete(filePath);
                }
            }
        }

        public void ScanLibraryToNetwrokFolder()
        {
             String networkScanOPRFolderPath = @"C:\OPR";
          //  String networkScanOPRFolderPath = @"\\ms1gamftsftp\FiscalAgtRelay";
            WebClient client = new WebClient();
            client.Credentials = new NetworkCredential("MS-Medicaid\\svc.sp.appservice", "@this40r");
            
            DateTime requestedDate = DateTime.Now;
            String fromDate = String.Empty;
            String toDate = String.Empty;
            String OPRNumber = String.Empty;
            String OPRType = String.Empty;
            String OPRSubType = String.Empty;
            String docFilePath = String.Empty;
            String destFolderPath = String.Empty;
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
            SPList scanList = currentWeb.Lists["Scan List"];
            SPQuery query = new SPQuery();
            SPListItemCollection listColl = scanList.GetItems(query);

           

            if (listColl != null)
            {
                DataRow[] dataRows = listColl.GetDataTable().Select();

                if ((requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Hour >= 15))
                {
                    fromDate = requestedDate.Date.ToShortDateString();
                    toDate = requestedDate.AddDays(1).ToShortDateString();
                }
                else
                {
                    if (Convert.ToString(DateTime.Now.DayOfWeek) == "Monday")   //Check for next business day
                    {
                        fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                        toDate = requestedDate.AddDays(1).ToShortDateString();
                    }
                    else
                    {
                        fromDate = requestedDate.AddDays(-1).ToShortDateString();
                        toDate = requestedDate.ToShortDateString();
                    }

                }

                var SacnListColl = dataRows.Where(s => (Convert.ToString(s["PickUp"]) == "No" && (Convert.ToDateTime(s["Modified"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Modified"]) <= DateTime.Parse(toDate + " 14:30:00")))
                                                            && ((Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved")
                                                            || (Convert.ToString(s["OPRStatus"]) == "Completed" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved")
                                                            || (Convert.ToString(s["OPRStatus"]) == "Cancelled")));
                if (SacnListColl.Count() > 0)
                {
                    foreach (DataRow item in SacnListColl)
                    {
                        OPRNumber = Convert.ToString(item["OPR_Test"]);
                        OPRType = Convert.ToString(item["OPRType"]);
                        OPRSubType = Convert.ToString(item["OPRSubType"]);
                        docFilePath = currentWeb.Site.Url + "/director/Scan%20OPR/" + OPRNumber + ".pdf";
                        SPFile file = currentWeb.GetFile(docFilePath);
                        byte[] byteStream = file.OpenBinary();
                        if (OPRType != null && OPRSubType != null)
                        {
                            destFolderPath = networkScanOPRFolderPath + "/" + Regex.Replace(OPRType, @"\s+", "") + "/" + Regex.Replace(OPRSubType, @"\s+", "") + "/" + OPRNumber + ".pdf";
                        }
                        else
                        {
                            destFolderPath = networkScanOPRFolderPath + "/" + Regex.Replace(OPRType, @"\s+", "") + "/" + OPRNumber + ".pdf";
                        }

                        
                        Stream fileStream = new System.IO.FileStream(destFolderPath, FileMode.Create);
                        BinaryWriter binaryWriter = new System.IO.BinaryWriter(fileStream);
                        binaryWriter.Write(byteStream);
                        binaryWriter.Close();
                        
                        //Drop meta data text file
                        String outputFilePath = networkScanOPRFolderPath + "/" + OPRNumber + ".txt";

                        String author = Convert.ToString(item["AuthorOPR"]);
                        String OPRSubject = Convert.ToString(item["OPRSubject"]);
                        String HPE = Convert.ToString(item["HP_OPR"]);
                        String OPRstatus = Convert.ToString(item["OPRStatus"]);
                        
                        StreamWriter sw = new StreamWriter(outputFilePath);
                        //character length for each field 15 30 150 20 10 10 
                        //sw.WriteLine(OPRNumber);
                        //sw.WriteLine(author);
                        //sw.WriteLine(OPRSubject);
                        //sw.WriteLine(OPRType);
                        //sw.WriteLine(HPE);
                        //sw.WriteLine(OPRstatus);
                        
                        sw.WriteLine("{0}\n{1}\n{2}\n{3}\n{4}\n{5}", OPRNumber.PadRight(10), author.PadRight(30), OPRSubject.PadRight(150), OPRType.PadRight(20), HPE.PadRight(10), OPRstatus.PadRight(10));
                        sw.Close();

                    }
                }
            }
        }



    }
}
