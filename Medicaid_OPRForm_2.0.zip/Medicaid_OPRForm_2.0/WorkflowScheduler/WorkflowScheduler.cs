﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint;
using System.Collections.Specialized;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;
using System.Data;
using System.IO;
using System.Net;

namespace WorkflowScheduler
{
    class WorkflowScheduler: SPJobDefinition
    {
         public WorkflowScheduler() : base() { }

        public WorkflowScheduler(SPWebApplication webApp)
            : base("TimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "TimerJob";           
        }

        public WorkflowScheduler(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public WorkflowScheduler(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            SPWebApplication webApp = this.Parent as SPWebApplication;
            using (SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["Director"])
            {
                SPList errorLogList = currentWeb.Lists["ErrorLog"];
                try
                {
                    GetPendingOPRs(currentWeb, errorLogList);
                }
                catch (Exception ex)
                {
                    SPListItem errorItem = errorLogList.AddItem();
                    errorItem["Title"] = "WorkflowScheduler - Execute: " + ex.Message;
                }
            }
        }

        public void GetPendingOPRs(SPWeb currentWeb, SPList errorLogList)
        {
            SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
            SPQuery camlQuery = new SPQuery();
            camlQuery.Query = "<Where>" +
                                 "<And>" +
                                 "<Eq>" +
                                    "<FieldRef Name='fileUpdated'/>" +   //Is FileUpdated 'Yes'?
                                    "<Value Type='Boolean'>1</Value>" +
                                  "</Eq>" +
                                  "<Eq>" +
                                    "<FieldRef Name='EmailSent'/>" +   //EmailSent 'No'
                                    "<Value Type='Boolean'>0</Value>" +
                                  "</Eq>" +
                                   "</And>" +
                              "</Where>";
            SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);
            //item["test"] = itemColl.Count + " - " + camlQuery.Query;
            //item.Update();
            String approverBody = string.Empty;
            String typistBody = string.Empty;
            if (itemColl != null && itemColl.Count > 0)
            {
                DataRow[] emailListArray = itemColl.GetDataTable().Select();
                var pendingItems = emailListArray.Where(s => Convert.ToString(s["Status"]) == "PENDING" && String.IsNullOrEmpty(Convert.ToString(s["ApprovalStatus"]))).ToList(); //New OPRs - Approver//Null or Empty is the new condition
                var reSubmittedItems = emailListArray.Where(s => Convert.ToString(s["ApprovalStatus"]) == "Resubmitted").ToList(); //Resubmitted OPRs -Approver
                var approverApprovedItems = emailListArray.Where(s => Convert.ToString(s["ApprovalStatus"]) == "Approver Approved").ToList(); //Approved OPRs - Typist
                var approverRejectedItems = emailListArray.Where(s => Convert.ToString(s["ApprovalStatus"]) == "Approver Rejected").ToList(); //Rejected OPRs - Typist

                String siteUrl = currentWeb.Site.Url;
                String libraryURL = String.Empty; //siteUrl + "/director/Scan%20OPR/";
                String workflowURL = siteUrl + "/director/SitePages/Workflow.aspx";
                String OPRGridURL = siteUrl + "/director/SitePages/OPR%20Grid.aspx";
                Boolean approverItemsExist = false;
                Boolean typistItemsExist = false;
                String approverEmail = String.Empty;
                
                String typistEmail = String.Empty;
                List<Int32> OPRIDList = new List<Int32>();
                String OPR_Number = String.Empty;
                List<String> approverEmailList = new List<String>();
                List<String> typistEmailList = new List<String>();
                approverBody = "<div class='divContainer'>";
                approverBody += "<div><b>Hi,<br/> Please find all the assigned OPRs below</b></div><br/>";
                approverBody += "<div><b><I>Pending OPRs:</I></b><br/></div><br/>";
                if (pendingItems.Count > 0)
                {
                    approverItemsExist = true;
                    foreach (var pendingItem in pendingItems)
                    {
                        libraryURL = siteUrl + "/director/Scan%20OPR/";
                        OPRIDList.Add(Convert.ToInt32(pendingItem["ID"]));
                        approverEmail = Convert.ToString(pendingItem["ApproverEmail"]);
                        
                        if (approverEmailList.Count==0 || !approverEmailList.Contains(approverEmail))
                        {
                            approverEmailList.Add(approverEmail);
                            String approverEmail2 = String.Empty;
                            SPList ApproverList = currentWeb.Lists["OPR Approvers"];
                            camlQuery = new SPQuery();
                            camlQuery.Query = "<Where>" +
                                                 "<Eq>" +
                                                    "<FieldRef Name='Email'/>" +  
                                                    "<Value Type='Text'>" + approverEmail + "</Value>" +
                                                  "</Eq>" +
                                              "</Where>";
                            try
                            {
                                approverEmail2 = ApproverList.GetItems(camlQuery)[0]["BackupApprover"].ToString();
                            }
                            finally
                            {
                                if(approverEmail2 != string.Empty && !approverEmailList.Contains(approverEmail2)) approverEmailList.Add(approverEmail2);
                            }
                        }                       
                        OPR_Number = Convert.ToString(pendingItem["LinkFilename"]).Split('.')[0];
                        libraryURL = libraryURL + Convert.ToString(pendingItem["LinkFilename"]);
                        approverBody += "<div class='divOPRLink'><a href=" + libraryURL + " target='_blank'>" + OPR_Number + "</a></div><br/>";
                    }
                }
                if (reSubmittedItems.Count > 0)
                {
                    approverBody += "<div><b><I>Resubmitted OPRs:</I></b><br/></div><br/>";
                    approverItemsExist = true;
                    foreach (var reSubmittedItem in reSubmittedItems)
                    {
                        libraryURL = siteUrl + "/director/Scan%20OPR/";
                        OPRIDList.Add(Convert.ToInt32(reSubmittedItem["ID"]));
                        approverEmail = Convert.ToString(reSubmittedItem["ApproverEmail"]);
                        
                        if (approverEmailList.Count == 0 || !approverEmailList.Contains(approverEmail))
                        {
                            approverEmailList.Add(approverEmail);
                            String approverEmail2 = String.Empty;
                            SPList ApproverList = currentWeb.Lists["OPR Approvers"];
                            camlQuery = new SPQuery();
                            camlQuery.Query = "<Where>" +
                                                 "<Eq>" +
                                                    "<FieldRef Name='Email'/>" +
                                                    "<Value Type='Text'>" + approverEmail + "</Value>" +
                                                  "</Eq>" +
                                              "</Where>";
                            try
                            {
                                approverEmail2 = ApproverList.GetItems(camlQuery)[0]["BackupApprover"].ToString();
                            }
                            finally
                            {
                                if (approverEmail2 != string.Empty && !approverEmailList.Contains(approverEmail2)) approverEmailList.Add(approverEmail2);
                            }
                        }
                        OPR_Number = Convert.ToString(reSubmittedItem["LinkFilename"]).Split('.')[0];
                        libraryURL = libraryURL + Convert.ToString(reSubmittedItem["LinkFilename"]);
                        approverBody += "<div class='divOPRLink'><a href=" + libraryURL + " target='_blank'>" + OPR_Number + "</a></div><br/>";
                    }
                }
                approverBody += "<div class='divMessage'><a href=" + workflowURL + ">Click here to proceed</a></div>";
                approverBody += "</div>";

                typistBody = "<div class='divContainer'>";
                typistBody += "<div>Hi,<br/> Please find the below actions related to submitted OPRs</div><br/>";
                if (approverApprovedItems.Count > 0)
                {
                    typistBody += "<div><b>Approved OPRs:</b><br/></div><br/>";
                    typistItemsExist = true;
                    foreach (var approverApprovedItem in approverApprovedItems)
                    {
                        libraryURL = siteUrl + "/director/Scan%20OPR/";
                        OPRIDList.Add(Convert.ToInt32(approverApprovedItem["ID"]));
                        OPR_Number = Convert.ToString(approverApprovedItem["LinkFilename"]).Split('.')[0];
                        typistEmail = Convert.ToString(approverApprovedItem["TypistEmail"]);
                        if (typistEmailList.Count == 0 || !typistEmailList.Contains(typistEmail))
                        {
                            typistEmailList.Add(typistEmail);
                        }
                        libraryURL = libraryURL + Convert.ToString(approverApprovedItem["LinkFilename"]);
                        typistBody += "<div class='divOPRLink'><a href=" + libraryURL + " target='_blank'>" + OPR_Number + "</a> </div><br/>";
                    }
                }
                if (approverRejectedItems.Count > 0)
                {
                    typistBody += "<div>Rejected OPRs:<br/></div><br/>";
                    typistItemsExist = true;
                    foreach (var approverRejectedItem in approverRejectedItems)
                    {
                        libraryURL = siteUrl + "/director/Scan%20OPR/";
                        OPRIDList.Add(Convert.ToInt32(approverRejectedItem["ID"]));
                        OPR_Number = Convert.ToString(approverRejectedItem["LinkFilename"]).Split('.')[0];
                        typistEmail = Convert.ToString(approverRejectedItem["TypistEmail"]);
                        if (typistEmailList.Count == 0 || !typistEmailList.Contains(typistEmail))
                        {
                            typistEmailList.Add(typistEmail);
                        }
                        libraryURL = libraryURL + Convert.ToString(approverRejectedItem["LinkFilename"]);
                        typistBody += "<div class='divOPRLink'><a href=" + libraryURL + " target='_blank'>" + OPR_Number + "</a></div><br/>";
                    }
                }
                typistBody += "<div class='divMessage'><b>NOTE: <I>On the Rejected OPRs, make necessary changes and <a href=" + OPRGridURL + ">resubmit</a> them</a></I></b></div>";
                typistBody += "</div>";
                if (approverItemsExist)
                {
                    try
                    {
                        SendEmail(approverEmailList, approverBody, "OPR-Approvals"); //Commented out for Testing purpose
                    }
                    catch(Exception ex)
                    {
                        SPListItem errorItem = errorLogList.AddItem();
                        errorItem["Title"] = "WorkflowScheduler - Approver sendmail error: " + ex.Message;
                        errorItem.Update();
                    }
                }
                if (typistItemsExist)
                {
                    try { 
                    SendEmail(typistEmailList, typistBody, "OPRs-Approval Status"); //Commented out for Testing purpose
                    }
                    catch (Exception ex)
                    {
                        SPListItem errorItem = errorLogList.AddItem();
                        errorItem["Title"] = "WorkflowScheduler - Typist sendmail error: " + ex.Message;
                        errorItem.Update();
                    }
                }
                //Change EmailStatus to true once email is sent
                if (OPRIDList.Count > 0)
                {
                    UpdateEmailStatus(OPRIDList);
                }
            }
        }

        public void SendEmail(List<String> emailToEmailAddress, String emailBody, String emailSubject)
        {
                String smtpServer = SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
                //String smtpServer = "10.131.89.54";
                MailMessage mailMessage = new MailMessage();
                foreach (String emailAddress in emailToEmailAddress)
                {
                    if (!String.IsNullOrEmpty(emailAddress))
                    {
                        mailMessage.To.Add(new MailAddress(emailAddress));
                    }
                }
                mailMessage.From = new MailAddress("no-reply@medicaid.alabama.gov");
                mailMessage.Subject = emailSubject;
                mailMessage.Body = emailBody;
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.Send(mailMessage);
        }

        public void UpdateEmailStatus(List<Int32> OPRIDList)
        {
            foreach (Int32 OPRID in OPRIDList)
            {
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
                SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
                SPListItem scanListItem = scanOPRLib.GetItemById(OPRID);
                SPFile file = scanListItem.File;
                file.Item.Properties["EmailSent"] = true;
                file.Item.SystemUpdate();
                file.Update();
                scanOPRLib.Update();
            }
        }
    }
}
