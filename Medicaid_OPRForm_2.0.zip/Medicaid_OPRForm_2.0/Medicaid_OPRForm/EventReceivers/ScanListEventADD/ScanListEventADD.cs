// <copyright file="ScanListEventADD.cs" company="Company">
// Copyright Company. All rights reserved.
// </copyright>
// <author>SPDEV\txrapaka</author>
// <date>2016-09-06 20:45:00Z</date>
namespace Medicaid_OPRForm
{
    using System;
    using System.Collections.Generic;
    using System.Security.Permissions;
    using System.Text;
    using Microsoft.SharePoint;
    using Microsoft.SharePoint.Security;
    using System.Web;
    using iTextSharp.text.pdf;
    using itextSharpText = iTextSharp.text;
    using System.IO;
    using System.Text.RegularExpressions;
    using iTextSharp.text;

    /// <summary>
    /// TODO: Add comment for ScanListEventADD
    /// </summary>C:\Users\txrapaka\Documents\Visual Studio 2013\Projects\Medicaid_OPRForm\Medicaid_OPRForm\EventReceivers\AddPDF\
    public class ScanListEventADD : SPItemEventReceiver
    {
       
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemAdded(SPItemEventProperties properties)
        {
            try
            {
                EventFiringEnabled = false;
                String siteUrl = properties.WebUrl;
                SPListItem listItem = properties.ListItem;
                listItem["OPRMessage"] = "add";
                listItem.Update();
                GeneratePDF(listItem, siteUrl, "Add");
            }
            catch (Exception ex)
            {
                properties.ListItem["Error"] = ex.Message;
                properties.ListItem.Update();
            }
            finally
            {
                EventFiringEnabled = true;
            }
        }
        
        /// <summary>
        /// TODO: Add comment for event ItemUpdated in ScanListEventADD 
        /// </summary>
        /// <param name="properties">Contains list event properties</param>   
        [SharePointPermission(SecurityAction.LinkDemand, ObjectModel = true)]
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            try
            {
                EventFiringEnabled = false;
                properties.ListItem["OPRMessage"] = "Resubmit";
                properties.ListItem.Update();
                ////Add code for event ItemUpdated in ScanListEventADD 

                String siteUrl = properties.WebUrl;
                SPListItem listItem = properties.ListItem;

                //UpdatePDF(listItem);
                //String subject1 = Convert.ToString(listItem["OPRType"]);
                //String OPRsubject = Convert.ToString(listItem["OPRSubject"]);
                String approvalStatus = Convert.ToString(listItem["ApprovalStatus"]);
                String reSubmit = Convert.ToString(listItem["Resubmit"]);
                //String OPRStatus = Convert.ToString(listItem["OPRStatus"]);
                if (approvalStatus != "Proofer Approved" && approvalStatus != "Approver Approved") //If Status is Cancelled, then dont update PDF
                {
                    GeneratePDF(listItem, siteUrl, reSubmit); //Disable on Data Migration
                }
            }
            catch(Exception ex)
            {
                properties.ListItem["OPRMessage"] = "Resubmit";
                properties.ListItem.Update();
            }
            finally
            {
              EventFiringEnabled = true;
            }
        }
        
        public static void DeleteFileFromMergeDocLib(SPListItem listItem)
        {

            //using (SPSite site = new SPSite("http://sp13dev:32120/teams/FiscalAgent/director/"))
            using (SPSite site = new SPSite(SPContext.Current.Site.Url + "/director/"))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    String fileName = Convert.ToString(listItem["OPR_Test"] + ".pdf");
                    SPList scanMergeOPRLibrary = currentWeb.Lists["Scan Merge Doc"];
                    SPFolder folder =  currentWeb.Folders["Scan Merge Doc"];
                    SPFile file = folder.Files[fileName];
                    file.Delete();
                }
            }
        }

        //public static void GeneratePDF(SPListItem listItem, String siteUrl, String subject1, String OPRsubject, String reSubmit, String OPRStatus)
        public static void GeneratePDF(SPListItem listItem, String siteUrl, String reSubmit)
        {
           
            iTextSharp.text.Font boldHeaderfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font contentFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.NORMAL);
            iTextSharp.text.Font HPNumberFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 16, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font boldfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.HELVETICA, 10, iTextSharp.text.Font.BOLD);
            var document = new itextSharpText.Document(itextSharpText.PageSize.A4, 10, 10, 25, 25);
            var outputMemory = new MemoryStream();
            var pdfWriter = PdfWriter.GetInstance(document, outputMemory);
            var Font = boldfont;
            document.Open();
           
            PdfContentByte pdfContentByte = pdfWriter.DirectContent;
            pdfContentByte.SetLineWidth(1.0f);
            pdfContentByte.MoveTo(10, document.Bottom - 10f);
            //pdfContentByte.LineTo(580, document.Bottom - 10f); Bottom line in PDF
            pdfContentByte.Stroke();
           
            itextSharpText.Paragraph headerFirst = new itextSharpText.Paragraph("FISCAL AGENT LIAISON OFFICE", boldHeaderfont);

            headerFirst.Alignment = itextSharpText.Element.ALIGN_CENTER;
            headerFirst.SpacingAfter = 10f;
            document.Add(headerFirst);
            itextSharpText.Paragraph headerSecond = new itextSharpText.Paragraph("CORRESPONDENCE TRACKING FORM", boldHeaderfont);
            headerSecond.Alignment = itextSharpText.Element.ALIGN_CENTER;
            headerSecond.SpacingAfter = 10f;
            document.Add(headerSecond);
           
            PdfPTable parentTable = new PdfPTable(1);
            //parentTable.DefaultCell.BorderWidthBottom = 0;

            PdfPTable firstable = new PdfPTable(3);
            firstable.DefaultCell.Border = 0;
            PdfPTable SDNTable = new PdfPTable(1);
            SDNTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            //itextSharpText.Phrase statePhrase = new itextSharpText.Phrase("STATE DOCUMENT NUMBER", boldfont);
            SDNTable.AddCell(new itextSharpText.Phrase("STATE DOCUMENT NUMBER", boldfont));
            SDNTable.AddCell("" + Environment.NewLine);
            String OPRNumber = Convert.ToString(listItem["OPR_Test"]);
            SDNTable.AddCell(new itextSharpText.Phrase(OPRNumber, HPNumberFont));
            firstable.AddCell(SDNTable);

            PdfPTable AuthorTable = new PdfPTable(1);
            AuthorTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            AuthorTable.AddCell(new itextSharpText.Phrase("AUTHOR", boldfont));
            AuthorTable.AddCell("" + Environment.NewLine);
            String AuthorOPR = Convert.ToString(listItem["AuthorOPR"]);
            AuthorTable.AddCell(new itextSharpText.Phrase(AuthorOPR, contentFont));
            String Approver = Convert.ToString(listItem["Approver"]);
            AuthorTable.AddCell(new itextSharpText.Phrase(Approver, contentFont));
            firstable.AddCell(AuthorTable);
            PdfPTable DOLTable = new PdfPTable(1);
            DOLTable.DefaultCell.Border = 0;
            DOLTable.AddCell(new itextSharpText.Phrase("DATE OF LETTER", boldfont));
            DOLTable.AddCell("" + Environment.NewLine);
            String OPRDate = Convert.ToDateTime(listItem["OPR_Date"]).ToShortDateString();
            DOLTable.AddCell(new itextSharpText.Phrase(OPRDate, contentFont));
            firstable.AddCell(DOLTable);
            parentTable.AddCell(firstable);
            PdfPTable secondtable = new PdfPTable(3);
            secondtable.DefaultCell.Border = 0;
            PdfPTable SubjectTable = new PdfPTable(1);
            SubjectTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            SubjectTable.AddCell(new itextSharpText.Phrase("SUBJECT", boldfont));
            SubjectTable.AddCell("");
            String OPRType = Convert.ToString(listItem["OPRType"]);
            SubjectTable.AddCell(new itextSharpText.Phrase(OPRType, contentFont));
            String OPRSubType = Convert.ToString(listItem["OPRSubType"]);
            SubjectTable.AddCell(new itextSharpText.Phrase(OPRSubType, contentFont));
            String OPRSubject = Convert.ToString(listItem["OPRSubject"]);
            SubjectTable.AddCell(new itextSharpText.Phrase(OPRSubject, contentFont));
            secondtable.AddCell(SubjectTable);

            PdfPTable HPNTable = new PdfPTable(1);
            HPNTable.HorizontalAlignment = itextSharpText.Element.ALIGN_CENTER;
            HPNTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            HPNTable.AddCell(new itextSharpText.Phrase("FA DOCUMENT #", boldfont));
            HPNTable.AddCell("" + Environment.NewLine);
            string HPNumber = Convert.ToString(listItem["HP_OPR"]);
            HPNTable.AddCell(new itextSharpText.Phrase(HPNumber, HPNumberFont));
            secondtable.AddCell(HPNTable);
            PdfPTable ActionTable = new PdfPTable(1);
            ActionTable.DefaultCell.Border = 0;
            ActionTable.AddCell(new itextSharpText.Phrase("ACTION", boldfont));
            ActionTable.AddCell("" + Environment.NewLine);
            ActionTable.AddCell("");
            String ActionOPR = Convert.ToString(listItem["Action_OPR"]);
            ActionTable.AddCell(new itextSharpText.Phrase(ActionOPR, contentFont));
            String OtherAction = Convert.ToString(listItem["Other_Action"]);
            ActionTable.AddCell(new itextSharpText.Phrase(OtherAction, contentFont));
            secondtable.AddCell(ActionTable);

            parentTable.AddCell(secondtable);

            PdfPTable thirdTable = new PdfPTable(3);
            thirdTable.DefaultCell.Border = 0;
            PdfPTable directedToTable = new PdfPTable(1);
            directedToTable.DefaultCell.Border = 0;
            directedToTable.AddCell(new itextSharpText.Phrase("ROUTE TO:", boldfont));
            directedToTable.AddCell("" + Environment.NewLine);
            directedToTable.AddCell("");
            thirdTable.AddCell(directedToTable);

            PdfPTable receivedByTable = new PdfPTable(1);
            receivedByTable.DefaultCell.Border = 0;
            receivedByTable.AddCell("DATE");
            receivedByTable.AddCell("");
            thirdTable.AddCell(receivedByTable);

            parentTable.AddCell(thirdTable);

            PdfPTable DirectedTOTable = new PdfPTable(2);
            DirectedTOTable.DefaultCell.Border = 0;
            PdfPTable DirectedTable = new PdfPTable(1);
            DirectedTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            DirectedTable.AddCell(new itextSharpText.Phrase("DIRECTED TO:", boldfont));
            String DirectTO = Convert.ToString(listItem["DirectTO"]);
            DirectedTable.AddCell(new itextSharpText.Phrase(DirectTO, contentFont));
            DirectedTable.AddCell("" + Environment.NewLine);
            DirectedTable.AddCell("");
            DirectedTable.AddCell(new itextSharpText.Phrase("ATTENTION:", boldfont));
            DirectedTable.AddCell("");
            String Attn = Convert.ToString(listItem["Attn"]);
            DirectedTable.AddCell(new itextSharpText.Phrase(Attn, contentFont));
            DirectedTOTable.AddCell(DirectedTable);

            PdfPTable ReceivedTable = new PdfPTable(1);
            ReceivedTable.DefaultCell.Border = 0;
            ReceivedTable.AddCell(new itextSharpText.Phrase("RECEIVED BY (PLEASE SIGN)", boldfont));
            ReceivedTable.AddCell("" + Environment.NewLine);
            String ReceivedBy = Convert.ToString(listItem["ReceivedBy"]);
            ReceivedTable.AddCell(new itextSharpText.Phrase(ReceivedBy, contentFont));
            ReceivedTable.AddCell("___________________________" + Environment.NewLine);
            ReceivedTable.AddCell("");
            ReceivedTable.AddCell("");
            ReceivedTable.AddCell("" + Environment.NewLine);
            ReceivedTable.AddCell("DATE:______________________" + Environment.NewLine);
            DirectedTOTable.AddCell(ReceivedTable);

            parentTable.AddCell(DirectedTOTable);

            PdfPTable MessageActionTable = new PdfPTable(1);
            MessageActionTable.DefaultCell.Border = 0;
            MessageActionTable.AddCell(new itextSharpText.Phrase("MESSAGE/ACTION TO TAKE", boldfont));
            MessageActionTable.AddCell("");
            String OPRMessage = Convert.ToString(listItem["OPRMessage"]);
            MessageActionTable.AddCell(new itextSharpText.Phrase(OPRMessage, contentFont));
            MessageActionTable.AddCell("" + Environment.NewLine);
            MessageActionTable.AddCell("ACTION MUST BE TAKEN BY" + Environment.NewLine);
            String DateofActionOPR = String.IsNullOrEmpty(Convert.ToString(listItem["DateofActionOPR"])) ? (Convert.ToBoolean(listItem["SeeMemo"]) ? "See Memo" : String.Empty) :
                                                            Convert.ToDateTime(listItem["DateofActionOPR"]).ToShortDateString();    //SeeMemo is the New field
            MessageActionTable.AddCell(new itextSharpText.Phrase(DateofActionOPR, contentFont));
            //FinancialOPR - commented out cause of DateofActionOPR - DateofActionOPR is same for FinancialOPR
            //String FinancialOPR = Convert.ToString(listItem["FinancialOPR"]); //
            //MessageActionTable.AddCell(new itextSharpText.Phrase(FinancialOPR, contentFont));
            String FinancialSeeMemo = Convert.ToString(listItem["FinancialSeeMemo"]);
            MessageActionTable.AddCell(new itextSharpText.Phrase(FinancialSeeMemo, contentFont));
            parentTable.AddCell(MessageActionTable);

            PdfPTable reqCoordinatedTable = new PdfPTable(1);
            reqCoordinatedTable.DefaultCell.Border = 0;
            reqCoordinatedTable.AddCell(new itextSharpText.Phrase("REQUEST SHOULD BE COORDINATED WITH ", boldfont));
            reqCoordinatedTable.AddCell("" + Environment.NewLine);
            String ReqCoordination = Convert.ToString(listItem["ReqCoordination"]);
            reqCoordinatedTable.AddCell(new itextSharpText.Phrase(ReqCoordination, contentFont));
            parentTable.AddCell(reqCoordinatedTable);

            PdfPTable routToParent1Table = new PdfPTable(2);
            routToParent1Table.DefaultCell.Border = 0;
            PdfPTable routTO1Table = new PdfPTable(1);
            routTO1Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO1Table.AddCell(new itextSharpText.Phrase("ROUTE TO:", boldfont));
            routTO1Table.AddCell("" + Environment.NewLine);
            routTO1Table.AddCell("");
            routTO1Table.AddCell("");
            routTO1Table.AddCell("");
            routToParent1Table.AddCell(routTO1Table);

            PdfPTable date1Table = new PdfPTable(1);
            date1Table.DefaultCell.Border = 0;
            date1Table.AddCell(new itextSharpText.Phrase("DATE", boldfont));
            date1Table.AddCell("");
            date1Table.AddCell("");
            routToParent1Table.AddCell(date1Table);

            parentTable.AddCell(routToParent1Table);

            PdfPTable routToParent2Table = new PdfPTable(2);
            routToParent2Table.DefaultCell.Border = 0;
            PdfPTable routTO2Table = new PdfPTable(1);
            routTO2Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO2Table.AddCell(new itextSharpText.Phrase("ROUTE TO:", boldfont));
            routTO2Table.AddCell("" + Environment.NewLine);
            routTO2Table.AddCell("");
            routTO2Table.AddCell("");
            routToParent2Table.AddCell(routTO2Table);

            PdfPTable date2Table = new PdfPTable(1);
            date2Table.DefaultCell.Border = 0;
            date2Table.AddCell(new itextSharpText.Phrase("DATE", boldfont));
            date2Table.AddCell("" + Environment.NewLine);
            date2Table.AddCell("");
            routToParent2Table.AddCell(date2Table);

            parentTable.AddCell(routToParent2Table);

            PdfPTable routToParent3Table = new PdfPTable(2);
            routToParent3Table.DefaultCell.Border = 0;
            PdfPTable routTO3Table = new PdfPTable(1);
            routTO3Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO3Table.AddCell(new itextSharpText.Phrase("ROUTE TO:", boldfont));
            routTO3Table.AddCell("" + Environment.NewLine);
            routTO3Table.AddCell("");
            routToParent3Table.AddCell(routTO3Table);

            PdfPTable date3Table = new PdfPTable(1);
            date3Table.DefaultCell.Border = 0;
            date3Table.AddCell(new itextSharpText.Phrase("DATE", boldfont));
            date3Table.AddCell("" + Environment.NewLine);
            date3Table.AddCell("");
            routToParent3Table.AddCell(date3Table);

            parentTable.AddCell(routToParent3Table);

            PdfPTable responseParentTable = new PdfPTable(2);
            responseParentTable.DefaultCell.Border = 0;
            PdfPTable respDueTable = new PdfPTable(1);
            respDueTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            respDueTable.AddCell(new itextSharpText.Phrase("RESPONSE DUE:", boldfont));
            respDueTable.AddCell("" + Environment.NewLine);
            respDueTable.AddCell("");
            responseParentTable.AddCell(respDueTable);

            PdfPTable responseTable = new PdfPTable(1);
            responseTable.DefaultCell.Border = 0;
            responseTable.AddCell(new itextSharpText.Phrase("RESPONDENT", boldfont));
            responseTable.AddCell("" + Environment.NewLine);
            responseTable.AddCell("");
            responseTable.AddCell("");
            responseParentTable.AddCell(responseTable);

            parentTable.AddCell(responseParentTable);

            PdfPTable dateRespParentTable = new PdfPTable(2);
            dateRespParentTable.DefaultCell.Border = 0;
            PdfPTable dateRespTable = new PdfPTable(1);
            dateRespTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            dateRespTable.AddCell(new itextSharpText.Phrase("DATE RESPONDED:", boldfont));
            dateRespTable.AddCell("" + Environment.NewLine);
            dateRespTable.AddCell("");
            dateRespParentTable.AddCell(dateRespTable);

            PdfPTable otherTable = new PdfPTable(1);
            otherTable.DefaultCell.Border = 0;
            otherTable.AddCell(new itextSharpText.Phrase("OTHER STATE DOCUMENT #", boldfont));
            otherTable.AddCell("" + Environment.NewLine);
            otherTable.AddCell("");
            dateRespParentTable.AddCell(otherTable);

            parentTable.AddCell(dateRespParentTable);


            PdfPTable ccparentTable = new PdfPTable(1);
            ccparentTable.DefaultCell.Border = 0;
            PdfPTable ccTable = new PdfPTable(1);
            ccTable.DefaultCell.Border = 0;
            ccTable.AddCell(new itextSharpText.Phrase("cc:", boldfont));
            String CCOPR = Convert.ToString(listItem["CC_OPR"]);
            ccTable.AddCell(new itextSharpText.Phrase(CCOPR, contentFont));

            String ORIGINATOR = Convert.ToString(listItem["CCOPR"]);
            ORIGINATOR = ORIGINATOR.Split(',')[1] + " " + ORIGINATOR.Split(',')[0]; //Display Originator name - First last name - Not in VM

            ccTable.AddCell(new itextSharpText.Phrase(ORIGINATOR, contentFont));
            String OPRCC = Convert.ToString(listItem["OPRCC"]);
            ccTable.AddCell(new itextSharpText.Phrase(OPRCC, contentFont));
            ccTable.AddCell("");
            ccparentTable.AddCell(ccTable);


            document.Add(parentTable);
            document.Add(ccparentTable);
            document.Close();
            document.Dispose();

            //using (SPSite site = new SPSite("http://sp13dev:32120/teams/FiscalAgent/director/"))
            using (SPSite site = new SPSite(siteUrl)) //dev Site - C
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
                    String sourceFile, fileName = null;
                    sourceFile = siteUrl + "/" + scanOPRLibrary.RootFolder + "/" + OPRNumber + ".pdf";
                    fileName =  OPRNumber + ".pdf";
                 
                    if (reSubmit == "Add")
                    {
                       
                        SPFile file = currentWeb.Files.Add(scanOPRLibrary.RootFolder + "/" + OPRNumber + ".pdf", outputMemory.ToArray(), true);
                        file.Item.Properties["Subject_1"] = Convert.ToString(listItem["OPRType"]);
                        file.Item.Properties["OPRSubType"] = Convert.ToString(listItem["OPRSubType"]);
                        file.Item.Properties["OPRMessage"] = Convert.ToString(listItem["OPRSubject"]);
                        file.Item.Properties["ApproverEmail"] = GetApproverEmail(Convert.ToString(listItem["Approver"]), siteUrl);
                        file.Item.Properties["TypistEmail"] = GetTypistEmail(Convert.ToString(listItem["CC_OPR"]), siteUrl);
                        file.Item.SystemUpdate();
                        file.Update();
                        scanOPRLibrary.Update();
                       
                    }
                    else
                    {
                       
                        ScanMergeDocuments(listItem, sourceFile, outputMemory.ToArray(), fileName, siteUrl, reSubmit);
                       
                    }
                }
            }
        }

        public static String GetApproverEmail(String shortName, String siteUrl)
        {
            String approverEmail = String.Empty;
            using (SPSite site = new SPSite(siteUrl)) //dev Site - C
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList ApproverList = currentWeb.Lists["OPR Approvers"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                          "<Eq>" +
                                            "<FieldRef Name='ShortName'/>" +   //EmailSent is the new Column
                                            "<Value Type='Text'>"+ shortName +"</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = ApproverList.GetItems(camlQuery);
                    if (itemColl.Count > 0)
                    {
                        approverEmail = Convert.ToString(itemColl[0]["Email"]);
                        approverEmail = approverEmail.Split('#')[1];
                    }
                }
            }
            return approverEmail;
        }

        public static String GetTypistEmail(String TypistInitials, String siteUrl)
        {
            String typistEmail = String.Empty;
            using (SPSite site = new SPSite(siteUrl)) //dev Site - C
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList ApproverList = currentWeb.Lists["Typist"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                          "<Eq>" +
                                            "<FieldRef Name='TypistInitials'/>" +
                                            "<Value Type='Text'>" + TypistInitials + "</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = ApproverList.GetItems(camlQuery);
                    if (itemColl.Count > 0)
                    {
                        typistEmail = Convert.ToString(itemColl[0]["Email"]);
                        typistEmail = typistEmail.Split('#')[1];
                    }
                }
            }
            return typistEmail;
        }

        public static void ScanMergeDocuments(SPListItem listItem, String srcFile, byte[] pdfEditedCopyStream, String fileName, String siteUrl,String reSubmit)
        {

            PdfReader reader = null;
            PdfReader editReader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage;
            string outputPdfPath = @"C:/EditMerge/" + fileName; //Edit Merge Folder
            sourceDocument = new Document();
            pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));
            //Open the output file
            sourceDocument.Open();
            try
            {
                //Loop through the files list
                int pages = 0;
                pages = get_pageCcount(srcFile, siteUrl);
                reader = new PdfReader(srcFile);
                //Add pages of current file
                editReader =new PdfReader(pdfEditedCopyStream);
                importedPage = pdfCopyProvider.GetImportedPage(editReader, 1);
                pdfCopyProvider.AddPage(importedPage);
                if (pages > 1)
                {
                    //2 - Replace the first PDF with edited one
                    for (int i = 2; i <= pages; i++)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                }
                editReader.Close();
                editReader.Dispose();
                reader.Close();
                reader.Dispose();
                //At the end save the output file
                pdfCopyProvider.Dispose();
                sourceDocument.Close();
                //OverWrite merged document back to Scan OPR Document Library
                SaveScanMergedDocument(listItem, fileName, siteUrl, reSubmit);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static void SaveScanMergedDocument(SPListItem listItem, String fileName, String siteUrl, String reSubmit)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
                    String outputPdfPath = @"C:/EditMerge/" + fileName;
                    Byte[] fileArrayMerge = File.ReadAllBytes(outputPdfPath);
                    SPFile file = currentWeb.Files.Add(scanOPRLib.RootFolder + "/" + fileName, fileArrayMerge, true);


                    file.Item.Properties["Subject_1"] = Convert.ToString(listItem["OPRType"]);
                    file.Item.Properties["OPRMessage"] = Convert.ToString(listItem["OPRSubject"]); 
                    if (reSubmit == "Resubmit")
                    {
                        file.Item.Properties["ApprovalStatus"] = "Resubmitted"; //Emptying ApprovalStatus for resubmission
                        file.Item.Properties["EmailSent"] = false;
                        file.Item.Properties["UserComment"] = String.Empty;
                    }
                    if ((reSubmit == "Resubmit" || reSubmit == "Update") && Convert.ToString(listItem["OPRStatus"]) == "Cancelled")
                    {
                        file.Item.Properties["Status"] = "Cancelled";
                    }
                    file.Item.Properties["ApproverEmail"] = GetApproverEmail(Convert.ToString(listItem["Approver"]), siteUrl);
                    file.Item.Properties["TypistEmail"] = GetTypistEmail(Convert.ToString(listItem["CC_OPR"]), siteUrl);
                    file.Item.SystemUpdate();
                    file.Update();
                    scanOPRLib.Update();

                    //if (reSubmit == "Resubmit")
                    //{
                    //    file.Item.Properties["ApprovalStatus"] = "Resubmitted"; //Updting Resubmission value
                    //    file.Item.Properties["ApproverEmail"] = GetApproverEmail(Convert.ToString(listItem["Aprover"]), siteUrl);
                    //    file.Item.SystemUpdate();
                    //    file.Update();
                    //    scanOPRLib.Update();
                    //}
                   

                    //Delete file from Merge Document Library
                    DeleteFileFromScanMergeDocLib(fileName);
                }
            }
        }

        public static void DeleteFileFromScanMergeDocLib(String fileName)
        {
            //Delete file from Edit Merge Document Library
            String networkFolderPath = @"C:/EditMerge";
            String[] files = Directory.GetFiles(networkFolderPath);
            foreach (String filePath in files)
            {
                if (filePath.Contains(fileName))
                {
                    File.Delete(filePath);
                }
            }
        }

        private static int get_pageCcount(string fileUrl, String siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site - C
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPFile file = web.GetFile(fileUrl);

                    using (StreamReader sr = new StreamReader(file.OpenBinaryStream()))
                    {
                        Regex regex = new Regex(@"/Type\s*/Page[^s]");
                        MatchCollection matches = regex.Matches(sr.ReadToEnd());

                        return matches.Count;
                    }
                }
            }
        }
    }
}

