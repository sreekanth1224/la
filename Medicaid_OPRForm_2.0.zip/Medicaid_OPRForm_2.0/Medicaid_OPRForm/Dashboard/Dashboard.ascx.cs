﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_OPRForm.Dashboard
{
    [ToolboxItemAttribute(false)]
    public partial class Dashboard : WebPart
    {
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public Dashboard()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetCompletedStatusCount();
                GetPendingStatusCount();
                GetCancelledStatusCount();
                GetHPStatusCount();
            }
        }
        public void GetCompletedStatusCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        //query.Query = "<Where>" +
                        //                "<Eq>" +
                        //                   "<FieldRef Name='OPRStatus'/>" +   //OPR_Number is the new column in 'Scan OPR'
                        //                   "<Value Type='Text'>Completed</Value>" +
                        //                 "</Eq>" +
                        //             "</Where>";

                        //Get last and latest 5 days records and apply the condition
                        query.Query ="<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> "+ SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Now.AddDays(-5)) +" </Value>" +
                                                 "</Geq>" +
                                                 "<Eq>" +
                                                   "<FieldRef Name='OPRStatus'/>" +
                                                   "<Value Type='Text'>Completed</Value>" +
                                                 "</Eq>" +
                                              "</And>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                   "<FieldRef Name='Created' />",
                                   "<FieldRef Name='OPRStatus' />");
                        query.ViewFieldsOnly = true;
                        query.DatesInUtc = false;
                        query.RowLimit = 3500;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DateTime requestedDate = DateTime.Now;
                            String fromDate = requestedDate.Date.AddDays(-1).ToShortDateString();
                            String toDate = requestedDate.Date.ToShortDateString();
                            TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:30:00"));
                            if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                            {
                                fromDate = requestedDate.Date.ToShortDateString();
                                toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            }
                            else if (requestedDate.Date.DayOfWeek == DayOfWeek.Monday)
                            {
                                fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                            }
                            DataRow[] dataRows = listColl.GetDataTable().Select();
                            var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:30:00") &&
                                                                  Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00")).ToList();

                            if (SacnListColl.Count > 0)
                            {
                                Int32 ApprovedCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Completed").Count();
                                //Int32 pedningCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Pending").Count();
                                //Int32 cancelledCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Cancelled").Count();
                                lblCompleted.Text = Convert.ToString(ApprovedCount);
                                //lblPending.Text = Convert.ToString(pedningCount);
                                //lblCancelled.Text = Convert.ToString(cancelledCount);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetPendingStatusCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        query.Query = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Now.AddDays(-5)) + " </Value>" +
                                                 "</Geq>" +
                                                 "<Eq>" +
                                                   "<FieldRef Name='OPRStatus'/>" +
                                                   "<Value Type='Text'>Pending</Value>" +
                                                 "</Eq>" +
                                              "</And>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                   "<FieldRef Name='Created' />",
                                   "<FieldRef Name='OPRStatus' />");
                        query.ViewFieldsOnly = true;
                        query.DatesInUtc = false;
                        query.RowLimit = 1500;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DateTime requestedDate = DateTime.Now;
                            String fromDate = requestedDate.Date.AddDays(-1).ToShortDateString();
                            String toDate = requestedDate.Date.ToShortDateString();
                            TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:30:00"));
                            if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                            {
                                fromDate = requestedDate.Date.ToShortDateString();
                                toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            }
                            else if (requestedDate.Date.DayOfWeek == DayOfWeek.Monday)
                            {
                                fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                            }
                            DataRow[] dataRows = listColl.GetDataTable().Select();
                            var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:30:00") &&
                                                                  Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00")).ToList();

                            if (SacnListColl.Count > 0)
                            {
                                Int32 pedningCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Pending").Count();
                                //Int32 cancelledCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Cancelled").Count();
                                lblPending.Text = Convert.ToString(pedningCount);
                                //lblCancelled.Text = Convert.ToString(cancelledCount);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetCancelledStatusCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        query.Query = "<Where>" +
                                           "<And>" +
                                               "<Geq>" +
                                                  "<FieldRef Name='Created'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Now.AddDays(-5)) + " </Value>" +
                                                "</Geq>" +
                                                "<Eq>" +
                                                  "<FieldRef Name='OPRStatus'/>" +
                                                  "<Value Type='Text'>Cancelled</Value>" +
                                                "</Eq>" +
                                             "</And>" +
                                        "</Where>" +
                                        "<OrderBy>" +
                                           "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                        "</OrderBy>";
                        query.ViewFields = string.Concat(
                                   "<FieldRef Name='Created' />",
                                   "<FieldRef Name='OPRStatus' />");
                        query.ViewFieldsOnly = true;
                        query.DatesInUtc = false;
                        query.RowLimit = 1500;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DateTime requestedDate = DateTime.Now;
                            String fromDate = requestedDate.Date.AddDays(-1).ToShortDateString();
                            String toDate = requestedDate.Date.ToShortDateString();
                            TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:30:00"));
                            if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                            {
                                fromDate = requestedDate.Date.ToShortDateString();
                                toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            }
                            else if (requestedDate.Date.DayOfWeek == DayOfWeek.Monday)
                            {
                                fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                            }
                            DataRow[] dataRows = listColl.GetDataTable().Select();
                            var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:30:00") &&
                                                                  Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00")).ToList();

                            if (SacnListColl.Count > 0)
                            {
                                Int32 cancelledCount = SacnListColl.Where(s => Convert.ToString(s["OPRStatus"]) == "Cancelled").Count();
                                lblCancelled.Text = Convert.ToString(cancelledCount);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetHPStatusCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList HPEList = currentWeb.Lists["HPE"];
                        SPQuery camlQuery = new SPQuery();
                        camlQuery.Query = "<Where>" +
                                             "<Eq>" +
                                                "<FieldRef Name='Created'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                                "<Value Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.UtcNow) + "</Value>" +
                                              "</Eq>" +
                                          "</Where>";
                        SPListItemCollection listColl = HPEList.GetItems(camlQuery);

                        if (listColl.Count > 0)
                        {
                            lblHPERequests.Text = Convert.ToString(listColl.Count);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
