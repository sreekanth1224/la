﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using Medicaid_OPRForm.Utility;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.IO;

namespace Medicaid_OPRForm.DailyLogSheet
{
    [ToolboxItemAttribute(false)]
    public partial class DailyLogSheet : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public DailyLogSheet()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                try
                {
                    GetScanListData(DateTime.Now);
                }
                catch(Exception ex)
                {
                    btnSerach.Text = ex.Message;
                }
                

               // readPDF();
               
            }
        }
        
        public void GetScanListData(DateTime requestedDate) //Get Date specific List data 
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {

                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        query.Query = "<Where>" +
                                           "<And>" +
                                               "<Geq>" +
                                                  "<FieldRef Name='DateOfLog'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='True'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(requestedDate.Date.ToShortDateString() + " 00:00:00")) + " </Value>" +
                                                "</Geq>" +
                                                "<Leq>" +
                                                  "<FieldRef Name='DateOfLog'/>" +
                                                  "<Value Type='DateTime' IncludeTimeValue='True'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(requestedDate.Date.ToShortDateString() + " 23:59:59")) + " </Value>" +
                                                "</Leq>" +
                                             "</And>" +
                                             //"<And>" +
                                             //  "<Geq>" +
                                             //     "<FieldRef Name='Created'/>" +
                                             //     "<Value Type='DateTime' IncludeTimeValue='True'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:16:00")) + " </Value>" +
                                             //   "</Geq>" +
                                             //   "<Leq>" +
                                             //     "<FieldRef Name='Created'/>" +
                                             //     "<Value Type='DateTime' IncludeTimeValue='True'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(toDate + " 14:15:00")) + " </Value>" +
                                             //   "</Leq>" +
                                             //"</And></Or>" +
                                        "</Where>" +
                                        "<OrderBy>" +
                                           "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                        "</OrderBy>";
                        query.ViewFields = string.Concat(
                                   "<FieldRef Name='OPR_Test' />",
                                   "<FieldRef Name='ID' />",
                                   "<FieldRef Name='CCOPR' />",
                                   "<FieldRef Name='CC_OPR' />",
                                   "<FieldRef Name='AuthorOPR' />",
                                   "<FieldRef Name='DirectTO' />",
                                   "<FieldRef Name='OPRType' />",
                                   "<FieldRef Name='HP_OPR' />",
                                   "<FieldRef Name='HPE_ID' />",
                                   "<FieldRef Name='Attn' />",
                                   "<FieldRef Name='OPRSubject' />",
                                   "<FieldRef Name='OPRMessage' />",
                                   "<FieldRef Name='PickUp' />",
                                   "<FieldRef Name='DateofActionOPR' />",
                                   "<FieldRef Name='OPRStatus' />",
                                   "<FieldRef Name='SeeMemo' />",
                                   "<FieldRef Name='FinancialSeeMemo' />",
                                   "<FieldRef Name='FinancialOPR' />",
                                   "<FieldRef Name='ApprovalStatus' />");
                        query.ViewFieldsOnly = true;
                        query.DatesInUtc = false;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null && listColl.Count > 0)
                        {                           
                            
                            //DataRow[] dataRows = listColl.GetDataTable().Select();

                            //Condition for (Pending && Approver approved)/ Cancelled on Same day/ Showing the Cancelled records on a purticular day 
                            //var SacnListColl = dataRows.Where(s => (Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved"
                            //                    && Convert.ToDateTime(s["Modified"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Modified"]) <= DateTime.Parse(toDate + " 14:30:00"))
                            //                    || (Convert.ToString(s["OPRStatus"]) != "Pending" && Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00"))
                            //                    || (Convert.ToString(s["OPRStatus"]) == "Cancelled" && Convert.ToDateTime(s["Modified"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Modified"]) <= DateTime.Parse(toDate + " 14:30:00"))).ToList();
                            //var SacnListColl = dataRows;
                                //.Where(s => (Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved")
                                               //|| (Convert.ToString(s["OPRStatus"]) != "Pending")
                                               //|| (Convert.ToString(s["OPRStatus"]) == "Cancelled")).ToList();
                            if (listColl.Count > 0)
                            {
                                DataTable scanTable = new DataTable();
                                DataRow dr = null;
                                /*Start-Scan List Dev*/
                                scanTable.Columns.Add(new DataColumn("OPR_Test", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("ID", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CCOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CC_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("AuthorOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DirectTO", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRType", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("HP_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("HPE_ID", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("Attn", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRSubject", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRMessage", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("PickUp", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DateofActionOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRStatus", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("SeeMemo", typeof(bool)));
                                /*End-Scan List Dev*/

                                foreach (SPListItem item in listColl)
                                {
                                    /*Start-Scan List Dev*/
                                    dr = scanTable.NewRow();
                                    dr["OPR_Test"] = Convert.ToString(item["OPR_Test"]);
                                    dr["ID"] = Convert.ToString(item["ID"]);
                                    dr["CCOPR"] = Convert.ToString(item["CCOPR"]);
                                    dr["CC_OPR"] = Convert.ToString(item["CC_OPR"]);
                                    dr["AuthorOPR"] = Convert.ToString(item["AuthorOPR"]);
                                    dr["DirectTO"] = Convert.ToString(item["DirectTO"]);
                                    dr["OPRType"] = Convert.ToString(item["OPRType"] + " -" + "\r\n" + item["OPRSubject"]);
                                    dr["HP_OPR"] = Convert.ToString(item["HP_OPR"]);
                                    dr["HPE_ID"] = Convert.ToString(item["HPE_ID"]);
                                    dr["Attn"] = Convert.ToString(item["Attn"]);
                                    dr["OPRSubject"] = Convert.ToString(item["OPRSubject"]);
                                    dr["OPRMessage"] = Convert.ToString(item["OPRMessage"]);
                                    dr["PickUp"] = Convert.ToString(item["PickUp"]);
                                    if (Convert.ToString(item["SeeMemo"]) == "1" || Convert.ToString(item["FinancialSeeMemo"]) == "See Memo")
                                    {
                                        dr["DateofActionOPR"] = "See Memo";
                                    }
                                    else if (String.IsNullOrEmpty(Convert.ToString(item["DateofActionOPR"])))
                                    {
                                        dr["DateofActionOPR"] = null;
                                    }
                                    else if (String.IsNullOrEmpty(Convert.ToString(item["FinancialOPR"])))
                                    {
                                        dr["DateofActionOPR"] = Convert.ToDateTime(item["DateofActionOPR"]).ToShortDateString();
                                    }
                                    else
                                    {
                                        dr["DateofActionOPR"] = Convert.ToDateTime(item["FinancialOPR"]).ToShortDateString();
                                    }
                                    //dr["DateofActionOPR"] = String.IsNullOrEmpty(Convert.ToString(item["FinancialOPR"])) ? Convert.ToDateTime(item["DateofActionOPR"]).ToShortDateString() : Convert.ToString(item["FinancialOPR"]);
                                    dr["OPRStatus"] = Convert.ToString(item["OPRStatus"]);
                                    scanTable.Rows.Add(dr);
                                    /*End-Scan List Dev*/
                                }

                                gvDailyLogSheet.DataSource = scanTable;
                                gvDailyLogSheet.DataBind();

                                ViewState["ScanList"] = scanTable;
                            }
                            else
                            {
                                DataTable dtEmpty = new DataTable();
                                gvDailyLogSheet.DataSource = dtEmpty;
                                gvDailyLogSheet.DataBind();   
                            }

                        }
                        else
                        {
                            DataTable dtEmpty = new DataTable();
                            gvDailyLogSheet.DataSource = dtEmpty;
                            gvDailyLogSheet.DataBind();
                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void ButtonPDf_Click(object sender, EventArgs e)
        {
           // GeneratePDF();
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            DateTime requestedDate = DateTime.Now;
            if (!String.IsNullOrEmpty(txtRequestedDate.Text))
            {
                requestedDate = DateTime.Parse(txtRequestedDate.Text);
            }
            GetScanListData(requestedDate);
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtRequestedDate.Text = "";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/director/SitePages/OPRLogSheet.aspx");
        }      
    }
}
