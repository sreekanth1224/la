﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
    public class DXCSearchEntity
    {
        public int ID { get; set; }
        public string EDS_Number { get; set; }
        public string Subject_HPE { get; set; }
        public string Author_HPE { get; set; }
        public DateTime DateReceived { get; set; }
        public string OPR_Number { get; set; }
        public DateTime Created { get; set; }
    }
}
