﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
    public class BASearchEntity
    {
        public int ID { get; set; }
        public string BANumber { get; set; }
        public string BAName { get; set; }
        public DateTime BADate { get; set; }
        public string BAOwner { get; set; }
        public DateTime Created { get; set; }
        
    }
}
