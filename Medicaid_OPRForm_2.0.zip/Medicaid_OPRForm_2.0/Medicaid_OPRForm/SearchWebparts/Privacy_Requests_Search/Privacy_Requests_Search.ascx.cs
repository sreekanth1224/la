﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_OPRForm.Utility;


namespace Medicaid_OPRForm.Webparts.Privacy_Requests_Search
{
    [ToolboxItemAttribute(false)]
    public partial class Privacy_Requests_Search : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public Privacy_Requests_Search()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        String siteUrl = SPContext.Current.Site.Url + "/director/";
        Int32 pageIndex = 0; //PageIndex
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        List<PrivacySearchEntity> searchEntity = new List<PrivacySearchEntity>();
        DateTime tempDate;
        

        public List<PrivacySearchEntity> GetPrivacyData(String paging) //Get Date specific List data 
        {
            bool isDueDateValid = (txtRequestDate.Text == "Request Date" || txtRequestDate.Text.Length == 0) ? true : DateTime.TryParse(txtRequestDate.Text, out tempDate);
            if (isDueDateValid)
            {
                try
                {
                    String loginName = String.Empty;
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);

                    pageIndex = 0;
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            lblErrorMsg.Text = String.Empty;
                            //ViewState["PrivacyTable"] = null;
                            SPList scanList = currentWeb.Lists["PrivacyRequests"];
                            List<string> objColumns = new List<string>();

                            //itemCount = scanList.ItemCount;
                            //totalPages = itemCount / Convert.ToInt32(ddlRowCount.SelectedValue);

                            // here, format is like: "Column name(internal name of column);Column type; Conditional operator; Search string (input by user)

                            SPQuery query = new SPQuery();
                            //query.RowLimit = Convert.ToUInt32(dropdownPageSize); //Row Limit

                            if (txtMedicaidID.Text != "Medicaid ID" && txtMedicaidID.Text.Length > 0)
                            {
                                objColumns.Add("MedicaidID;Text;Contains;" + txtMedicaidID.Text.Trim());
                            }
                            if (txtSSN.Text != "SSN" && txtSSN.Text.Length > 0)
                            {
                                objColumns.Add("SSN;Text;Contains;" + txtSSN.Text.Trim());
                            }
                            if (txtRequestDate.Text != "Request Date" && txtRequestDate.Text.Length > 0)
                            {
                                objColumns.Add("RequestDate;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtRequestDate.Text)));
                            }
                            if (txtRecipientName.Text != "Recipient Name" && txtRecipientName.Text.Length > 0)
                            {
                                objColumns.Add("RecipientName;Text;Contains;" + txtRecipientName.Text.Trim());
                            }
                            if (txtStatus.Text != "Status" && txtStatus.Text.Length > 0)
                            {
                                objColumns.Add("Status;Text;Contains;" + txtStatus.Text.Trim());
                            }
                            if (txtRequesttype.Text != "Request Type" && txtRequesttype.Text.Length > 0)
                            {
                                objColumns.Add("Requesttype;Text;Contains;" + txtRequesttype.Text.Trim());
                            }
                            if (txtMMISType.Text != "MMIS Type" && txtMMISType.Text.Length > 0)
                            {
                                objColumns.Add("MMISType;Text;Contains;" + txtMMISType.Text.Trim());
                            }
                            //if (itemPoistion != null) //Item Position
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}
                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='RequestDate' Ascending='FALSE'/></OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                       "<FieldRef Name='MedicaidID' />",
                                       "<FieldRef Name='SSN' />",
                                       "<FieldRef Name='RequestDate' />",
                                       "<FieldRef Name='RecipientName' />",
                                       "<FieldRef Name='Status' />",
                                       "<FieldRef Name='Requesttype' />",
                                       "<FieldRef Name='MMISType' />",
                                       "<FieldRef Name='PrivacyReqFile' />",
                                       "<FieldRef Name='Created' />",
                                       "<FieldRef Name='ID' />");
                            query.ViewFieldsOnly = true;

                            //if (itemPoistion != null)
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}

                            SPListItemCollection listColl = scanList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (listColl != null && listColl.Count > 0)
                            {
                                //DataTable PrivacyTable = listColl.GetDataTable();
                                //DataView PrivacyView = PrivacyTable.DefaultView;
                                //PrivacyView.Sort = "Created DESC";  //Display Grid Records in Descending Order
                                //ViewState["PrivacyTable"] = PrivacyView.ToTable();
                                //gvPrivacySearch.DataSource = ViewState["PrivacyTable"];
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                //lblRecordCount.Text = Convert.ToString(scanListCollection.Count());

                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new PrivacySearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        MedicaidID = Convert.ToString(item["MedicaidID"]),
                                        SSN = Convert.ToString(item["SSN"]),
                                        RequestDate = Convert.ToDateTime(item["RequestDate"]),
                                        RecipientName = Convert.ToString(item["RecipientName"]),
                                        Status = Convert.ToString(item["Status"]),
                                        Requesttype = Convert.ToString(item["Requesttype"]),
                                        MMISType = Convert.ToString(item["MMISType"]),
                                        PrivacyReqFile = Convert.ToString(item["PrivacyReqFile"]),
                                        Created = Convert.ToDateTime(item["Created"])
                                    });
                                }
                            }
                            else
                            {
                                gvPrivacySearch.DataSource = null;
                                gvPrivacySearch.DataBind();
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }

        public void ClearSearchFields()
        {
            if (txtMedicaidID.Text == "Medicaid ID")
            {
                txtMedicaidID.Text = "";
            }
            if (txtSSN.Text == "SSN")
            {
                txtSSN.Text = "";
            }
            if (txtRequestDate.Text == "Request Date")
            {
                txtRequestDate.Text = "";
            }
            if (txtRecipientName.Text == "Recipient Name")
            {
                txtRecipientName.Text = "";
            }
            if (txtStatus.Text == "Status")
            {
                txtStatus.Text = "";
            }
            if (txtRequesttype.Text == "Request Type")
            {
                txtRequesttype.Text = "";
            }
            if (txtMMISType.Text == "MMIS Type")
            {
                txtMMISType.Text = "";
            }

        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>"); //Ascending to FALSE
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            //GetPrivacyData(null, null);
            ClearSearchFields();
            gvPrivacySearch.DataSource = GetPrivacyData(null);
            gvPrivacySearch.DataBind();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtMedicaidID.Text = "Medicaid ID";
            txtSSN.Text = "SSN";
            txtRequestDate.Text = "Request Date";
            txtRecipientName.Text = "Recipient Name";
            txtStatus.Text = "Status";
            txtRequesttype.Text = "Request Type";
            txtMMISType.Text = "MMIS Type";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/SitePages/Privacy%20Search.aspx");

        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvPrivacySearch.DataSource = GetPrivacyData(null);
            gvPrivacySearch.DataBind();
            //GetPrivacyData(null, null);
            //if (ViewState["PrivacyTable"] != null)
            //{
            //    DataTable dt = ViewState["PrivacyTable"] as DataTable;

            //    if (dt != null)
            //    {
            //        gvPrivacySearch.PageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
            //        gvPrivacySearch.DataSource = ViewState["PrivacyTable"];
            //        gvPrivacySearch.DataBind();
            //    }
            //}
        }

       
        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

       protected void gvPrivacySearch_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            //ClearSearchFields();
            //gvPrivacySearch.PageIndex = e.NewPageIndex;
            //GetPrivacyData();
        }

        protected void gvPrivacySearch_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
            //if (ViewState["PrivacyTable"] != null)
            //{
            //    DataTable dt = ViewState["PrivacyTable"] as DataTable;

            //    if (dt != null)
            //    {
            //        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
            //        gvPrivacySearch.DataSource = ViewState["PrivacyTable"];
            //        gvPrivacySearch.DataBind();
            //    }
            //}
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            //String pageInfo = ViewState["Prev"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //// oPos.PagingInfo = ViewState["Prev"] as String;
            //GetPrivacyData(oPos, "prev");
            gvPrivacySearch.DataSource = GetPrivacyData("prev");
            gvPrivacySearch.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            //String pageInfo = ViewState["Next"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //oPos.PagingInfo = ViewState["Prev"] as String;
            //GetPrivacyData(oPos, "next");
            gvPrivacySearch.DataSource = GetPrivacyData("next");
            gvPrivacySearch.DataBind();
        }

        public void SortColumn(String sortExpression)
        {
            List<PrivacySearchEntity> PrivacySearchEntityList = GetPrivacyData(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "MedicaidID":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.MedicaidID).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.MedicaidID).ToList();
                    break;
                case "SSN":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.SSN).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.SSN).ToList();
                    break;
                case "RecipientName":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.RecipientName).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.RecipientName).ToList();
                    break;
                case "Status":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.Status).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.Status).ToList();
                    break;
                case "Requesttype":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.Requesttype).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.Requesttype).ToList();
                    break;
                case "MMISType":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.MMISType).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.MMISType).ToList();
                    break;
                case "PrivacyReqFile":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.PrivacyReqFile).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.PrivacyReqFile).ToList();
                    break;
                case "RequestDate":
                    gvPrivacySearch.DataSource = (sortDirection == "ASC") ? PrivacySearchEntityList.OrderBy(x => x.RequestDate).ToList() : PrivacySearchEntityList.OrderByDescending(x => x.RequestDate).ToList();
                    break;
            }
            gvPrivacySearch.DataBind();
        } 


    }
}
    

