﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using Medicaid_OPRForm.Utility;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.IO;

namespace Medicaid_OPRForm.DailyLogSheet
{
    [ToolboxItemAttribute(false)]
    public partial class DailyLogSheet : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public DailyLogSheet()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        //String siteUrl = "https://dev.sp.medicaid.al/teams/FiscalAgent/director/";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetScanListData();

               // readPDF();
               
            }
        }
        //public void readPDF()
        //{
        //    using (SPSite site = new SPSite(siteUrl))
        //    {
        //        using (SPWeb web = site.OpenWeb())
        //        {
        //            SPList scanList = web.Lists["Documents"];
        //            SPQuery query = new SPQuery();
        //            SPListItemCollection listColl = scanList.GetItems(query);
        //            if (listColl != null)
        //            {
        //                DataRow[] dataRows = listColl.GetDataTable().Select();
        //                String fileName = DateTime.Now.ToString("dd-MM-yyyy") + ".pdf";
        //                var pdfFileColl = dataRows.Where(s => Convert.ToString(s["LinkFilename"]) == fileName).ToList();
        //                if (pdfFileColl.Count > 0)
        //                {
        //                   // pdfFileColl[0].ItemArray[0];
        //                    String pdfFile = pdfFileColl[0].ItemArray[0].ToString();
        //                }
        //            }
        //        }
        //    }
        //}
        //public void GeneratePDF()
        //{
        //    //SPSecurity.RunWithElevatedPrivileges(delegate()
        //    //{


        //        DataRow[] logSheetArray = GetDailyLogSheet();

        //        String fromDate = DateTime.Now.Date.AddDays(-1).ToShortDateString();
        //        String toDate = DateTime.Now.Date.ToShortDateString();
        //        TimeSpan timespan = DateTime.Now.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
        //        if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
        //        {
        //            fromDate = DateTime.Now.Date.ToShortDateString();
        //        }
        //        var SacnListColl = logSheetArray.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();

        //        if (SacnListColl.Count > 0)
        //        {
        //            Font boldfont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9, iTextSharp.text.Font.BOLD);
        //            Font contentFont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8, iTextSharp.text.Font.NORMAL);
        //            Font HeaderFont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12, iTextSharp.text.Font.BOLD);
        //            var document = new Document(PageSize.A4, 10, 10, 25, 25);
        //            var outputMemory = new MemoryStream();
        //            var pdfWriter = PdfWriter.GetInstance(document, outputMemory);
        //            document.Open();

        //            //PdfContentByte contentByte = pdfWriter.DirectContent;
        //            //contentByte.SetLineWidth(1.0f);
        //            //PdfPTable tblParent = new PdfPTable(6);
        //            //int[] tblWidthParent = {20, 20, 15, 15, 15, 15 };
        //            //tblParent.SetWidths(tblWidthParent);
        //            //tblParent.HorizontalAlignment = 0;
        //            //tblParent.DefaultCell.Border = 0;

        //            PdfPTable tblHeader = new PdfPTable(6);
        //            int[] tblHeaderWidth = { 20, 20, 15, 15, 15, 15 };
        //            tblHeader.SetWidths(tblHeaderWidth);
        //            tblHeader.WidthPercentage = 95;
        //            tblHeader.SpacingAfter = 10f;
        //            tblHeader.HorizontalAlignment = Element.ALIGN_CENTER;
        //            tblHeader.DefaultCell.Border = 0;
        //            tblHeader.DefaultCell.PaddingTop = 5;
        //            tblHeader.DefaultCell.BorderWidthTop = 0.5f;
        //            tblHeader.DefaultCell.BorderWidthBottom = 0.5f;
        //            tblHeader.AddCell(new Phrase("DocNumber", boldfont));
        //            tblHeader.AddCell(new Phrase("Author", boldfont));
        //            tblHeader.AddCell(new Phrase("Subject_1", boldfont));
        //            tblHeader.AddCell(new Phrase("Subject_2", boldfont));
        //            tblHeader.AddCell(new Phrase("Date of Letter", boldfont));
        //            tblHeader.AddCell(new Phrase("Date of Action", boldfont));
        //            document.Add(tblHeader);

        //            PdfPTable tblColumn = new PdfPTable(6);
        //            int[] tblColumnWidth = { 20, 20, 15, 15, 15, 15 };
        //            tblColumn.SetWidths(tblHeaderWidth);
        //            tblColumn.WidthPercentage = 95;
        //            tblColumn.SpacingAfter = 10f;
        //            tblColumn.HorizontalAlignment = Element.ALIGN_CENTER;
        //            tblColumn.DefaultCell.Border = 0;
        //            tblColumn.DefaultCell.PaddingTop = 5;
        //            tblColumn.DefaultCell.BorderWidthBottom = 0.5f;

        //            foreach (var item in SacnListColl)
        //            {
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[7]), contentFont)); //DocNumber
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[13]), contentFont)); //Author
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[16]), contentFont)); //Subject_1
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[14]), contentFont)); //Subject_2
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[10]), contentFont)); //Date of Letter
        //                tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[25]), contentFont)); //Date of Action
        //                document.Add(tblColumn);
        //                tblColumn.FlushContent();
                        
        //            }

        //            PdfContentByte pdfContentByte = pdfWriter.DirectContent;
        //            pdfContentByte.SetLineWidth(1.0f);
        //            pdfContentByte.MoveTo(10, document.Bottom - 10f);
        //            pdfContentByte.LineTo(580, document.Bottom - 10f);
        //            pdfContentByte.Stroke();

        //            document.Close();
        //            document.Dispose();

        //            byte[] FileContent = outputMemory.ToArray();
        //            using (SPSite site = new SPSite(siteUrl))
        //            {
        //                using (SPWeb web = site.OpenWeb())
        //                {
        //                    SPList DocLib = web.Lists["Documents"];
        //                    //Add the file
        //                    //String fileName = DateTime.Now.Day.ToString();
        //                    String fileName = DocLib.RootFolder + "/" + DateTime.Now.ToString("dd-MM-yyyy") + ".pdf";
        //                    web.Files.Add(fileName, FileContent, true);

        //                    SPFile file = web.GetFile(fileName);
        //                }
        //            }

        //            outputMemory.Close();
        //            outputMemory.Dispose();
        //            outputMemory.Flush();

        //            // Write out PDF from memory stream.
        //            //using (FileStream fs = System.IO.File.Create("C:\\Test1.pdf"))
        //            //{
        //            //    fs.Write(content, 0, (int)content.Length);
        //            //}


        //            //PdfPCell pdfHeaderCell1 = new PdfPCell();
        //            //pdfHeaderCell1.Border = 0;
        //            //pdfHeaderCell1.Phrase = new Phrase(Environment.NewLine + "TEst1", boldfont);
        //            //tblHeader.AddCell(pdfHeaderCell1);
        //        }
        //    //});
        //}

        public void GetScanListData() //Get Date specific List data 
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        DateTime table = DateTime.Now;
                        int hour = DateTime.Now.Hour;
                        bool isTime = hour < 14;
                       
                        query.DatesInUtc = false;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null)
                        {
                            String fromDate = DateTime.Now.Date.AddDays(-1).ToShortDateString();
                            //String fromDate = DateTime.Now.Date.ToShortDateString();
                            String toDate = DateTime.Now.Date.ToShortDateString();
                            TimeSpan timespan = DateTime.Now.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
                            //if (timespan.Days >= 1)
                            if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                            {
                                fromDate = DateTime.Now.Date.ToShortDateString();
                            }
                            DataRow[] dataRows = listColl.GetDataTable().Select();

                            var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();


                            if (SacnListColl.Count > 0)
                            {
                                DataTable scanTable = new DataTable();
                                DataRow dr = null;


                                /*Start-Scan List Dev*/
                                scanTable.Columns.Add(new DataColumn("OPR_Test", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("ID", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CCOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CC_OPR", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("OPR_Date", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("AuthorOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DirectTO", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRType", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("FinancialOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("HP_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("Attn", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRSubject", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRMessage", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("Action_OPR", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("Other_Action", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("ReqCoordination", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("ReceivedBy", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DateofActionOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRStatus", typeof(string)));
                                /*End-Scan List Dev*/


                                foreach (DataRow item in SacnListColl)
                                {

                                    /*Start-Scan List Dev*/
                                    dr = scanTable.NewRow();
                                    dr["OPR_Test"] = Convert.ToString(item["OPR_Test"]);
                                    dr["ID"] = Convert.ToString(item["ID"]);
                                    dr["CCOPR"] = Convert.ToString(item["CCOPR"]);
                                    dr["CC_OPR"] = Convert.ToString(item["CC_OPR"]);
                                    //dr["OPRDate"] = Convert.ToDateTime(item["OPRDate"]).ToShortDateString();
                                    //dr["OPR_Date"] = Convert.ToString(item["OPR_Date"]);
                                    dr["AuthorOPR"] = Convert.ToString(item["AuthorOPR"]);
                                    dr["DirectTO"] = Convert.ToString(item["DirectTO"]);
                                    dr["OPRType"] = Convert.ToString(item["OPRType"] + " -" + "\r\n" + item["OPRSubject"]);
                                    //dr["FinancialOPR"] = Convert.ToString(item["FinancialOPR"]);
                                    dr["HP_OPR"] = Convert.ToString(item["HP_OPR"]);
                                    dr["Attn"] = Convert.ToString(item["Attn"]);
                                    dr["OPRSubject"] = Convert.ToString(item["OPRSubject"]);
                                    dr["OPRMessage"] = Convert.ToString(item["OPRMessage"]);
                                    //dr["Action_OPR"] = Convert.ToString(item["Action_OPR"]);
                                    //dr["Other_Action"] = Convert.ToString(item["Other_Action"]);
                                    //dr["ReqCoordination"] = Convert.ToString(item["ReqCoordination"]);
                                    //dr["ReceivedBy"] = Convert.ToString(item["ReceivedBy"]);
                                    dr["DateofActionOPR"] = Convert.ToString(item["DateofActionOPR"]);
                                    dr["OPRStatus"] = Convert.ToString(item["OPRStatus"]);
                                    scanTable.Rows.Add(dr);
                                    /*End-Scan List Dev*/
                                }

                                grvStudentDetails.DataSource = scanTable;
                                grvStudentDetails.DataBind();

                                ViewState["ScanList"] = scanTable;
                            }
                            else
                            {
                                DataTable dtEmpty = new DataTable();
                                grvStudentDetails.DataSource = dtEmpty;
                                grvStudentDetails.DataBind();   
                            }

                        }
                        
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //public DataRow[] GetDailyLogSheet() //Get Date specific List data 
        //{
        //    DataRow[] dataRows = null;
        //    try
        //    {
        //        using (SPSite site = new SPSite(siteUrl))
        //        {
        //            using (SPWeb currentWeb = site.OpenWeb())
        //            {
        //                SPList scanList = currentWeb.Lists["Scan List"];
        //                SPQuery query = new SPQuery();
        //                DateTime table = DateTime.Now;
        //                int hour = DateTime.Now.Hour;
        //                bool isTime = hour < 14;

        //                query.DatesInUtc = false;
        //                SPListItemCollection listColl = scanList.GetItems(query);
        //                if (listColl != null)
        //                {
        //                    dataRows = listColl.GetDataTable().Select();
        //                }

        //            }
        //        }

        //        return dataRows;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        protected void ButtonPDf_Click(object sender, EventArgs e)
        {
           // GeneratePDF();
        }      
    }
}
