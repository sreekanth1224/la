﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using Medicaid_OPRForm.Utility;
//using iTextSharp.text.pdf;
using System.IO;
using iTextSharpNS = iTextSharp.text.pdf;
//using Medicaid_OPRForm.OPRID;


namespace Medicaid_OPRForm.VisualWebPart1
{
    [ToolboxItemAttribute(false)]
    public partial class VisualWebPart1 : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public VisualWebPart1()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        DateTime searchDate = DateTime.Now;
        //String siteUrl = "https://dev.sp.medicaid.al/teams/FiscalAgent/director/";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (grvStudentDetails.Rows.Count == 0)
                {
                    GetScanListData(searchDate);
                    GetHPNumbers();
                }
                else
                {
                    GetHPNumbers();
                }
            }
            //List<string> sourcepdf = new List<string>();
            //sourcepdf.Add(@"C:\Users\txrapaka\Desktop\1.pdf");

            //CreateMergedPDF2(sourcepdf, @"C:\Users\txrapaka\Desktop\sourcepdf\2.pdf");

        }
        public List<String> AddOPRSubTypes()
        {
            List<String> listOPRSubType = new List<String>();
            listOPRSubType.Add("Select");
            listOPRSubType.Add("Max Fee");
            listOPRSubType.Add("Procedure Codes");
            listOPRSubType.Add("Providers");
            listOPRSubType.Add("Sanction of Providers");
            listOPRSubType.Add("New Customery Charge");
            listOPRSubType.Add("Updated Customery Charge");
            listOPRSubType.Add("Nursing Home Rate Changes");
            return listOPRSubType;
        }
        public List<String> AddOPRSubTypeFinancial()
        {
            List<String> listOPRSubTypeFinancial = new List<String>();
            listOPRSubTypeFinancial.Add("Select");
            listOPRSubTypeFinancial.Add("Lump Sum Payments");
            return listOPRSubTypeFinancial;
        }

        public void GetHPNumbers()
        {
            GridViewRow row = grvStudentDetails.FooterRow;

            DropDownList ddl = (DropDownList)row.FindControl("ddlHPNumber");
            ddl.DataSource = GenerateHPIDs();
            ddl.DataBind();
        }

        public void GetScanListData(DateTime requestedDate) //Get Date specific List data 
        {
            try
            {
                String loginName  = String.Empty;
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPUser currentUser = currentWeb.CurrentUser;
                        loginName = currentUser.Name;

                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        // DateTime table = DateTime.Now;
                        //int hour = requestedDate.Hour;
                        //bool isTime = hour < 14;

                        //query.Query = queryString;
                        query.DatesInUtc = false;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null)
                        {
                            String fromDate = requestedDate.Date.AddDays(-1).ToShortDateString();
                            //String fromDate = DateTime.Now.Date.ToShortDateString();
                            String toDate = requestedDate.Date.ToShortDateString();
                            TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
                            //if (timespan.Days >= 1)
                            //Get all Old and current requests
                            if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 29) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                            {
                                fromDate = requestedDate.Date.ToShortDateString();
                                toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            }
                            DataRow[] dataRows = listColl.GetDataTable().Select();
                            var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00") &&
                                                                  Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00")).ToList();
                            // var SacnListColl = dataRows.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();


                            if (SacnListColl.Count > 0)
                            {
                                DataTable scanTable = new DataTable();
                                DataRow dr = null;


                                /*Start-Scan List Dev*/
                                scanTable.Columns.Add(new DataColumn("OPR_Test", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("ID", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CCOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("CC_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPR_Date", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("AuthorOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DirectTO", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRType", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRSubType", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("FinancialOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("HP_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("Attn", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRSubject", typeof(string)));
                                //scanTable.Columns.Add(new DataColumn("OPRMessage", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("Action_OPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("Other_Action", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("ReqCoordination", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("ReceivedBy", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("DateofActionOPR", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("RouteTO", typeof(string)));
                                scanTable.Columns.Add(new DataColumn("OPRStatus", typeof(string)));
                                /*End-Scan List Dev*/


                                foreach (DataRow item in SacnListColl)
                                {

                                    /*Start-Scan List Dev*/
                                    dr = scanTable.NewRow();
                                    dr["OPR_Test"] = Convert.ToString(item["OPR_Test"]);
                                    dr["ID"] = Convert.ToString(item["ID"]);
                                    dr["CCOPR"] = Convert.ToString(item["CCOPR"]);
                                    dr["CC_OPR"] = Convert.ToString(item["CC_OPR"]);
                                    //dr["OPRDate"] = Convert.ToDateTime(item["OPRDate"]).ToShortDateString();
                                    dr["OPR_Date"] = Convert.ToString(item["OPR_Date"]);
                                    dr["AuthorOPR"] = Convert.ToString(item["AuthorOPR"]);
                                    dr["DirectTO"] = Convert.ToString(item["DirectTO"]);
                                    dr["OPRType"] = Convert.ToString(item["OPRType"]);
                                    dr["OPRSubType"] = Convert.ToString(item["OPRSubType"]);
                                    dr["FinancialOPR"] = Convert.ToString(item["FinancialOPR"]);
                                    dr["HP_OPR"] = Convert.ToString(item["HP_OPR"]);
                                    dr["Attn"] = Convert.ToString(item["Attn"]);
                                    dr["OPRSubject"] = Convert.ToString(item["OPRSubject"]);
                                    //dr["OPRMessage"] = Convert.ToString(item["OPRMessage"]);
                                    dr["Action_OPR"] = Convert.ToString(item["Action_OPR"]);
                                    dr["Other_Action"] = Convert.ToString(item["Other_Action"]);
                                    dr["ReqCoordination"] = Convert.ToString(item["ReqCoordination"]);
                                    dr["ReceivedBy"] = Convert.ToString(item["ReceivedBy"]);
                                    dr["DateofActionOPR"] = Convert.ToString(item["DateofActionOPR"]);
                                    dr["RouteTO"] = Convert.ToString(item["RouteTO"]);
                                    dr["OPRStatus"] = Convert.ToString(item["OPRStatus"]);
                                    scanTable.Rows.Add(dr);
                                    /*End-Scan List Dev*/
                                }

                                grvStudentDetails.DataSource = scanTable;
                                grvStudentDetails.DataBind();

                                ViewState["ScanList"] = scanTable;
                            }
                            else
                            {
                                FirstGridViewRow(); //Set empty grid If there are no records
                                grvStudentDetails.Rows[0].Cells[0].Visible = false;
                            }
                            //add date to the footer
                            GridViewRow row = grvStudentDetails.FooterRow;
                            TextBox txtfooterDate = row.FindControl("txtFooterDateofLetter") as TextBox;
                            if ((DateTime.Now.Hour >= 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                            {
                                txtfooterDate.Text = DateTime.Now.Date.AddDays(1).ToShortDateString();
                            }
                            else
                            {
                                txtfooterDate.Text = DateTime.Now.Date.ToShortDateString();
                            }

                            if (!String.IsNullOrEmpty(loginName))
                            {
                                DropDownList ddlCC = row.FindControl("ddlCC") as DropDownList;
                                ddlCC.SelectedValue = loginName;
                                
                            }
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected System.Web.UI.WebControls.ListItemCollection GenerateHPIDs() //Get HP Numbers from HP List
        {
            int i = 0;
            System.Web.UI.WebControls.ListItemCollection coll = new System.Web.UI.WebControls.ListItemCollection();
            //ClientContext context = new ClientContext("http://portal.spdev.local/director/");
            ClientContext context = new ClientContext(siteUrl);
            List announcementsList = context.Web.Lists.GetByTitle("HPE");

            //List announcementsList = context.Web.Lists.GetByTitle("HPE");
            //List announcementsList = context.Web.Lists.GetByTitle("HP OPR Entry");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(1000000);
            CL.ListItemCollection items = announcementsList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            foreach (CL.ListItem listItem in items)
            {
                coll.Insert(i, new System.Web.UI.WebControls.ListItem(listItem["EDS_Number"].ToString()));
                //coll.Insert(i, new System.Web.UI.WebControls.ListItem(listItem["HP_Number"].ToString())); //Dev site Property
                i++;
            }
            coll.Insert(0, String.Empty);
            return coll;
        }

        private void FirstGridViewRow() //Set First Grid Row
        {
            DataTable dt = new DataTable();
            DataRow dr = null;

            /*Start-Scan List Dev Site*/
            dt.Columns.Add(new DataColumn("OPR_Test", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("CCOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("CC_OPR", typeof(string)));
            dt.Columns.Add(new DataColumn("OPR_Date", typeof(string)));
            dt.Columns.Add(new DataColumn("AuthorOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("DirectTO", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRType", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRSubType", typeof(string)));
            dt.Columns.Add(new DataColumn("FinancialOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("HP_OPR", typeof(string)));
            dt.Columns.Add(new DataColumn("Attn", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRSubject", typeof(string)));
            //dt.Columns.Add(new DataColumn("OPRMessage", typeof(string)));
            dt.Columns.Add(new DataColumn("Action_OPR", typeof(string)));
            dt.Columns.Add(new DataColumn("Other_Action", typeof(string)));
            dt.Columns.Add(new DataColumn("ReqCoordination", typeof(string)));
            dt.Columns.Add(new DataColumn("ReceivedBy", typeof(string)));
            dt.Columns.Add(new DataColumn("DateofActionOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("RouteTO", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRStatus", typeof(string)));
            dr = dt.NewRow();

            dr["OPR_Test"] = string.Empty;
            dr["ID"] = string.Empty;
            dr["CCOPR"] = string.Empty;
            dr["CC_OPR"] = string.Empty;
            dr["OPR_Date"] = string.Empty;
            dr["AuthorOPR"] = string.Empty;
            dr["DirectTO"] = string.Empty;
            dr["OPRType"] = string.Empty;
            dr["OPRSubType"] = string.Empty;
            dr["FinancialOPR"] = string.Empty;
            dr["HP_OPR"] = string.Empty;
            dr["Attn"] = string.Empty;
            dr["OPRSubject"] = string.Empty;
            //dr["OPRMessage"] = string.Empty;
            dr["Action_OPR"] = string.Empty;
            dr["Other_Action"] = string.Empty;
            dr["ReqCoordination"] = string.Empty;
            dr["ReceivedBy"] = string.Empty;
            dr["DateofActionOPR"] = string.Empty;
            dr["RouteTO"] = string.Empty;
            dr["OPRStatus"] = string.Empty;
            dt.Rows.Add(dr);

            /*End-Scan List Dev Site*/

            ViewState["CurrentTable"] = dt;

            grvStudentDetails.DataSource = dt;
            grvStudentDetails.DataBind();


            //append log-in user
           

        }

        public string GetOPRID() //Generate OPR ID
        {

            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanList = currentWeb.Lists["Scan List"];
                    SPQuery query = new SPQuery();

                    List<SPListItem> listItems = (from SPListItem item in scanList.Items
                                                  select item).ToList();
                    String fromDate = string.Empty;


                    String OPR_Test = String.Empty;
                    String OPRID = String.Empty;
                    String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2016
                    String Month = DateTime.Now.Month.ToString();
                    String MonthFormat = String.Empty;
                    if (Convert.ToInt32(Month) <= 9)
                    {
                        MonthFormat = "0" + Month;
                    }
                    else
                    {
                        MonthFormat = Month;
                    }
                    String Day = String.Empty;// DateTime.Now.Day.ToString();
                    if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                    {
                        Day = DateTime.Now.Date.AddDays(1).Day.ToString();
                        fromDate = DateTime.Now.Date.ToShortDateString();
                    }
                    else
                    {
                        fromDate = DateTime.Now.AddDays(-1).Date.ToShortDateString();
                        Day = DateTime.Now.Day.ToString();
                    }
                    if (Convert.ToInt32(Day) <= 9)
                    {
                        Day = "0" + Day;
                    }
                    var SacnListColl = listItems.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();
                    if (SacnListColl.Count > 0)
                    {

                        OPRID = SacnListColl.OrderByDescending(i => i["ID"]).Select(i => i["OPR_Test"].ToString()).First();
                        OPRID = OPRID.Split('-')[3].ToString(); //OPR-16-0401-01
                        int ID = Convert.ToInt32(OPRID) + 1;
                        if (Convert.ToInt32(OPRID) <= 9)
                            OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-0" + ID;
                        else
                            OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-" + Convert.ToInt32(ID);
                    }
                    else
                    {

                        OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-01";
                    }
                    return OPR_Test;
                }
            }
        }

        protected void grvStudentDetails_RowDeleting(object sender, GridViewDeleteEventArgs e) //Delete Function*
        {
            SetRowData();
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;
                int rowIndex = Convert.ToInt32(e.RowIndex);
                if (dt.Rows.Count > 1)
                {
                    dt.Rows.Remove(dt.Rows[rowIndex]);
                    drCurrentRow = dt.NewRow();
                    ViewState["CurrentTable"] = dt;
                    grvStudentDetails.DataSource = dt;
                    grvStudentDetails.DataBind();

                    for (int i = 0; i < grvStudentDetails.Rows.Count - 1; i++)
                    {
                        grvStudentDetails.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                    }
                    //SetPreviousData();
                }
            }
        }

        private void SetRowData() //Set Row Data*
        {
            int rowIndex = 0;

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;


                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 0; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        TextBox TextBoxName = (TextBox)grvStudentDetails.Rows[rowIndex].Cells[1].FindControl("txtName");
                        TextBox TextBoxAge = (TextBox)grvStudentDetails.Rows[rowIndex].Cells[2].FindControl("txtAge");
                        TextBox TextBoxAddress = (TextBox)grvStudentDetails.Rows[rowIndex].Cells[3].FindControl("txtAddress");
                        RadioButtonList RBLGender =
                          (RadioButtonList)grvStudentDetails.Rows[rowIndex].Cells[4].FindControl("RBLGender");
                        DropDownList DrpQualification =
                          (DropDownList)grvStudentDetails.Rows[rowIndex].Cells[5].FindControl("drpQualification");
                        drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow["RowNumber"] = i + 1;
                        dtCurrentTable.Rows[i - 1]["Col1"] = TextBoxName.Text;
                        dtCurrentTable.Rows[i - 1]["Col2"] = TextBoxAge.Text;
                        dtCurrentTable.Rows[i - 1]["Col3"] = TextBoxAddress.Text;
                        dtCurrentTable.Rows[i - 1]["Col4"] = RBLGender.SelectedValue;
                        dtCurrentTable.Rows[i - 1]["Col5"] = DrpQualification.SelectedValue;
                        rowIndex++;
                    }

                    ViewState["CurrentTable"] = dtCurrentTable;
                    //grvStudentDetails.DataSource = dtCurrentTable;
                    //grvStudentDetails.DataBind();
                }
            }
            else
            {
                System.Web.HttpContext.Current.Response.Write("ViewState is null");
            }
            //SetPreviousData();
        }

        protected void grvStudentDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (grvStudentDetails.EditIndex == e.Row.RowIndex)
                {

                    DropDownList ddlHPNumber = (DropDownList)e.Row.FindControl("ddlHPNumber");
                    ddlHPNumber.DataSource = GenerateHPIDs();
                    ddlHPNumber.DataBind();
                    ddlHPNumber.SelectedValue = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[10] as String;

                    DropDownList ddlCC = (DropDownList)e.Row.FindControl("ddlCC");
                    ddlCC.SelectedValue = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[3] as String;


                    //ddlOPRType.Items.FindByValue(OPRtype).Selected = true;

                    DropDownList ddlOPREditType = (DropDownList)e.Row.FindControl("ddlOPREditType");
                    if (ddlOPREditType.Items.Count > 0)
                    {
                        String OPRtype = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[7] as String;
                        ddlOPREditType.SelectedValue = OPRtype;

                        DropDownList ddlOPREditSubType = (DropDownList)e.Row.FindControl("ddlOPREditSubType");
                        String OPREditSubType = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[8] as String;
                        if (OPRtype == "Financials")
                        {
                            ddlOPREditSubType.DataSource = AddOPRSubTypeFinancial();
                            ddlOPREditSubType.DataBind();
                            if (!String.IsNullOrEmpty(OPREditSubType))
                            {
                                ddlOPREditSubType.SelectedValue = OPREditSubType;
                            }
                        }
                        else if (OPRtype == "File Maintenance")
                        {
                            ddlOPREditSubType.DataSource = AddOPRSubTypes();
                            ddlOPREditSubType.DataBind();
                            if (!String.IsNullOrEmpty(OPREditSubType))
                            {
                                ddlOPREditSubType.SelectedValue = OPREditSubType;
                            }

                        }
                        else
                        {
                            ddlOPREditSubType.Visible = false;
                        }
                    }

                    DropDownList ddlActionOPR = (DropDownList)e.Row.FindControl("ddlActionOPR");
                    ddlActionOPR.SelectedValue = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[13] as String;

                }

            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                DropDownList ddlOPRSubType = (DropDownList)e.Row.FindControl("ddlOPRSubType");
                ddlOPRSubType.Visible = false;
            }
        }

        protected void ButtonSave_Click(object sender, EventArgs e) //Save Records to List
        {
            GridViewRow row = grvStudentDetails.FooterRow;

            Label lblDoc = (Label)row.FindControl("lblDoc");
            DropDownList ddlAuthorFooter = (DropDownList)row.FindControl("ddlAuthorFooter");
            TextBox txtDateofLetter = (TextBox)row.FindControl("txtFooterDateofLetter");
            TextBox txtCC1 = (TextBox)row.FindControl("txtCC1");//Originator
            DropDownList ddlCC = (DropDownList)row.FindControl("ddlCC");//Typist
            DropDownList ddlOPRType = (DropDownList)row.FindControl("ddlOPRType");
            TextBox txtFinancial = (TextBox)row.FindControl("txtFinancial");
            TextBox txtDateofAction = (TextBox)row.FindControl("txtDateofAction");
            TextBox txtRouteTo = (TextBox)row.FindControl("txtRouteTo");
            TextBox txtDirectTO = (TextBox)row.FindControl("txtDir"); //DirectTO
            TextBox txtAttn = (TextBox)row.FindControl("txtAttn");
            DropDownList ddlHPNumber = (DropDownList)row.FindControl("ddlHPNumber");
            TextBox txtRequestCoordination = (TextBox)row.FindControl("txtRequestCoordination");
            TextBox txtReceivedBy = (TextBox)row.FindControl("txtReceivedBy");
            TextBox txtOPRSubject = (TextBox)row.FindControl("txtOPRSubject");
            //TextBox txtOPRMessage = (TextBox)row.FindControl("txtOPRMessage");
            DropDownList ddlActionOPR = (DropDownList)row.FindControl("ddlActionOPR");
            TextBox txtOther = (TextBox)row.FindControl("txtOther");
            DropDownList ddlOPRSubType = (DropDownList)row.FindControl("ddlOPRSubType");

            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            if (ddlOPRType.SelectedItem.Value == "Financials" && txtFinancial.Text == "")
            {
                errorMessage = "Financial date is mandatory";

            }
            else if (ddlOPRType.SelectedItem.Value == "File Maintainence" && ddlOPRSubType.SelectedItem.Value == "Select")
            {
                errorMessage = "CC is mandatory";
            }
            else if (ddlCC.SelectedItem.Value == "")
            {
                errorMessage = "CC is mandatory";
            }
            else if (txtCC1.Text == "")
            {
                errorMessage = "CC1 is mandatory";
            }
            else if (ddlOPRType.SelectedItem.Value == "")
            {
                errorMessage = "Subject_1 is mandatory";
            }
            else if (ddlActionOPR.SelectedItem.Value == "Other" && txtOther.Text == "")
            {

                errorMessage = "Other type is mandatory";
            }
            else if (txtOPRSubject.Text == "")
            {
                errorMessage = "Subject_2 is mandatory";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {

                Label1.Text = String.Empty;
                ClientContext clientContext = new ClientContext(siteUrl);
                List oList = clientContext.Web.Lists.GetByTitle("Scan List");
                ////List oList = clientContext.Web.Lists.GetByTitle("ScanList");


                /*Start-Scan List Dev*/
                ListItemCreationInformation listCreationInformation = new ListItemCreationInformation();
                CL.ListItem oListItem = oList.AddItem(listCreationInformation);
                String OPRID = GetOPRID();
                oListItem["OPR_Test"] = OPRID;
                oListItem["CCOPR"] = txtCC1.Text;
                oListItem["CC_OPR"] = ddlCC.SelectedValue;
                oListItem["OPR_Date"] = txtDateofLetter.Text;
                oListItem["AuthorOPR"] = ddlAuthorFooter.SelectedValue;
                oListItem["DirectTO"] = txtDirectTO.Text;
                oListItem["OPRType"] = ddlOPRType.SelectedValue;
                oListItem["FinancialOPR"] = txtFinancial.Text;
                oListItem["HP_OPR"] = ddlHPNumber.SelectedValue;
                oListItem["Attn"] = txtAttn.Text;
                oListItem["OPRSubject"] = txtOPRSubject.Text;
                //oListItem["OPRMessage"] = txtOPRMessage.Text;
                oListItem["Action_OPR"] = ddlActionOPR.SelectedValue;
                oListItem["Other_Action"] = txtOther.Text;
                oListItem["ReqCoordination"] = txtRequestCoordination.Text;
                oListItem["ReceivedBy"] = txtReceivedBy.Text;
                oListItem["DateofActionOPR"] = txtDateofAction.Text;
                oListItem["RouteTO"] = txtRouteTo.Text;
                oListItem["OPRStatus"] = "Pending";
                oListItem["OPRSubType"] = ddlOPRSubType.SelectedValue == "Select" ? String.Empty : ddlOPRSubType.SelectedValue; //Hide Select from OPR Types in Subject_1
                /*End-Scan List Dev*/


                oListItem.Update();
                clientContext.ExecuteQuery();
                //Label1.Text = "";
                Label2.Text = "OPR submitted successfully.";
                Page.Response.Redirect(siteUrl + "pages/testgrid.aspx");
                //Page.Response.Redirect(siteUrl + "Pages/OPRformentry.aspx");

                //Label2.Text = "OPR submitted successfully.";
                GetScanListData(DateTime.Now);
                GetHPNumbers();
            }
            else
            {
                Label1.Text = errorMessage;
            }



        }

        protected void ddlOPRType_SelectedIndexChanged(object sender, EventArgs e) //Pre-populate the data based on OPR Type
        {

            DropDownList ddlOPR = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlOPR.Parent.Parent;
            int rowindex = gvr.RowIndex;
            TextBox txt = (TextBox)gvr.Cells[5].FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvr.Cells[8].FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvr.Cells[10].FindControl("txtDir");
            TextBox txt3 = (TextBox)gvr.Cells[11].FindControl("txtAttn");
            DropDownList ddlOPRSubType = (DropDownList)gvr.Cells[5].FindControl("ddlOPRSubType");

            txt4.ReadOnly = true;


            if (ddlOPR.SelectedItem.Value.Equals("Financials"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                txt2.Text = "Linda Hanks";
                txt3.Text = "Keith Hollis";
                txt4.Text = "";
                txt4.Enabled = false;

                ddlOPRSubType.Visible = true;
                ddlOPRSubType.DataSource = AddOPRSubTypeFinancial();
                ddlOPRSubType.DataBind();
            }

            else if (ddlOPR.SelectedItem.Value.Equals("Claims Processing"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Linda Hanks";
                txt3.Text = "";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(30).ToShortDateString();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("File Maintenance"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "John Evans";
                txt3.Text = "Alex Spurlock";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

                ddlOPRSubType.Visible = true;
                ddlOPRSubType.DataSource = AddOPRSubTypes();
                ddlOPRSubType.DataBind();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Provider Rep Visits"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                ddlOPRSubType.Visible = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Keith Hollis";
                txt3.Text = "Cyndi Crockett";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(60).ToShortDateString();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Adjustments"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Linda Hanks";
                txt3.Text = "";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Memo"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt4.ReadOnly = true;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Linda Hanks";
                txt3.Text = "";
                //txt4.Enabled = false;
                txt4.Text = "See Memo";
                txt4.ForeColor = System.Drawing.Color.Black;

            }
            else
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "";
                txt3.Text = "";
                txt4.Text = "";
                txt4.Enabled = false;
            }
        }

        protected void ddlActionOPR_SelectedIndexChanged(object sender, EventArgs e)
        {

            //DropDownList ddlActionOPR = (DropDownList)sender;
            DropDownList ddlActionOPR = (DropDownList)sender;
            DropDownList ddlOPRType = (DropDownList)sender;
            GridViewRow avr = (GridViewRow)ddlActionOPR.Parent.Parent;
            TextBox txt4 = (TextBox)avr.Cells[8].FindControl("txtDateofAction");
            int rowindex = avr.RowIndex;
            if (ddlActionOPR.SelectedItem.Value.Equals("Other"))
            {
                TextBox txt1 = (TextBox)avr.Cells[5].FindControl("txtOther");
                txt1.Enabled = true;
                txt1.BackColor = System.Drawing.Color.Red;
            }
            else if (ddlOPRType.SelectedItem.Value.Equals("Memo"))
            {
                txt4.Text = "See Memo";

            }
            else
            {
                TextBox txt1 = (TextBox)avr.Cells[5].FindControl("txtOther");
                txt1.Enabled = false;
                txt1.Text = string.Empty;
                txt1.BackColor = System.Drawing.Color.Silver;
            }
        }

        protected void grvStudentDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvStudentDetails.ShowFooter = false;
            ButtonSave.Visible = false;
            grvStudentDetails.EditIndex = e.NewEditIndex;
            //GetScanListData();
            DataTable scanTableEdit = ViewState["ScanList"] as DataTable;
            grvStudentDetails.DataSource = scanTableEdit;
            grvStudentDetails.DataBind();
            GetHPNumbers();
        }

        protected void grvStudentDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvStudentDetails.ShowFooter = true;
            ButtonSave.Visible = true;
            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            grvStudentDetails.EditIndex = -1;
            //GetScanListData();
            DataTable scanTableEdit = ViewState["ScanList"] as DataTable;
            grvStudentDetails.DataSource = scanTableEdit;
            grvStudentDetails.DataBind();
            GetHPNumbers();
        }

        protected void grvStudentDetails_RowUpdating(object sender, GridViewUpdateEventArgs e) //Update records upon edit
        {
            grvStudentDetails.ShowFooter = true;
            ButtonSave.Visible = true;
            Label lblID = (Label)grvStudentDetails.Rows[e.RowIndex].FindControl("lblID");
            TextBox txtDateofLetter = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtDateofLetter");
            TextBox txtCC1 = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtCC1");//Originator
            DropDownList ddlCC = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlCC");//Typist
            DropDownList ddlOPREditType = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlOPREditType");
            DropDownList ddlOPREditSubType = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlOPREditSubType");
            TextBox txtFinancial = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtFinancial");
            TextBox txtDateofAction = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtDateofAction");
            TextBox txtRouteTo = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtRouteTo");
            //TextBox txtDirectTO = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtDirectTO");
            TextBox txtDir = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtDir");
            TextBox txtAttn = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtAttn");
            DropDownList ddlHPNumber = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlHPNumber");
            TextBox txtRequestCoordination = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtRequestCoordination");
            TextBox txtReceivedBy = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtReceivedBy");
            TextBox txtOPRSubject = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtOPRSubject");
            DropDownList ddlActionOPR = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlActionOPR");
            TextBox txtOther = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtOther");
            TextBox txtOPRStatus = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtOPRStatus");
            //TextBox txtOPRMessage = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtOPRMessage");

            ClientContext clientContext = new ClientContext(siteUrl);
            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            if (ddlOPREditType.SelectedItem.Value == "Financials" && txtFinancial.Text == "")
            {
                errorMessage = "Financial date is mandatory";

            }
            else if (ddlOPREditType.SelectedItem.Value == "")
            {
                errorMessage = "Subject_1 is mandatory";
            }
            else if (ddlActionOPR.SelectedItem.Value == "Other" && txtOther.Text == "")
            {

                errorMessage = "Other type is mandatory";
            }
            else if (ddlCC.SelectedItem.Value == "")
            {
                errorMessage = "CC is mandatory";
            }
            else if (txtCC1.Text == "")
            {
                errorMessage = "CC1 is mandatory";
            }
            else if (txtOPRSubject.Text == "")
            {
                errorMessage = "Subject_2 is mandatory";
            }
            //else if (txtOPRMessage.Text == "")
            //{
            //    errorMessage = "OPR Message is mandatory";
            //}

            /*Start-Scan List Dev*/
            List oList = clientContext.Web.Lists.GetByTitle("Scan List");
            // List oList = clientContext.Web.Lists.GetByTitle("ScanList");
            if (String.IsNullOrEmpty(errorMessage))
            {
                ButtonSave.Visible = true;
                int scanListID = Convert.ToInt32(lblID.Text);
                CL.ListItem oListItem = oList.GetItemById(scanListID);
                oListItem["CCOPR"] = txtCC1.Text;//Originator
                oListItem["CC_OPR"] = ddlCC.SelectedValue;//Typist
                oListItem["OPR_Date"] = txtDateofLetter.Text;
                oListItem["DirectTO"] = txtDir.Text; //DirectTO
                oListItem["OPRType"] = ddlOPREditType.SelectedValue;
                oListItem["OPRSubType"] = ddlOPREditSubType.SelectedValue == "Select" ? String.Empty : ddlOPREditSubType.SelectedValue;
                oListItem["FinancialOPR"] = txtFinancial.Text;
                oListItem["HP_OPR"] = ddlHPNumber.SelectedValue;
                oListItem["Attn"] = txtAttn.Text;
                oListItem["OPRSubject"] = txtOPRSubject.Text;
                oListItem["Action_OPR"] = ddlActionOPR.SelectedValue;
                oListItem["Other_Action"] = txtOther.Text;
                oListItem["ReqCoordination"] = txtRequestCoordination.Text;
                oListItem["ReceivedBy"] = txtReceivedBy.Text;
                oListItem["DateofActionOPR"] = txtDateofAction.Text;
                oListItem["RouteTO"] = txtRouteTo.Text;
                oListItem["OPRStatus"] = txtOPRStatus.Text;
                //oListItem["OPRMessage"] = txtOPRMessage.Text;
                /*End-Scan List Dev*/

                oListItem.Update();
                clientContext.ExecuteQuery();
                Label1.Text = "";
                Label2.Text = "OPR updated successfully.";


                //Page.Response.Redirect(siteUrl + "Pages/OPRformentry.aspx");

                grvStudentDetails.EditIndex = -1;
                if (txtSubmittedDate.Text.Length > 0)
                {
                    // ViewState["searchDate"] = txtSubmittedDate.Text;
                    DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                    GetScanListData(submittedDate);
                }
                else
                {
                    GetScanListData(DateTime.Now);
                }
                GetHPNumbers();
                //Page.Response.Redirect(siteUrl + "pages/testgrid.aspx");
            }
            else
            {
                ButtonSave.Visible = true;
                Label1.Text = errorMessage;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e) //Need to include Data Not Found
        {
            DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
            GetScanListData(submittedDate);
            GetHPNumbers();
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(siteUrl + "/");
        }

        protected void ddlOPRSubType_SelectedIndexChanged(object sender, EventArgs e)
        {

            TextBox txt = (TextBox)grvStudentDetails.FooterRow.FindControl("txtFinancial");
            TextBox txt4 = (TextBox)grvStudentDetails.FooterRow.FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)grvStudentDetails.FooterRow.FindControl("txtDir");
            TextBox txt3 = (TextBox)grvStudentDetails.FooterRow.FindControl("txtAttn");
            DropDownList ddlOPRType = (DropDownList)grvStudentDetails.FooterRow.FindControl("ddlOPRType");
            DropDownList ddlOPRSubType = (DropDownList)grvStudentDetails.FooterRow.FindControl("ddlOPRSubType");


            if (ddlOPRType.SelectedItem.Value.Equals("Financials") && ddlOPRSubType.SelectedItem.Value.Equals("Lump Sum Payments"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                txt2.Text = "Linda Hanks";
                txt3.Text = "Brenda Nixon";
                txt4.Text = "";
                txt4.Enabled = false;

            }
            if ((ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Max Fee")) || (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Procedure Codes")))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "John Evans";
                txt3.Text = "Alex Spurlock";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Providers"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Allan Holle";
                txt3.Text = "Jeff Kochik";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Sanction of Providers"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Keith Hollis";
                txt3.Text = "Jean Watson";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("New Customery Charge"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Alan Holle";
                txt3.Text = "Jeff Kochik";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Updated Customery Charge"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "";
                txt3.Text = "Linda Hanks";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Nursing Home Rate Changes"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "";
                txt3.Text = "Jeff Kochik";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

            }
        }

        protected void ddlOPREditType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlOPREditType = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlOPREditType.Parent.Parent;
            int rowindex = gvr.RowIndex;
            TextBox txt = (TextBox)gvr.Cells[5].FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvr.Cells[8].FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvr.Cells[10].FindControl("txtDir");
            TextBox txt3 = (TextBox)gvr.Cells[11].FindControl("txtAttn");
            DropDownList ddlOPREditSubType = (DropDownList)gvr.Cells[5].FindControl("ddlOPREditSubType");
            txt4.ReadOnly = true;

            if (ddlOPREditType.SelectedItem.Value.Equals("Financials"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                txt2.Text = "Linda Hanks";
                txt3.Text = "Keith Hollis";
                txt4.Text = "";
                txt4.Enabled = false;

                ddlOPREditSubType.Visible = true;
                ddlOPREditSubType.DataSource = AddOPRSubTypeFinancial();
                ddlOPREditSubType.DataBind();
            }


            else if (ddlOPREditType.SelectedItem.Value.Equals("Claims Processing"))
            {
                txt.Text = String.Empty;
                ddlOPREditSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "Linda Hanks";
                txt3.Text = "";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(30).ToShortDateString();

            }
            else if (ddlOPREditType.SelectedItem.Value.Equals("File Maintenance"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "John Evans";
                txt3.Text = "Alex Spurlock";
                txt4.Enabled = true;
                txt4.Text = System.DateTime.Now.AddDays(14).ToShortDateString();

                ddlOPREditSubType.Visible = true;
                ddlOPREditSubType.DataSource = AddOPRSubTypes();
                ddlOPREditSubType.DataBind();

            }
        }


        protected void ddlOPREditSubType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //String errorMessage = String.Empty;
            DropDownList ddlOPREditSubType = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlOPREditSubType.Parent.Parent;
            DropDownList ddlOPREditType = (DropDownList)gvr.Cells[5].FindControl("ddlOPREditType");
            TextBox txt = (TextBox)gvr.Cells[5].FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvr.Cells[8].FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvr.Cells[10].FindControl("txtDir");
            TextBox txt3 = (TextBox)gvr.Cells[11].FindControl("txtAttn");
            if (ddlOPREditType.SelectedItem.Value.Equals("Financials") && ddlOPREditSubType.SelectedItem.Value.Equals("Lump Sum Payments"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                txt2.Text = "Linda Hanks";
                txt3.Text = "Brenda Nixon";
                txt4.Text = "";
                txt4.Enabled = false;

            }
            //else if (ddlOPREditType.SelectedItem.Value == "Financials" && ddlOPREditSubType.SelectedItem.Value == "Select")
            //{
            //    //errorMessage = "Please select";
            //    //Label1.Text = errorMessage;
            //}
        }

        //public static void CombineMultiplePDFs(string[] fileNames, string outFile)
        //{
        //    // step 1: creation of a document-object
        //    Document document = new Document();

        //    // step 2: we create a writer that listens to the document
        //    PdfCopy writer = new PdfCopy(document, new FileStream(outFile, FileMode.Create));
        //    if (writer == null)
        //    {
        //        return;
        //    }

        //    // step 3: we open the document
        //    document.Open();

        //    foreach (string fileName in fileNames)
        //    {
        //        // we create a reader for a certain document
        //        PdfReader reader = new PdfReader(fileName);
        //        reader.ConsolidateNamedDestinations();

        //        // step 4: we add content
        //        for (int i = 1; i <= reader.NumberOfPages; i++)
        //        {
        //            PdfImportedPage page = writer.GetImportedPage(reader, i);
        //            writer.AddPage(page);
        //        }

        //        PRAcroForm form = reader.AcroForm;
        //        if (form != null)
        //        {
        //            writer.CopyDocumentFields(reader);
        //        }

        //        reader.Close();
        //    }
        //}

        public static void CreateMergedPDF(string targetPDF, string sourceDir)
        {
            List<Int32> pageindex = new List<Int32>();
            pageindex.Add(1);
            using (FileStream stream = new FileStream(targetPDF, FileMode.Create))
            {
                iTextSharp.text.Document pdfDoc = new iTextSharp.text.Document(iTextSharp.text.PageSize.A4);
                iTextSharpNS.PdfCopy pdf = new iTextSharpNS.PdfCopy(pdfDoc, stream);
                pdfDoc.Open();
                var files = Directory.GetFiles(sourceDir);
                Console.WriteLine("Merging files count: " + files.Length);
                int i = 1;
                foreach (string file in files)
                {
                    Console.WriteLine(i + ". Adding: " + file);
                    pdf.AddDocument(new iTextSharpNS.PdfReader(file), pageindex);
                    i++;
                }

                if (pdfDoc != null)
                    pdfDoc.Close();

                Console.WriteLine("SpeedPASS PDF merge complete.");
            }
        }
        public static bool CreateMergedPDF1(IEnumerable<string> fileNames, string targetPdf)
        {
            bool merged = true;
            using (FileStream stream = new FileStream(targetPdf, FileMode.Create))
            {
                iTextSharp.text.Document document = new iTextSharp.text.Document();
                iTextSharpNS.PdfCopy pdf = new iTextSharpNS.PdfCopy(document, stream);
                iTextSharpNS.PdfReader reader = null;
                try
                {
                    document.Open();
                    foreach (string file in fileNames)
                    {
                        reader = new iTextSharpNS.PdfReader(file);
                        pdf.AddDocument(reader);
                        reader.Close();
                    }
                }
                catch (Exception)
                {
                    merged = false;
                    if (reader != null)
                    {
                        reader.Close();
                    }
                }
                finally
                {
                    if (document != null)
                    {
                        document.Close();
                    }
                }
            }
            return merged;
        }
        public static void CreateMergedPDF2(List<String> InFiles, String OutFile)
        {
            using (FileStream stream = new FileStream(OutFile, FileMode.Create))
            using (iTextSharp.text.Document doc = new iTextSharp.text.Document())
            using (iTextSharpNS.PdfCopy pdf = new iTextSharpNS.PdfCopy(doc, stream))
            {
                doc.Open();

                iTextSharpNS.PdfReader reader = null;
                iTextSharpNS.PdfImportedPage page = null;

                InFiles.ForEach(file =>
                  {
                      reader = new iTextSharpNS.PdfReader(file);

                      for (int i = 0; i < reader.NumberOfPages; i++)
                      {
                          page = pdf.GetImportedPage(reader, i + 1);
                          pdf.AddPage(page);
                      }

                      pdf.FreeReader(reader);
                      reader.Close();
                  });

            }
        }
    }
}
