﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Text;



namespace Medicaid_OPRForm.HPEEntry
{
    [ToolboxItemAttribute(false)]
    public partial class HPEEntry : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public HPEEntry()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        public void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GenerateOPRIDs(ddlOPRNumber);
                if (grvStudentDetails.Rows.Count == 0)
                {
                    GetHPEntryDetails();
                }
            }
        }
        public void GetHPEntryDetails()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList scanList = currentWeb.Lists["HPE"];
                        SPQuery query = new SPQuery();
                        //SPListItemCollection listColl = scanList.GetItems(query);
                        List<SPListItem> listItems = (from SPListItem item in scanList.Items
                                                      select item).ToList();
                        var OPRlistColl = listItems.Where(s => Convert.ToDateTime(s["Created"]).Date == DateTime.Now.Date).ToList();
                        if (OPRlistColl != null)
                        {

                            DataTable OPRTable = new DataTable();
                            DataRow dr = null;
                            OPRTable.Columns.Add(new DataColumn("ID", typeof(string)));
                            OPRTable.Columns.Add(new DataColumn("Author_HPE", typeof(string)));
                            OPRTable.Columns.Add(new DataColumn("DateReceived", typeof(string)));
                            OPRTable.Columns.Add(new DataColumn("EDS_Number", typeof(string)));
                            OPRTable.Columns.Add(new DataColumn("OPR_Number", typeof(string)));
                            OPRTable.Columns.Add(new DataColumn("Subject_HPE", typeof(string)));

                            foreach (var item in OPRlistColl)
                            {

                                dr = OPRTable.NewRow();
                                dr["ID"] = Convert.ToString(item["ID"]);
                                dr["Author_HPE"] = Convert.ToString(item["Author_HPE"]);
                                dr["DateReceived"] = Convert.ToString(item["DateReceived"]);
                                dr["EDS_Number"] = Convert.ToString(item["EDS_Number"]);
                                dr["OPR_Number"] = Convert.ToString(item["OPR_Number"]);
                                dr["Subject_HPE"] = Convert.ToString(item["Subject_HPE"]);

                                OPRTable.Rows.Add(dr);

                            }


                            grvStudentDetails.DataSource = OPRTable;
                            grvStudentDetails.DataBind();
                            ViewState["HPEntryDetails"] = OPRTable;
                        }
                        else
                        {
                            DataTable dt = new DataTable();
                            grvStudentDetails.DataSource = dt;
                            grvStudentDetails.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*Generate OPRID*/
        public void GenerateOPRIDs(DropDownList dropdownOPRNumber)
        {
            dropdownOPRNumber.DataSource = GetOPRIDCollection();
            dropdownOPRNumber.DataBind();
        }
        protected System.Web.UI.WebControls.ListItemCollection GetOPRIDCollection()
        {
            int i = 0;
            System.Web.UI.WebControls.ListItemCollection coll = new System.Web.UI.WebControls.ListItemCollection();
            ClientContext context = new ClientContext(siteUrl);
            List announcementsList = context.Web.Lists.GetByTitle("Scan List");
            CamlQuery query = CamlQuery.CreateAllItemsQuery(1000000);
            CL.ListItemCollection items = announcementsList.GetItems(query);
            context.Load(items);
            context.ExecuteQuery();
            foreach (CL.ListItem listItem in items)
            {
                if (i == 0)
                {
                    coll.Insert(i, new System.Web.UI.WebControls.ListItem("Please select"));
                }
                else
                {
                    coll.Insert(i, new System.Web.UI.WebControls.ListItem(listItem["OPR_Test"].ToString()));
                }
                i++;
            }
            //coll.Insert(0, String.Empty);
            return coll;
        }

        public void ButtonSave_Click(object sender, EventArgs e) //Save Records to List
        {
            String errorMessage = String.Empty;
            //if (txtAuthorHPE.Text == "")
            //{
            //    errorMessage = "";
            //}
            if (txtDateReceived.Text == "")
            {
                errorMessage = "Please enter date received";
            }
            else if (txtEDSNumber.Text == "")
            {
                errorMessage = "Please enter HP Number";
            }
            else if (txtSubject.Text == "")
            {
                errorMessage = "Please enter Subject";
            }
            else if (txtAuthorHPE.Text == "")
            {
                errorMessage = "Please enter Author";
            }
            //else if (ddlOPRNumber.SelectedItem.Value == "Please select")
            //{
            //    errorMessage = "";
            //}
            
            if (String.IsNullOrEmpty(errorMessage))
            {

                lblErrorMessage.Text = String.Empty;
                ClientContext clientContext = new ClientContext(siteUrl);
                List oList = clientContext.Web.Lists.GetByTitle("HPE");
                ListItemCreationInformation listCreationInformation = new ListItemCreationInformation();
                CL.ListItem oListItem = oList.AddItem(listCreationInformation);

                oListItem["Author_HPE"] = txtAuthorHPE.Text;
                oListItem["DateReceived"] = DateTime.Parse(txtDateReceived.Text);
                oListItem["EDS_Number"] = "HP-" + txtEDSNumber.Text;
                if (ddlOPRNumber.SelectedValue != "Please select")
                {
                    oListItem["OPR_Number"] = ddlOPRNumber.SelectedItem.Value;
                }
                else 
                {
                    oListItem["OPR_Number"] = "";
                }
                //oListItem["OPR_Number"] = ddlOPRNumber.SelectedItem.Value;
                oListItem["Subject_HPE"] = txtSubject.Text;

                oListItem.Update();
                clientContext.ExecuteQuery();
                lblSuccessMessage.Text = "HP Request submitted successfully.";
                //Page.Response.Redirect(siteUrl + "/Pages/hpentry.aspx");
                Page.Response.Redirect(siteUrl + "/Pages/hpentry.aspx");

                GetHPEntryDetails();

            }
            else
            {
                lblErrorMessage.Text = errorMessage;
            }
        }

        protected void grvStudentDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvStudentDetails.EditIndex = e.NewEditIndex;
            DataTable dtHPEntryDetails = ViewState["HPEntryDetails"] as DataTable;
            grvStudentDetails.DataSource = dtHPEntryDetails;
            grvStudentDetails.DataBind();
            GetHPEntryDetails();
            //DropDownList ddlEditOPRNumber = (DropDownList)grvStudentDetails.Rows[e.NewEditIndex].FindControl("ddlEditOPRNumber");
            //GenerateOPRIDs(ddlEditOPRNumber);
        }

        protected void grvStudentDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvStudentDetails.EditIndex = -1;
            DataTable dtHPEntryDetails = ViewState["HPEntryDetails"] as DataTable;
            grvStudentDetails.DataSource = dtHPEntryDetails;
            grvStudentDetails.DataBind();
            GetHPEntryDetails();

        }

        protected void grvStudentDetails_RowUpdating(object sender, GridViewUpdateEventArgs e) //Update records upon edit
        {

            btnSave.Visible = true;
            TextBox txtEditAuthorHPE = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtEditAuthorHPE");
            TextBox txtEditSubject = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtEditSubject");
            DropDownList ddlEditOPRNumber = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlEditOPRNumber");
            HiddenField hiddenItemID = (HiddenField)grvStudentDetails.Rows[e.RowIndex].FindControl("hiddenID");
            
            String errorMessage = String.Empty;

            if (txtEditAuthorHPE.Text == "")
            {
                errorMessage = "Please Enter Author";
            }
            else if (txtEditSubject.Text == "")
            {
                errorMessage = "Please Enter Subject";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {

                lblErrorMessage.Text = String.Empty;
                ClientContext clientContext = new ClientContext(siteUrl);
                List oList = clientContext.Web.Lists.GetByTitle("HPE");

                int listItemID = Convert.ToInt32(hiddenItemID.Value);
                CL.ListItem oListItem = oList.GetItemById(listItemID);
                oListItem["Author_HPE"] = txtEditAuthorHPE.Text;
                oListItem["Subject_HPE"] = txtEditSubject.Text;
                if (ddlEditOPRNumber.SelectedValue != "Please select")
                {
                    oListItem["OPR_Number"] = ddlEditOPRNumber.SelectedItem.Value;
                }
                else
                {
                    oListItem["OPR_Number"] = "";
                }

                oListItem.Update();
                clientContext.ExecuteQuery();
                lblSuccessMessage.Text = "HP Request updated successfully.";
                //Page.Response.Redirect(siteUrl + "/Pages/hpentry.aspx");
                Page.Response.Redirect(siteUrl + "/Pages/hpentry.aspx");

                GetHPEntryDetails();

            }
            else
            {
                lblErrorMessage.Text = errorMessage;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            GetHPEntryDetails();
        }

        protected void grvStudentDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (grvStudentDetails.EditIndex == e.Row.RowIndex)
                {

                    DropDownList ddlEditOPRNumber = (DropDownList)e.Row.FindControl("ddlEditOPRNumber");
                    GenerateOPRIDs(ddlEditOPRNumber);
                    ddlEditOPRNumber.SelectedValue = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[4] as String;

                }
                else
                {
                    Label lblDateReceived = (Label)e.Row.FindControl("lblDateReceived");
                    lblDateReceived.Text = DateTime.Parse(((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[2] as String).ToShortDateString();
                }
            }
            
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            //Page.Response.Redirect(siteUrl + "/");

            if (FileUpload1.HasFile)
            {
                string file = FileUpload1.FileName;
                //FileUpload1.SaveAs(Page.Server.MapPath(file));

                StringBuilder pdfText = new StringBuilder();
                PdfReader reader = new PdfReader(@"C:\Users\txrapaka\Desktop\showdoc.pdf");

                for (int i = 1; i <= reader.NumberOfPages; i++)
                {
                    ITextExtractionStrategy objExtractStrategy = new SimpleTextExtractionStrategy();
                    string strLineText = PdfTextExtractor.GetTextFromPage(reader, i, objExtractStrategy);
                    strLineText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(strLineText)));
                    pdfText.Append(strLineText);
                }

                reader.Close();
                //Label1.Text = pdfText.ToString();

            }
        }
          

    }
}
