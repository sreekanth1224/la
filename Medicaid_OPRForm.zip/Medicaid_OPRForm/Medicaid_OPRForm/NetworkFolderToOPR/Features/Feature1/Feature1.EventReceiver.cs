using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration;

namespace NetworkFolderToOPR.Features.Feature1
{
    /// <summary>
    /// This class handles events raised during feature activation, deactivation, installation, uninstallation, and upgrade.
    /// </summary>
    /// <remarks>
    /// The GUID attached to this class may be used during packaging and should not be modified.
    /// </remarks>

    [Guid("b715abe0-1458-4558-877c-8c10d4fd5593")]
    public class Feature1EventReceiver : SPFeatureReceiver
    {
        // Uncomment the method below to handle the event raised after a feature has been activated.


        const string JOB_NAME = "NetworkFolderToOPRJOB";
        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
             {
                 SPWebApplication webApp = properties.Feature.Parent as SPWebApplication;
                 
                 foreach (SPJobDefinition job in webApp.JobDefinitions)
                 {
                     if (job.Name == JOB_NAME)
                     {
                         job.Delete();
                     }
                 }

                 SPWebService myService = SPWebService.ContentService;
                 myService.RemoteAdministratorAccessDenied = false;
                 myService.Update();

                 //NWFolderToOPR networkFolderJob = new NWFolderToOPR(JOB_NAME, SPFarm.Local.TimerService, webApp.Farm.Servers[""], SPJobLockType.Job);

                 NWFolderToOPR networkFolderJob = new NWFolderToOPR(JOB_NAME, webApp, webApp.Farm.Servers["qsp13wfe1.ms-medicaid.al"], SPJobLockType.Job);
                 SPMinuteSchedule networkFolderSchedule = new SPMinuteSchedule();
                 networkFolderSchedule.BeginSecond = 0;
                 networkFolderSchedule.EndSecond = 59;
                 networkFolderSchedule.Interval = 55;
                 networkFolderJob.Schedule = networkFolderSchedule;
                 networkFolderJob.Update();

                 //foreach (SPServer server in SPFarm.Local.Servers)
                 //{
                 //    if (server.Role == SPServerRole.WebFrontEnd)
                 //    {
                 //        NWFolderToOPR networkFolderJob = new NWFolderToOPR(JOB_NAME, SPFarm.Local.TimerService, server, SPJobLockType.Job);
                 //        SPMinuteSchedule networkFolderSchedule = new SPMinuteSchedule();
                 //        networkFolderSchedule.BeginSecond = 0;
                 //        networkFolderSchedule.EndSecond = 59;
                 //        networkFolderSchedule.Interval = 55;
                 //        networkFolderJob.Schedule = networkFolderSchedule;
                 //        networkFolderJob.Update();
                 //    }
                 //}

             });

        }
        // Uncomment the method below to handle the event raised before a feature is deactivated.

        public override void FeatureDeactivating(SPFeatureReceiverProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                SPWebApplication webApp = properties.Feature.Parent as SPWebApplication;
                // delete the job
                foreach (SPJobDefinition job in webApp.JobDefinitions)
                {
                    if (job.Name == JOB_NAME)
                    {
                        job.Delete();
                    }
                }
            });
        }


        // Uncomment the method below to handle the event raised after a feature has been installed.

        //public override void FeatureInstalled(SPFeatureReceiverProperties properties)
        //{
        //}


        // Uncomment the method below to handle the event raised before a feature is uninstalled.

        //public override void FeatureUninstalling(SPFeatureReceiverProperties properties)
        //{
        //}

        // Uncomment the method below to handle the event raised when a feature is upgrading.

        //public override void FeatureUpgrading(SPFeatureReceiverProperties properties, string upgradeActionName, System.Collections.Generic.IDictionary<string, string> parameters)
        //{
        //}
    }
}
