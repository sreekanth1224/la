﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using Medicaid_OPRForm.Utility;
using System.IO;
//using iTextSharpNS = iTextSharp.text.pdf;
using System.Net;
using itextSharpText = iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.Net.Mail;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.WebControls;


namespace Medicaid_OPRForm.VisualWebPart1
{
    [ToolboxItemAttribute(false)]
    public partial class VisualWebPart1 : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public VisualWebPart1()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        //String userID = "txrapaka";
        //String pwd = "Prattville@1";
        //String domain = "SPDev";
        String userID = "svc.sp.appservice";
        String pwd = "@this40r";
        String domain = "MS-Medicaid";
        Int32 pageIndex = 0;   //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        DateTime searchDate = DateTime.Now;
        Dictionary<String, String> OPRTypeAssignee = new Dictionary<String, String>();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                if (gvOPRDeatils.Rows.Count == 0)
                {
                    GetScanListData(searchDate, null, null);
                    //OPRTypeAssignee = GetOPRTypeAssignees();
                    //HttpContext.Current.Session["Assignees"] = OPRTypeAssignee.ToList();
                    //GetHPNumbers();
                }
                else
                {
                    //GetHPNumbers();
                }
            }

        }

        public List<String> AddOPRSubTypes()
        {
            List<String> listOPRSubType = new List<String>();
            listOPRSubType.Add("Select");
            listOPRSubType.Add("Max Fee");
            listOPRSubType.Add("Procedure Codes");
            listOPRSubType.Add("Providers");
            listOPRSubType.Add("Sanction of Providers");
            listOPRSubType.Add("New Customary Charge");
            listOPRSubType.Add("Updated Customary Charge");
            listOPRSubType.Add("Nursing Home Rate Changes");
            return listOPRSubType;
        }

        public List<String> AddOPRSubTypeFinancial()
        {
            List<String> listOPRSubTypeFinancial = new List<String>();
            listOPRSubTypeFinancial.Add("Select");
            listOPRSubTypeFinancial.Add("Lump Sum Payments");
            return listOPRSubTypeFinancial;
        }

        //public void GetHPNumbers()
        //{
        //     GridViewRow row = gvOPRDeatils.FooterRow;
        //     DropDownList ddl = (DropDownList)row.FindControl("ddlHPNumber");
        //     Dictionary<String, String> listCollection = GenerateHPIDs();
        //     if (listCollection.Count > 0)
        //     {
        //         ddl.DataSource = listCollection;
        //         ddl.DataTextField = "Key";
        //         ddl.DataValueField = "Value";
        //         ddl.DataBind();

        //         ddl.SelectedValue = String.Empty;
        //     }
        //}
        public Dictionary<String, String> GetOPRTypeAssignees()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList HPEList = currentWeb.Lists["OPR Types"];
                    SPQuery camlQuery = new SPQuery();
                    String strOPRTypes = String.Empty;
                    String strAssigness = String.Empty;
                    SPListItemCollection itemColl = HPEList.GetItems(camlQuery);

                    if (itemColl != null && itemColl.Count > 0)
                    {
                        foreach (SPListItem item in itemColl)
                        {
                            strOPRTypes = Convert.ToString(item["OPRtype"]) + ":" + Convert.ToString(item["SubType"]);
                            strAssigness = Convert.ToString(item["DirectedTo"]) + ":" + Convert.ToString(item["Attn"]);
                            OPRTypeAssignee.Add(strOPRTypes, strAssigness);
                        }
                    }
                }
            }
            return OPRTypeAssignee;
        }

        public Int32 GetHPEID(String EDSNumber)
        {
            Int32 HPEID = 0;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList HPEList = currentWeb.Lists["HPE"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                         "<Eq>" +
                                            "<FieldRef Name='EDS_Number'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                            "<Value Type='Text'>" + EDSNumber + "</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = HPEList.GetItems(camlQuery);

                    if (itemColl != null && itemColl.Count > 0)
                    {
                        HPEID = Convert.ToInt32(itemColl[0]["ID"]);
                    }
                }
            }
            return HPEID;
        }

        public String GetAuthor() //OPR Author
        {
            String authorName = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanList = currentWeb.Lists["OPRAuthor"];
                    SPQuery query = new SPQuery();
                    query.DatesInUtc = false;
                    SPListItemCollection listColl = scanList.GetItems(query);
                    if (listColl.Count > 0)
                    {
                        authorName = Convert.ToString(listColl[0]["Title"]);
                    }
                }
            }
            return authorName;
        }

        public void GetScanListData(DateTime requestedDate, SPListItemCollectionPosition itemPoistion, String paging) //Get Date specific List data 
        {
            try
            {
                pageIndex = 0;
                String loginName = String.Empty;
                Int32 recordsPerPage = Convert.ToInt32(ddlRecordsPerPage.SelectedValue);
                String strQuery = String.Empty;
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {

                        SPUser currentUser = currentWeb.CurrentUser; //Dispaly Typist Initials upon LoginName
                        loginName = currentUser.Name;

                        SPList scanList = currentWeb.Lists["Scan List"];
                        itemCount = scanList.ItemCount;
                        totalPages = itemCount / recordsPerPage;

                        String fromDate = requestedDate.Date.AddDays(-1).ToShortDateString();
                        String toDate = requestedDate.Date.ToShortDateString();
                        TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:30:00"));
                        if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                        {
                            fromDate = requestedDate.Date.ToShortDateString();
                            toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            gvOPRDeatils.ShowFooter = true;
                        }
                        else if (requestedDate.Date.DayOfWeek == DayOfWeek.Monday)
                        {
                            if (requestedDate.Date < DateTime.Now.Date)
                            {
                                gvOPRDeatils.ShowFooter = false;
                            }
                            fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                        }
                        else if (requestedDate.Date.ToShortDateString() == DateTime.Now.Date.ToShortDateString())
                        {
                            gvOPRDeatils.ShowFooter = true;
                        }
                        else
                        {
                            gvOPRDeatils.ShowFooter = false;
                        }

                        if (!String.IsNullOrEmpty(txtSubmittedDate.Text) && !String.IsNullOrEmpty(txtSearchOPR.Text))
                        {
                            strQuery = "<Where>" +
                                                "<And>" +
                                                    "<Contains>" +
                                                         "<FieldRef Name='OPR_Test'/>" +
                                                         "<Value Type='Text'>" + txtSearchOPR.Text + "</Value>" +
                                                    "</Contains>" +
                                                    "<And>" +
                                                    "<Geq>" +
                                                         "<FieldRef Name='Created'/>" +
                                                         "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:30:00")) + "</Value>" +
                                                    "</Geq>" +
                                                     "<Leq>" +
                                                         "<FieldRef Name='Created'/>" +
                                                         "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(toDate + " 14:30:00")) + "</Value>" +
                                                    "</Leq>" +
                                                    "</And>" +
                                                 "</And>" +
                                        "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtSubmittedDate.Text) && String.IsNullOrEmpty(txtSearchOPR.Text))
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:30:00")) + "</Value>" +
                                                "</Geq>" +
                                                 "<Leq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(toDate + " 14:30:00")) + "</Value>" +
                                                "</Leq>" +
                                            "</And>" +
                                        "</Where>";
                        }
                        else if (String.IsNullOrEmpty(txtSubmittedDate.Text) && !String.IsNullOrEmpty(txtSearchOPR.Text))
                        {
                            strQuery = "<Where>" +
                                           "<Contains>" +
                                                "<FieldRef Name='OPR_Test'/>" +
                                                 "<Value Type='Text'>" + txtSearchOPR.Text + "</Value>" +
                                            "</Contains>" +
                                       "</Where>";
                        }
                        else
                        {
                            strQuery = "<Where>" +
                                          "<And>" +
                                              "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:30:00")) + "</Value>" +
                                              "</Geq>" +
                                               "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(toDate + " 14:30:00")) + "</Value>" +
                                              "</Leq>" +
                                          "</And>" +
                                      "</Where>";
                        }


                        SPQuery query = new SPQuery();
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.RowLimit = Convert.ToUInt32(recordsPerPage);
                        query.DatesInUtc = false;
                        query.ViewFields = string.Concat(
                                   "<FieldRef Name='OPR_Test' />",
                                   "<FieldRef Name='ID' />",
                                   "<FieldRef Name='CCOPR' />",
                                   "<FieldRef Name='CC_OPR' />",
                                   "<FieldRef Name='Proofer' />",
                                   "<FieldRef Name='OPR_Date' />",
                                   "<FieldRef Name='AuthorOPR' />",
                                   "<FieldRef Name='Approver' />",
                                   "<FieldRef Name='DirectTO' />",
                                   "<FieldRef Name='OPRType' />",
                                   "<FieldRef Name='OPRSubType' />",
                                   "<FieldRef Name='FinancialOPR' />",
                                   "<FieldRef Name='HP_OPR' />",
                                   "<FieldRef Name='HPE_ID' />",
                                   "<FieldRef Name='Attn' />",
                                    "<FieldRef Name='OPRSubject' />",
                                    "<FieldRef Name='OPRMessage' />",
                                    "<FieldRef Name='Action_OPR' />",
                                    "<FieldRef Name='Other_Action' />",
                                    "<FieldRef Name='ReceivedBy' />",
                                    "<FieldRef Name='DateofActionOPR' />",
                                    "<FieldRef Name='OPRStatus' />",
                                    "<FieldRef Name='PickUp' />",
                                    "<FieldRef Name='OPRCC' />",
                                    "<FieldRef Name='FinancialSeeMemo' />",
                                    "<FieldRef Name='ApprovalStatus' />",
                                    "<FieldRef Name='Created' />");
                        query.ViewFieldsOnly = true;

                        if (itemPoistion != null)
                        {
                            query.ListItemCollectionPosition = itemPoistion;
                        }
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null && listColl.Count > 0)
                        {
                            DataView view = listColl.GetDataTable().DefaultView;
                            //view.Sort = "ID DESC";
                            DataTable sortedScanTable = view.ToTable();
                            ViewState["ScanList"] = sortedScanTable;
                            itemPoistion = listColl.ListItemCollectionPosition;
                            if (itemPoistion != null)
                            {
                                if (paging == null)
                                {
                                    ViewState["Next"] = null;
                                    ViewState["Prev"] = null;
                                    pageIndex = 0;
                                }
                                if (paging == null || paging == "next")
                                {
                                    strPageInfo = Convert.ToString(ViewState["Next"]);
                                    if (strPageInfo.IndexOf("index") > 0)
                                    {
                                        pageIndex = Convert.ToInt32(strPageInfo.Split('=')[3]);
                                        pageIndex++;
                                    }
                                    ViewState["Next"] = itemPoistion.PagingInfo + "&index=" + pageIndex;
                                    ViewState["Prev"] = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}&index={1}", listColl[0].ID.ToString(), pageIndex);
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    strPageInfo = Convert.ToString(ViewState["Prev"]);
                                    if (strPageInfo.IndexOf("index") > 0)
                                    {
                                        pageIndex = Convert.ToInt32(strPageInfo.Split('=')[4]);
                                        pageIndex--;
                                    }
                                    ViewState["Next"] = String.Format(itemPoistion.PagingInfo + "&index={0}", pageIndex);
                                    ViewState["Prev"] = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}&index={1}", listColl[0].ID.ToString(), pageIndex);
                                }

                            }
                            else
                            {
                                strPageInfo = Convert.ToString(ViewState["Next"]);
                                if (strPageInfo.IndexOf("index") > 0)
                                {
                                    pageIndex = Convert.ToInt32(strPageInfo.Split('=')[3]);
                                    pageIndex++;
                                }
                            }
                            if (itemCount > recordsPerPage)
                            {
                                btnNext.Visible = true;
                                btnPrevious.Visible = true;
                                btnPrevious.Enabled = false;
                            }

                            if ((paging == null) || (paging == "prev" && pageIndex == 0))
                            {
                                btnPrevious.Enabled = false;
                                btnNext.Enabled = true;
                            }
                            else
                            {
                                btnPrevious.Enabled = true;
                            }
                            if (paging == "next" && pageIndex == totalPages)
                            {
                                btnNext.Enabled = false;
                                btnPrevious.Enabled = true;
                            }
                            if (sortedScanTable.Rows.Count < 10)
                            {
                                btnNext.Visible = false;
                                btnPrevious.Visible = false;
                            }
                            gvOPRDeatils.PageSize = recordsPerPage;
                            gvOPRDeatils.DataSource = sortedScanTable;
                            gvOPRDeatils.DataBind();
                        }
                        else
                        {
                            FirstGridViewRow(); //Set empty grid If there are no records
                            gvOPRDeatils.Rows[0].Cells[0].Visible = false;
                        }
                        //Disable Resubmit column on page load
                        gvOPRDeatils.Columns[1].Visible = false;
                        //add date to the footer
                        GridViewRow row = gvOPRDeatils.FooterRow;
                        TextBox txtfooterDate = row.FindControl("txtFooterDateofLetter") as TextBox;
                        String dateOfLetter = String.Empty;
                        if ((DateTime.Now.Hour >= 14 && DateTime.Now.Minute >= 30) || (DateTime.Now.Hour >= 15))
                        {
                            if (Convert.ToString(DateTime.Now.DayOfWeek) == "Friday")   //Check for next business day
                            {
                                dateOfLetter = DateTime.Now.Date.AddDays(3).ToShortDateString();
                            }
                            else
                            {
                                dateOfLetter = DateTime.Now.Date.AddDays(1).ToShortDateString();
                            }
                            txtfooterDate.Text = dateOfLetter;
                        }
                        else
                        {
                            txtfooterDate.Text = DateTime.Now.Date.ToShortDateString();
                        }

                        if (!String.IsNullOrEmpty(loginName)) //Typist by Login Name - Login Name Sort
                        {
                            DropDownList ddlCC = (DropDownList)row.FindControl("ddlCC");
                            ddlCC.DataSource = GetTypistNames();
                            ddlCC.DataTextField = "Key";
                            ddlCC.DataValueField = "Value";
                            ddlCC.DataBind();

                            if (!loginName.Contains(','))
                            {
                                String[] loginNameArray = loginName.Split(' ');
                                loginName = loginNameArray[1] + ", " + loginNameArray[0];
                            }
                            ddlCC.SelectedValue = loginName;

                        }

                        DropDownList ddlProofer = (DropDownList)row.FindControl("ddlProofer");
                        ddlProofer.DataSource = GetOPRProofers();
                        ddlProofer.DataTextField = "Key";
                        ddlProofer.DataValueField = "Value";
                        ddlProofer.DataBind();

                        DropDownList ddlApproverFooter = (DropDownList)row.FindControl("ddlApproverFooter");
                        ddlApproverFooter.DataSource = GetOPRApprovers();
                        ddlApproverFooter.DataTextField = "Key";
                        ddlApproverFooter.DataValueField = "Value";
                        ddlApproverFooter.DataBind();

                        Label lblAuthorFooter = (Label)row.FindControl("lblAuthorFooter");
                        lblAuthorFooter.Text = GetAuthor();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Dictionary<String, String> GetTypistNames()
        {
            Dictionary<String, String> dictionaryCollection = new Dictionary<String, String>();
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {

                    SPList scanList = currentWeb.Lists["Typist"];
                    SPQuery query = new SPQuery();
                    query.DatesInUtc = false;
                    SPListItemCollection listColl = scanList.GetItems(query);
                    if (listColl != null)
                    {
                        DataRow[] dataRows = listColl.GetDataTable().Select();
                        foreach (DataRow dataRow in dataRows)
                        {
                            if (!dictionaryCollection.ContainsValue(Convert.ToString(dataRow["LastName"] + ", " + dataRow["FirstName"])))
                            {
                                dictionaryCollection.Add(Convert.ToString(dataRow["TypistInitials"]), Convert.ToString(dataRow["LastName"] + ", " + dataRow["FirstName"]));
                            }
                        }
                        dictionaryCollection.Add(String.Empty, String.Empty);
                    }
                }
            }

            return dictionaryCollection;

        }

        public Dictionary<String, String> GetOPRApprovers()  //Get ShortName by passing Name from 'OPR Approvers' list
        {
            Dictionary<String, String> dictionaryCollection = new Dictionary<String, String>();
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {

                    SPList scanList = currentWeb.Lists["OPR Approvers"];
                    SPQuery query = new SPQuery();
                    query.DatesInUtc = false;
                    SPListItemCollection listColl = scanList.GetItems(query);
                    if (listColl != null)
                    {
                        DataRow[] dataRows = listColl.GetDataTable().Select();
                        foreach (DataRow dataRow in dataRows)
                        {
                            if (!dictionaryCollection.ContainsKey(Convert.ToString(dataRow["Name"])))
                            {
                                dictionaryCollection.Add(Convert.ToString(dataRow["Name"]), Convert.ToString(dataRow["ShortName"]));
                            }
                        }
                        dictionaryCollection.Add(String.Empty, String.Empty);
                    }
                }
            }

            return dictionaryCollection;

        }

        public Dictionary<String, String> GetOPRProofers()
        {
            Dictionary<String, String> dictionaryCollection = new Dictionary<String, String>();
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {

                    SPList scanList = currentWeb.Lists["OPR Proofers"];
                    SPQuery query = new SPQuery();
                    query.DatesInUtc = false;
                    SPListItemCollection listColl = scanList.GetItems(query);
                    if (listColl != null)
                    {
                        DataRow[] dataRows = listColl.GetDataTable().Select();
                        foreach (DataRow dataRow in dataRows)
                        {
                            if (!dictionaryCollection.ContainsKey(Convert.ToString(dataRow["Name"])))
                            {
                                dictionaryCollection.Add(Convert.ToString(dataRow["Name"]), Convert.ToString(dataRow["ShortName"]));
                            }
                        }
                        dictionaryCollection.Add(String.Empty, String.Empty);
                    }
                }
            }

            return dictionaryCollection;

        }

        //protected Dictionary<String, String> GenerateHPIDs() //Get HPE Numbers from HPE List
        //{
        //    Dictionary<String, String> listCollection = new Dictionary<String, String>();
        //    using (SPSite site = new SPSite(siteUrl))
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            SPList scanList = currentWeb.Lists["HPE"];
        //            SPQuery query = new SPQuery();
        //            query.DatesInUtc = false;
        //            SPListItemCollection listColl = scanList.GetItems(query);
        //            if (listColl.Count > 0)
        //            {
        //                DataRow[] dataRows = listColl.GetDataTable().Select();
        //                //listCollection.Add(String.Empty, String.Empty);
        //                foreach (DataRow dataRow in dataRows)
        //                {
        //                    if (!listCollection.ContainsKey(Convert.ToString(dataRow["EDS_Number"])))
        //                    {
        //                        listCollection.Add(Convert.ToString(dataRow["EDS_Number"]), Convert.ToString(dataRow["ID"]));
        //                    }
        //                }
        //                listCollection.Add(String.Empty, String.Empty);
        //            }
        //        }
        //    }
        //    return listCollection;                                                                                                                                                                                  
        //}

        private void FirstGridViewRow() //Set First Grid Row
        {
            DataTable dt = new DataTable();
            DataRow dr = null;

            /*Start-Scan List Dev Site*/
            dt.Columns.Add(new DataColumn("OPR_Test", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("CCOPR", typeof(string)));//Originator
            dt.Columns.Add(new DataColumn("CC_OPR", typeof(string)));//Typist
            dt.Columns.Add(new DataColumn("Proofer", typeof(string)));
            dt.Columns.Add(new DataColumn("OPR_Date", typeof(string)));
            dt.Columns.Add(new DataColumn("AuthorOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("Approver", typeof(string)));
            dt.Columns.Add(new DataColumn("DirectTO", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRType", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRSubType", typeof(string)));
            dt.Columns.Add(new DataColumn("FinancialOPR", typeof(string)));
            dt.Columns.Add(new DataColumn("HP_OPR", typeof(string)));
            dt.Columns.Add(new DataColumn("HPE_ID", typeof(string)));
            dt.Columns.Add(new DataColumn("Attn", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRSubject", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRMessage", typeof(string)));
            dt.Columns.Add(new DataColumn("Action_OPR", typeof(string)));
            dt.Columns.Add(new DataColumn("Other_Action", typeof(string)));
            //dt.Columns.Add(new DataColumn("ReqCoordination", typeof(string)));
            dt.Columns.Add(new DataColumn("ReceivedBy", typeof(string)));
            dt.Columns.Add(new DataColumn("DateofActionOPR", typeof(string)));
            //dt.Columns.Add(new DataColumn("RouteTO", typeof(string)));
            dt.Columns.Add(new DataColumn("OPRStatus", typeof(string)));
            //dt.Columns.Add(new DataColumn("Proofer", typeof(string)));
            dt.Columns.Add(new DataColumn("PickUp", typeof(string)));

            dt.Columns.Add(new DataColumn("OPRCC", typeof(string)));//CC Multiple names Entry
            dt.Columns.Add(new DataColumn("FinancialSeeMemo", typeof(string)));
            dr = dt.NewRow();

            dr["OPR_Test"] = string.Empty;
            dr["ID"] = string.Empty;
            dr["CCOPR"] = string.Empty;//Originator
            dr["CC_OPR"] = string.Empty;//Typist
            dr["Proofer"] = string.Empty;
            dr["OPR_Date"] = string.Empty;
            dr["AuthorOPR"] = string.Empty;
            dr["Approver"] = string.Empty;
            dr["DirectTO"] = string.Empty;
            dr["OPRType"] = string.Empty;
            dr["OPRSubType"] = string.Empty;
            dr["FinancialOPR"] = string.Empty;
            dr["HP_OPR"] = string.Empty;
            dr["HPE_ID"] = string.Empty;
            dr["Attn"] = string.Empty;
            dr["OPRSubject"] = string.Empty;
            dr["OPRMessage"] = string.Empty;
            dr["Action_OPR"] = string.Empty;
            dr["Other_Action"] = string.Empty;
            //dr["ReqCoordination"] = string.Empty;
            dr["ReceivedBy"] = string.Empty;
            dr["DateofActionOPR"] = string.Empty;
            //dr["RouteTO"] = string.Empty;
            dr["OPRStatus"] = string.Empty;
            //dr["Proofer"] = string.Empty;
            dr["PickUp"] = string.Empty;
            dr["OPRCC"] = string.Empty;//CC Multiple names Entry
            dr["FinancialSeeMemo"] = string.Empty;
            dt.Rows.Add(dr);

            /*End-Scan List Dev Site*/

            ViewState["CurrentTable"] = dt;

            gvOPRDeatils.DataSource = dt;
            gvOPRDeatils.DataBind();


            //append log-in user


        }

        public static int LastWorkingDayOfMonth(DateTime date)  //Last working day of the Month
        {
            var lastDay = DateTime.DaysInMonth(date.Year, date.Month);
            var dayOfWeek = date.AddDays(lastDay - date.Day).DayOfWeek;
            return dayOfWeek == DayOfWeek.Saturday ? lastDay - 1 : dayOfWeek == DayOfWeek.Sunday ? lastDay - 2 : lastDay;
        }

        public static DateTime checkWeekEnd(DateTime date)  //Check Sat & Sun, add next weekday.
        {
            var dayOfWeek = date.DayOfWeek;
            var nextWeekDay = date;
            if (dayOfWeek == DayOfWeek.Saturday)
            {
                nextWeekDay = date.AddDays(2);
            }
            else if (dayOfWeek == DayOfWeek.Sunday)
            {
                nextWeekDay = date.AddDays(1);
            }
            return nextWeekDay;
        }

        public string GetOPRID() //Generate OPR ID
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    String fromDate = string.Empty;
                    String OPR_Test = String.Empty;
                    String OPRID = String.Empty;
                    String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2016
                    Int32 Month = 0;
                    String MonthFormat = String.Empty;
                    String Day = String.Empty;
                    SPList scanList = currentWeb.Lists["Scan List"];
                    SPQuery query = new SPQuery();
                    GridViewRow row = gvOPRDeatils.FooterRow;
                    TextBox txtDateofLetter = (TextBox)row.FindControl("txtFooterDateofLetter");
                    //List<SPListItem> listItems = (from SPListItem item in scanList.Items
                    //                              select item).ToList();
                    Int32 lastBusinessDay = LastWorkingDayOfMonth(DateTime.Now);

                    if ((lastBusinessDay == DateTime.Now.Day) && ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 30) || (DateTime.Now.Hour >= 15)))
                    {
                        Month = DateTime.Now.AddMonths(1).Month;
                        MonthFormat = Month <= 9 ? String.Format("0{0}", Month) : Convert.ToString(Month);
                    }
                    else
                    {
                        Month = DateTime.Now.Month;
                        MonthFormat = Month <= 9 ? String.Format("0{0}", Month) : Convert.ToString(Month);
                    }

                    if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 30) || (DateTime.Now.Hour >= 15))
                    {
                        if (Convert.ToString(DateTime.Now.DayOfWeek) == "Friday")   //Check for next business day
                        {
                            Day = DateTime.Now.Date.AddDays(3).Day.ToString();
                            fromDate = DateTime.Now.Date.ToShortDateString();
                        }
                        else
                        {
                            Day = DateTime.Now.Date.AddDays(1).Day.ToString();
                            fromDate = DateTime.Now.Date.ToShortDateString();
                        }
                    }
                    else if (Convert.ToString(DateTime.Now.DayOfWeek) == "Monday")
                    {
                        Day = DateTime.Now.Day.ToString();
                        fromDate = DateTime.Now.Date.AddDays(-3).ToShortDateString();
                    }
                    else
                    {
                        fromDate = DateTime.Now.AddDays(-1).Date.ToShortDateString();
                        Day = DateTime.Now.Day.ToString();
                    }
                    if (Convert.ToInt32(Day) <= 9)
                    {
                        Day = "0" + Day;
                    }
                    txtDateofLetter.Text = Convert.ToDateTime(MonthFormat + "/" + Day + "/" + Year).ToShortDateString();

                    SPList OPRList = currentWeb.Lists["Scan List"];
                    String strQuery = String.Empty;
                    strQuery = "<Where>" +
                                         "<Geq>" +
                                              "<FieldRef Name='Created'/>" +
                                              "<Value Type='DateTime' IncludeTimeValue='True'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:30:00")) + "</Value>" +
                                         "</Geq>" +
                                     "</Where>";
                    query.Query = strQuery +
                                        "<OrderBy>" +
                                           "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                        "</OrderBy>";
                    query.ViewFields = string.Concat(
                                "<FieldRef Name='ID' />",
                                 "<FieldRef Name='OPR_Test' />");
                    query.DatesInUtc = false;
                    query.ViewFieldsOnly = true;
                    SPListItemCollection listColl = OPRList.GetItems(query);
                    //var SacnListColl = listItems.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:30:00")).ToList();
                    if (listColl.Count > 0)
                    {
                        OPRID = Convert.ToString(listColl[0]["OPR_Test"]); //SacnListColl.OrderByDescending(i => i["ID"]).Select(i => i["OPR_Test"].ToString()).First();
                        OPRID = OPRID.Split('-')[3].ToString(); //OPR-16-0401-01
                        int startID = Convert.ToInt32(OPRID) + 1;
                        if (Convert.ToInt32(OPRID) < 9)
                            OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-00" + startID;
                        else
                            OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-0" + Convert.ToInt32(startID);
                    }
                    else
                    {

                        OPR_Test = "OPR-" + Year + "-" + MonthFormat + Day + "-001";
                    }
                    return OPR_Test;
                }
            }
        }

        protected void gvOPRDeatils_RowDeleting(object sender, GridViewDeleteEventArgs e) //Delete Function*
        {
            SetRowData();
            if (ViewState["CurrentTable"] != null)
            {
                DataTable dt = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;
                int rowIndex = Convert.ToInt32(e.RowIndex);
                if (dt.Rows.Count > 1)
                {
                    dt.Rows.Remove(dt.Rows[rowIndex]);
                    drCurrentRow = dt.NewRow();
                    ViewState["CurrentTable"] = dt;
                    gvOPRDeatils.DataSource = dt;
                    gvOPRDeatils.DataBind();

                    for (int i = 0; i < gvOPRDeatils.Rows.Count - 1; i++)
                    {
                        gvOPRDeatils.Rows[i].Cells[0].Text = Convert.ToString(i + 1);
                    }
                    //SetPreviousData();
                }
            }
        }

        private void SetRowData() //Set Row Data*
        {
            int rowIndex = 0;

            if (ViewState["CurrentTable"] != null)
            {
                DataTable dtCurrentTable = (DataTable)ViewState["CurrentTable"];
                DataRow drCurrentRow = null;


                if (dtCurrentTable.Rows.Count > 0)
                {
                    for (int i = 0; i <= dtCurrentTable.Rows.Count; i++)
                    {
                        TextBox TextBoxName = (TextBox)gvOPRDeatils.Rows[rowIndex].FindControl("txtName");
                        TextBox TextBoxAge = (TextBox)gvOPRDeatils.Rows[rowIndex].FindControl("txtAge");
                        TextBox TextBoxAddress = (TextBox)gvOPRDeatils.Rows[rowIndex].FindControl("txtAddress");
                        RadioButtonList RBLGender =
                          (RadioButtonList)gvOPRDeatils.Rows[rowIndex].FindControl("RBLGender");
                        DropDownList DrpQualification =
                          (DropDownList)gvOPRDeatils.Rows[rowIndex].FindControl("drpQualification");
                        drCurrentRow = dtCurrentTable.NewRow();
                        drCurrentRow["RowNumber"] = i + 1;
                        dtCurrentTable.Rows[i - 1]["Col1"] = TextBoxName.Text;
                        dtCurrentTable.Rows[i - 1]["Col2"] = TextBoxAge.Text;
                        dtCurrentTable.Rows[i - 1]["Col3"] = TextBoxAddress.Text;
                        dtCurrentTable.Rows[i - 1]["Col4"] = RBLGender.SelectedValue;
                        dtCurrentTable.Rows[i - 1]["Col5"] = DrpQualification.SelectedValue;
                        rowIndex++;
                    }

                    ViewState["CurrentTable"] = dtCurrentTable;
                }
            }
            else
            {
                System.Web.HttpContext.Current.Response.Write("ViewState is null");
            }
            //SetPreviousData();
        }

        protected void gvOPRDeatils_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                System.Data.DataRowView rowView = e.Row.DataItem as System.Data.DataRowView;
                String itemStatus = Convert.ToString(rowView["OPRStatus"]);

                //if (Convert.ToString(rowView["FinancialOPR"]) != null && Convert.ToString(rowView["FinancialOPR"]).Length > 0)
                //{
                //    e.Row.Cells[0].Controls[0].Visible = false;
                //}
                if (itemStatus == "Completed" || itemStatus == "Cancelled")
                {
                    e.Row.Cells[0].Controls[0].Visible = false;
                }

                if (gvOPRDeatils.EditIndex == e.Row.RowIndex)
                {
                    using (ClientContext context = new ClientContext(siteUrl))
                    {
                        context.Credentials = new NetworkCredential(userID, pwd, domain);
                        Web web = context.Web;
                        PeopleEditor PeopleEditorOriginator = (PeopleEditor)e.Row.FindControl("PeopleEditorOriginator"); //People Search for Originator
                        String originator = Convert.ToString(rowView["CCOPR"]);
                        //PeopleEditorOriginator.CommaSeparatedAccounts = originator;//.Split(',')[0] + "," + originator.Split(',')[1];

                        PickerEntity userEntity = new PickerEntity();
                        ArrayList userList = new ArrayList();
                        userEntity.Key = originator;
                        userList.Add(userEntity);
                        PeopleEditorOriginator.UpdateEntities(userList);
                        PeopleEditorOriginator.DataBind();
                    }

                    DropDownList ddlProofer = (DropDownList)e.Row.FindControl("ddlProofer");
                    ddlProofer.DataSource = GetOPRProofers();
                    ddlProofer.DataTextField = "Key";
                    ddlProofer.DataValueField = "Value";
                    ddlProofer.DataBind();
                    ddlProofer.SelectedValue = Convert.ToString(rowView["Proofer"]);

                    DropDownList ddlApprover = (DropDownList)e.Row.FindControl("ddlApprover");
                    ddlApprover.DataSource = GetOPRApprovers();
                    ddlApprover.DataTextField = "Key";
                    ddlApprover.DataValueField = "Value";
                    ddlApprover.DataBind();
                    ddlApprover.SelectedValue = Convert.ToString(rowView["Approver"]);

                    DropDownList ddlCC = (DropDownList)e.Row.FindControl("ddlCC");
                    ddlCC.DataSource = GetTypistNames();
                    ddlCC.DataTextField = "Key";
                    ddlCC.DataValueField = "Value";
                    ddlCC.DataBind();
                    ddlCC.SelectedValue = ddlCC.Items.FindByText(Convert.ToString(rowView["CC_OPR"])).Value;

                    DropDownList ddlEditFinancialSeeMemo = (DropDownList)e.Row.FindControl("ddlEditFinancialSeeMemo");

                    DropDownList ddlOPREditType = (DropDownList)e.Row.FindControl("ddlOPREditType");
                    if (ddlOPREditType.Items.Count > 0)
                    {
                        String OPRtype = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[9] as String;
                        ddlOPREditType.SelectedValue = OPRtype;

                        DropDownList ddlOPREditSubType = (DropDownList)e.Row.FindControl("ddlOPREditSubType");
                        String OPREditSubType = Convert.ToString(rowView["OPRSubType"]);
                        //String OPREditSubType = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[10] as String;
                        if (OPRtype == "Financials")
                        {
                            ddlEditFinancialSeeMemo.Visible = true;
                            ddlOPREditSubType.DataSource = AddOPRSubTypeFinancial();
                            ddlOPREditSubType.DataBind();
                            if (!String.IsNullOrEmpty(OPREditSubType))
                            {
                                ddlOPREditSubType.SelectedValue = OPREditSubType;
                            }
                            String FinancialSeeMemo = Convert.ToString(rowView["FinancialSeeMemo"]);
                            //String FinancialSeeMemo = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[24] as String;
                            if (!String.IsNullOrEmpty(FinancialSeeMemo))
                            {
                                ddlEditFinancialSeeMemo.SelectedValue = FinancialSeeMemo;
                            }
                        }
                        else if (OPRtype == "File Maintenance")
                        {
                            ddlOPREditSubType.DataSource = AddOPRSubTypes();
                            ddlOPREditSubType.DataBind();
                            if (!String.IsNullOrEmpty(OPREditSubType))
                            {
                                ddlOPREditSubType.SelectedValue = OPREditSubType;
                            }

                        }
                        else
                        {
                            ddlOPREditSubType.Visible = false;
                        }
                    }

                    DropDownList ddlActionOPR = (DropDownList)e.Row.FindControl("ddlActionOPR");
                    ddlActionOPR.SelectedValue = Convert.ToString(rowView["Action_OPR"]);

                    DropDownList ddlOPRStatus = (DropDownList)e.Row.FindControl("ddlOPRStatus");
                    ddlOPRStatus.SelectedValue = Convert.ToString(rowView["OPRStatus"]);

                    DropDownList ddlPickUp = (DropDownList)e.Row.FindControl("ddlPickUp");
                    ddlPickUp.SelectedValue = Convert.ToString(rowView["PickUp"]);

                    //Empty DateofAction OPR field when FinancialOPR has value
                    TextBox txtDateofAction = (TextBox)e.Row.FindControl("txtDateofAction");
                    String financialOPR = Convert.ToString(rowView["FinancialOPR"]);
                    if (financialOPR != null && financialOPR.Length > 0)
                    {
                        txtDateofAction.Text = "";
                    }
                }

            }
            else if (e.Row.RowType == DataControlRowType.Footer)
            {
                DropDownList ddlOPRSubType = (DropDownList)e.Row.FindControl("ddlOPRSubType");
                ddlOPRSubType.Visible = false;
            }
        }

        protected void ButtonSave_Click(object sender, EventArgs e) //Save Records to List
        {
            GridViewRow row = gvOPRDeatils.FooterRow;

            Label lblDoc = (Label)row.FindControl("lblDoc");
            Label lblAuthorFooter = (Label)row.FindControl("lblAuthorFooter");
            DropDownList ddlApprover = (DropDownList)row.FindControl("ddlApproverFooter");
            TextBox txtDateofLetter = (TextBox)row.FindControl("txtFooterDateofLetter");
            DropDownList ddlCC = (DropDownList)row.FindControl("ddlCC");//Typist
            DropDownList ddlProofer = (DropDownList)row.FindControl("ddlProofer");
            DropDownList ddlOPRType = (DropDownList)row.FindControl("ddlOPRType");
            TextBox txtFinancial = (TextBox)row.FindControl("txtFinancial");
            TextBox txtDateofAction = (TextBox)row.FindControl("txtDateofAction");
            TextBox txtEDSNumber = (TextBox)row.FindControl("txtEDSNumber");
            TextBox txtDirectTO = (TextBox)row.FindControl("txtDir"); //DirectTO
            TextBox txtAttn = (TextBox)row.FindControl("txtAttn");
            TextBox txtRequestCoordination = (TextBox)row.FindControl("txtRequestCoordination");
            TextBox txtReceivedBy = (TextBox)row.FindControl("txtReceivedBy");
            TextBox txtOPRSubject = (TextBox)row.FindControl("txtOPRSubject");
            TextBox txtOPRMessage = (TextBox)row.FindControl("txtOPRMessage");
            DropDownList ddlActionOPR = (DropDownList)row.FindControl("ddlActionOPR");
            TextBox txtOther = (TextBox)row.FindControl("txtOther");
            DropDownList ddlOPRSubType = (DropDownList)row.FindControl("ddlOPRSubType");
            DropDownList ddlOPRStatus = (DropDownList)row.FindControl("ddlOPRStatus");
            DropDownList ddlPickUp = (DropDownList)row.FindControl("ddlPickUp");
            TextBox txtOPRCC = (TextBox)row.FindControl("txtOPRCC"); // OPRCC-Multi Names
            DropDownList ddlFinancialSeeMemo = (DropDownList)row.FindControl("ddlFinancialSeeMemo");
            PeopleEditor PeopleEditorOriginator = (PeopleEditor)row.FindControl("PeopleEditorOriginator");

            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            if (ddlOPRType.SelectedItem.Value == "Financials" && txtFinancial.Text == "" && ddlFinancialSeeMemo.SelectedItem.Value == "")
            {
                errorMessage = "Financial date is mandatory";
            }
            else if (ddlOPRType.SelectedItem.Value == "File Maintainence" && ddlOPRSubType.SelectedItem.Value == "Select")
            {
                errorMessage = "OPR Type is mandatory";
            }
            else if (ddlCC.SelectedItem.Value == "")
            {
                errorMessage = "Typist is mandatory";
            }
            else if (ddlOPRType.SelectedItem.Value == "")
            {
                errorMessage = "Subject_1 is mandatory";
            }
            else if (ddlActionOPR.SelectedItem.Value == "Other" && txtOther.Text == "")
            {
                errorMessage = "Other type is mandatory";
            }
            else if (txtOPRSubject.Text == "")
            {
                errorMessage = "Subject_2 is mandatory";
            }
            else if (ddlProofer.SelectedItem.Value == "")
            {
                errorMessage = "Proofer is mandatory";
            }
            else if (ddlPickUp.SelectedItem.Value == "")
            {
                errorMessage = "PickUp is mandatory";
            }
            else if (PeopleEditorOriginator.ResolvedEntities.Count == 0)
            {
                errorMessage = "Originator is mandatory";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {
                using (ClientContext context = new ClientContext(siteUrl))
                {

                    context.Credentials = new NetworkCredential(userID, pwd, domain);
                    Web web = context.Web;
                    Label1.Text = String.Empty;
                    List oList = context.Web.Lists.GetByTitle("Scan List");

                    /*Start-Scan List Dev*/
                    ListItemCreationInformation listCreationInformation = new ListItemCreationInformation();
                    CL.ListItem oListItem = oList.AddItem(listCreationInformation);

                    String OPRID = GetOPRID();
                    PickerEntity userEntity = (PickerEntity)PeopleEditorOriginator.ResolvedEntities[0];
                    //User user = web.EnsureUser(userEntity.Key);

                    oListItem["OPR_Test"] = OPRID;
                    oListItem["CCOPR"] = userEntity.DisplayText;//txtCC1.Text;   //Originator
                    oListItem["CC_OPR"] = ddlCC.SelectedItem.Text;  //Typist
                    oListItem["Proofer"] = ddlCC.SelectedItem.Text;//ddlProofer.SelectedValue;// Proofer is typist per requirement.
                    oListItem["OPR_Date"] = Convert.ToDateTime(txtDateofLetter.Text);
                    oListItem["AuthorOPR"] = lblAuthorFooter.Text;
                    oListItem["Approver"] = ddlApprover.SelectedValue;
                    oListItem["DirectTO"] = txtDirectTO.Text;
                    oListItem["OPRType"] = ddlOPRType.SelectedValue;
                    oListItem["FinancialOPR"] = txtFinancial.Text;
                    oListItem["HP_OPR"] = String.IsNullOrEmpty(txtEDSNumber.Text) ? String.Empty : txtEDSNumber.Text;
                    oListItem["HPE_ID"] = GetHPEID(txtEDSNumber.Text);
                    oListItem["Attn"] = txtAttn.Text;
                    oListItem["OPRSubject"] = txtOPRSubject.Text;
                    oListItem["OPRMessage"] = txtOPRMessage.Text;
                    oListItem["Action_OPR"] = ddlActionOPR.SelectedValue;
                    oListItem["Other_Action"] = txtOther.Text;
                    oListItem["ReceivedBy"] = txtReceivedBy.Text;
                    if (ddlFinancialSeeMemo.SelectedValue == "See Memo")
                    {
                        oListItem["DateofActionOPR"] = null;
                    }
                    else if (String.IsNullOrEmpty(txtDateofAction.Text))
                    {
                        if (!String.IsNullOrEmpty(txtFinancial.Text))
                        {
                            oListItem["DateofActionOPR"] = Convert.ToDateTime(txtFinancial.Text);
                        }
                        else
                        {
                            oListItem["DateofActionOPR"] = null;
                        }
                    }
                    else if (txtDateofAction.Text == "See Memo")
                    {
                        oListItem["DateofActionOPR"] = null;
                        oListItem["SeeMemo"] = true;
                    }
                    else
                    {
                        oListItem["DateofActionOPR"] = Convert.ToDateTime(txtDateofAction.Text);
                    }
                    oListItem["OPRStatus"] = "Pending"; //ddlOPRStatus.SelectedValue;
                    oListItem["OPRSubType"] = ddlOPRSubType.SelectedValue == "Select" ? String.Empty : ddlOPRSubType.SelectedValue; //Hide Select from OPR Types in Subject_1
                    oListItem["PickUp"] = ddlPickUp.SelectedValue;
                    oListItem["OPRCC"] = txtOPRCC.Text; //CC Multiple Names entry
                    oListItem["FinancialSeeMemo"] = (ddlFinancialSeeMemo.SelectedValue == "See Memo") ? ddlFinancialSeeMemo.SelectedValue : String.Empty;


                    /*End-Scan List Dev*/

                    oListItem.Update();
                    context.ExecuteQuery();
                    //Label1.Text = "";
                    Label2.Text = "OPR submitted successfully.";
                    //Page.Response.Redirect(siteUrl + "SitePages/testgrid.aspx");
                    Page.Response.Redirect(siteUrl + "SitePages/OPR Grid.aspx");    //Dev Site

                    //Label2.Text = "OPR submitted successfully.";
                    //GetScanListData(DateTime.Now, null, null);
                    //GetHPNumbers();
                }
            }
            else
            {
                Label1.Text = errorMessage;
            }
        }

        protected void ddlOPRType_SelectedIndexChanged(object sender, EventArgs e) //Pre-populate the data based on OPR Type
        {
            DropDownList ddlOPR = (DropDownList)sender;
            TextBox txt = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtDir");
            TextBox txt3 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtAttn");
            DropDownList ddlOPRSubType = (DropDownList)gvOPRDeatils.FooterRow.FindControl("ddlOPRSubType");
            DropDownList ddlFinancialSeeMemo = (DropDownList)gvOPRDeatils.FooterRow.FindControl("ddlFinancialSeeMemo");
            txt4.ReadOnly = true;
            //OPRTypeAssignee = HttpContext.Current.Session["Assignees"] as Dictionary<String, String>;
            String concatTypeSubType = string.Empty;
            OPRTypeAssignee = GetOPRTypeAssignees();
            if (ddlOPR.SelectedItem.Value.Equals("Financials"))
            {
                txt.Enabled = true; //txtFinancials
                txt.BackColor = System.Drawing.Color.Red;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                txt4.Text = "";
                txt4.Enabled = false;

                ddlFinancialSeeMemo.Visible = true;

                ddlOPRSubType.Visible = true;
                ddlOPRSubType.DataSource = AddOPRSubTypeFinancial();
                ddlOPRSubType.DataBind();
            }

            else if (ddlOPR.SelectedItem.Value.Equals("Claims Processing"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                ddlFinancialSeeMemo.Visible = false;
                txt4.Enabled = true;
                DateTime claimsDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = claimsDate.ToShortDateString();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Data Switch Agreement"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt4.ReadOnly = true;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                //txt4.Enabled = false;
                txt4.Text = "See Memo";
                txt4.ForeColor = System.Drawing.Color.Black;
                ddlFinancialSeeMemo.Visible = false;

            }
            else if (ddlOPR.SelectedItem.Value.Equals("File Maintenance"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();
                ddlFinancialSeeMemo.Visible = false;

                ddlOPRSubType.Visible = true;
                ddlOPRSubType.DataSource = AddOPRSubTypes();
                ddlOPRSubType.DataBind();

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Provider Rep Visits"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                ddlOPRSubType.Visible = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                txt4.Enabled = true;
                DateTime repVisitsDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = repVisitsDate.ToShortDateString();
                ddlFinancialSeeMemo.Visible = false;

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Adjustments"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                txt4.Enabled = true;
                DateTime adjustDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = adjustDate.ToShortDateString();
                ddlFinancialSeeMemo.Visible = false;
                //gvOPRDeatils.ShowFooter = false; //Show Footer
                //ButtonSave.Visible = false; //hide save Button

            }
            else if (ddlOPR.SelectedItem.Value.Equals("Memo"))
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt4.ReadOnly = true;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPR.SelectedItem.Value + ":"; //Main Type
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                //txt4.Enabled = false;
                txt4.Text = "See Memo";
                txt4.ForeColor = System.Drawing.Color.Black;
                ddlFinancialSeeMemo.Visible = false;

            }
            else
            {
                txt.Text = String.Empty;
                ddlOPRSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                txt2.Text = "";
                txt3.Text = "";
                txt4.Text = "";
                txt4.Enabled = false;
                ddlFinancialSeeMemo.Visible = false;
            }
            //gvOPRDeatils.ShowFooter = true;    //Show Footer on Subject_1
        }

        protected void ddlActionOPR_SelectedIndexChanged(object sender, EventArgs e)
        {

            //DropDownList ddlActionOPR = (DropDownList)sender;
            DropDownList ddlActionOPR = (DropDownList)sender;
            DropDownList ddlOPRType = (DropDownList)sender;
            GridViewRow avr = (GridViewRow)ddlActionOPR.Parent.Parent;
            //TextBox txt4 = (TextBox)avr.Cells[8].FindControl("txtDateofAction");
            TextBox txt4 = (TextBox)avr.FindControl("txtDateofAction");
            int rowindex = avr.RowIndex;
            if (ddlActionOPR.SelectedItem.Value.Equals("Other"))
            {
                //TextBox txt1 = (TextBox)avr.Cells[5].FindControl("txtOther");
                TextBox txt1 = (TextBox)avr.FindControl("txtOther");
                txt1.Enabled = true;
                txt1.BackColor = System.Drawing.Color.Red;
            }
            else if (ddlOPRType.SelectedItem.Value.Equals("Memo"))
            {
                txt4.Text = "See Memo";

            }
            else
            {
                //TextBox txt1 = (TextBox)avr.Cells[5].FindControl("txtOther");
                TextBox txt1 = (TextBox)avr.FindControl("txtOther");
                txt1.Enabled = false;
                txt1.Text = string.Empty;
                txt1.BackColor = System.Drawing.Color.Silver;
            }
        }

        protected void gvOPRDeatils_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gvOPRDeatils.ShowFooter = false;
            ButtonSave.Visible = false;
            gvOPRDeatils.EditIndex = e.NewEditIndex;
            DataTable scanTableEdit = ViewState["ScanList"] as DataTable;
            gvOPRDeatils.DataSource = scanTableEdit;
            gvOPRDeatils.DataBind();

            HyperLink OPRNumber = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("hlnkDocNumber") as HyperLink;
            String approvalStatus = GetOPRStatus(OPRNumber.Text);
            DropDownList ddlResubmit = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlResubmit") as DropDownList;
            DropDownList ddlOPRStatus = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlOPRStatus") as DropDownList;
            DropDownList ddlApprover = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlApprover") as DropDownList;
            DropDownList ddlProofer = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlProofer") as DropDownList;
            DropDownList ddlCC = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlCC") as DropDownList;           //Typist
            //TextBox txtCC1 = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtCC1") as TextBox;
            DropDownList ddlOPREditType = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlOPREditType") as DropDownList;
            DropDownList ddlOPREditSubType = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlOPREditSubType") as DropDownList;
            TextBox txtFinancial = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtFinancial") as TextBox;
            TextBox txtDateofLetter = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtDateofLetter") as TextBox;
            DropDownList ddlEditFinancialSeeMemo = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlEditFinancialSeeMemo") as DropDownList;
            TextBox txtDateofAction = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtDateofAction") as TextBox;
            TextBox txtDir = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtDir") as TextBox;
            TextBox txtAttn = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtAttn") as TextBox;
            TextBox txtEDSNumber = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtEDSNumber") as TextBox;

            //DropDownList ddlHPNumber = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlHPNumber") as DropDownList;

            TextBox txtReceivedBy = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtReceivedBy") as TextBox;
            TextBox txtOPRSubject = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtOPRSubject") as TextBox;
            TextBox txtOther = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtOther") as TextBox;
            TextBox txtOPRMessage = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtOPRMessage") as TextBox;
            DropDownList ddlActionOPR = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlActionOPR") as DropDownList;
            TextBox txtOPRCC = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("txtOPRCC") as TextBox;
            DropDownList ddlPickUp = gvOPRDeatils.Rows[e.NewEditIndex].FindControl("ddlPickUp") as DropDownList;

            if (approvalStatus == "rejected") //Hide between Approvalstatus - ReSubmit DropDown
            {
                gvOPRDeatils.Columns[1].Visible = true;
                ddlResubmit.SelectedValue = "Resubmit";
            }
            else if (approvalStatus == "approved")
            {
                gvOPRDeatils.Rows[e.NewEditIndex].Cells[0].Enabled = true;
                ddlOPRStatus.Enabled = true;
                ddlApprover.Enabled = false;
                ddlProofer.Enabled = false;
                //txtCC1.Enabled = false;
                ddlCC.Enabled = false;
                ddlOPREditType.Enabled = false;
                ddlOPREditSubType.Enabled = false;
                txtFinancial.Enabled = false;
                txtDateofLetter.Enabled = false;
                ddlEditFinancialSeeMemo.Enabled = false;
                txtDateofAction.Enabled = true;
                txtDir.Enabled = false;
                txtAttn.Enabled = false;
                txtEDSNumber.Enabled = false;
                txtReceivedBy.Enabled = false;
                txtOPRSubject.Enabled = false;
                txtOther.Enabled = false;
                txtOPRMessage.Enabled = false;
                ddlActionOPR.Enabled = false;
                txtOPRCC.Enabled = false;
                ddlPickUp.Enabled = false;
            }
            else
            {
                gvOPRDeatils.Columns[1].Visible = false;
                ddlResubmit.SelectedValue = "Update";
            }

            //GetHPNumbers();
        }

        protected String GetOPRStatus(String OPRNumber) //Get 'OPRNumber' from 'Scan List' match it with 'OPR_Number' from'Scan OPR' library to check 'ApprovalStatus' from 'Scan OPR'
        {
            String approvalStatus = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    String OPRNumberPDFLink = OPRNumber + ".pdf"; //siteUrl + "/Scan OPR/" + OPRNumber + ".pdf";
                    SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                         "<Eq>" +
                                            "<FieldRef Name='LinkFilename'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                            "<Value Type='Text'>" + OPRNumberPDFLink + "</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = scanOPRLibrary.GetItems(camlQuery);
                    if (itemColl.Count > 0 && (Convert.ToString(itemColl[0]["ApprovalStatus"]) == "Proofer Rejected" || Convert.ToString(itemColl[0]["ApprovalStatus"]) == "Approver Rejected"))
                    {
                        approvalStatus = "rejected";
                    }
                    else if (itemColl.Count > 0 && (Convert.ToString(itemColl[0]["ApprovalStatus"]) == "Proofer Approved" || Convert.ToString(itemColl[0]["ApprovalStatus"]) == "Approver Approved"))
                    {
                        approvalStatus = "approved";
                    }
                }
            }
            return approvalStatus;
        }

        protected void gvOPRDeatils_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gvOPRDeatils.ShowFooter = true;
            ButtonSave.Visible = true;
            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            gvOPRDeatils.EditIndex = -1;
            if (txtSubmittedDate.Text.Length > 0)
            {
                // ViewState["searchDate"] = txtSubmittedDate.Text;
                DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                GetScanListData(submittedDate, null, null);
            }
            else
            {
                GetScanListData(DateTime.Now, null, null);
            }
            //GetHPNumbers();
        }

        protected void gvOPRDeatils_RowUpdating(object sender, GridViewUpdateEventArgs e) //Update records upon edit
        {
            gvOPRDeatils.ShowFooter = true;
            ButtonSave.Visible = true;
            Int32 scanListID = 0;
            Label lblID = (Label)gvOPRDeatils.Rows[e.RowIndex].FindControl("lblID");
            Label lblAuthor = (Label)gvOPRDeatils.Rows[e.RowIndex].FindControl("lblAuthor");
            TextBox txtDateofLetter = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtDateofLetter");
            //TextBox txtCC1 = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtCC1");//Originator
            DropDownList ddlCC = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlCC");//Typist
            DropDownList ddlProofer = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlProofer");
            DropDownList ddlApprover = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlApprover");//Approver
            DropDownList ddlOPREditType = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlOPREditType");
            DropDownList ddlOPREditSubType = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlOPREditSubType");
            TextBox txtFinancial = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtFinancial");
            TextBox txtDateofAction = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtDateofAction");
            TextBox txtDir = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtDir");
            TextBox txtAttn = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtAttn");

            TextBox txtEDSNumber = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtEDSNumber");
            //DropDownList ddlHPNumber = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlHPNumber");
            TextBox txtRequestCoordination = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtRequestCoordination");
            TextBox txtReceivedBy = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtReceivedBy");
            TextBox txtOPRSubject = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtOPRSubject");
            DropDownList ddlActionOPR = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlActionOPR");
            TextBox txtOther = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtOther");
            DropDownList ddlOPRStatus = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlOPRStatus");
            //DropDownList ddlProofer = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlProofer");
            TextBox txtOPRMessage = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtOPRMessage");
            DropDownList ddlPickUp = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlPickUp");
            TextBox txtOPRCC = (TextBox)gvOPRDeatils.Rows[e.RowIndex].FindControl("txtOPRCC");
            DropDownList ddlEditFinancialSeeMemo = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlEditFinancialSeeMemo");
            DropDownList ddlResubmit = (DropDownList)gvOPRDeatils.Rows[e.RowIndex].FindControl("ddlResubmit");
            PeopleEditor PeopleEditorOriginator = (PeopleEditor)gvOPRDeatils.Rows[e.RowIndex].FindControl("PeopleEditorOriginator");//People_Picker_Originator
            HyperLink hlnkDocNumber = (HyperLink)gvOPRDeatils.Rows[e.RowIndex].FindControl("hlnkDocNumber");

            ClientContext clientContext = new ClientContext(siteUrl);
            Label1.Text = "";
            Label2.Text = "";
            String errorMessage = String.Empty;

            if (ddlOPREditType.SelectedItem.Value == "Financials" && txtFinancial.Text == "" && ddlEditFinancialSeeMemo.SelectedItem.Value == "")
            {
                errorMessage = "Financial date is mandatory";

            }
            else if (ddlOPREditType.SelectedItem.Value == "")
            {
                errorMessage = "Subject_1 is mandatory";
            }
            else if (ddlActionOPR.SelectedItem.Value == "Other" && txtOther.Text == "")
            {

                errorMessage = "Other type is mandatory";
            }
            else if (ddlCC.SelectedItem.Value == "")
            {
                errorMessage = "Typist is mandatory";
            }
            else if (PeopleEditorOriginator.ResolvedEntities.Count == 0)
            {
                errorMessage = "Originator is mandatory";
            }
            else if (txtOPRSubject.Text == "")
            {
                errorMessage = "Subject_2 is mandatory";
            }

            /*Start-Scan List Dev*/
            List oList = clientContext.Web.Lists.GetByTitle("Scan List");
            clientContext.Credentials = new NetworkCredential(userID, pwd, domain);

            if (String.IsNullOrEmpty(errorMessage))
            {
                Web web = clientContext.Web;
                PickerEntity userEntity = (PickerEntity)PeopleEditorOriginator.ResolvedEntities[0];

                ButtonSave.Visible = true;
                scanListID = Convert.ToInt32(lblID.Text);
                CL.ListItem oListItem = oList.GetItemById(scanListID);
                oListItem["CCOPR"] = userEntity.DisplayText;//txtCC1.Text;//Originator
                oListItem["CC_OPR"] = ddlCC.SelectedItem.Text;//Typist
                oListItem["Proofer"] = ddlCC.SelectedItem.Text;//ddlProofer.SelectedValue; //Proofer
                oListItem["OPR_Date"] = Convert.ToDateTime(txtDateofLetter.Text);
                oListItem["DirectTO"] = txtDir.Text; //DirectTO
                oListItem["OPRType"] = ddlOPREditType.SelectedValue;
                oListItem["OPRSubType"] = ddlOPREditSubType.SelectedValue == "Select" ? String.Empty : ddlOPREditSubType.SelectedValue;
                oListItem["FinancialOPR"] = (ddlEditFinancialSeeMemo.SelectedValue == "See Memo") ? String.Empty : txtFinancial.Text;
                oListItem["HP_OPR"] = String.IsNullOrEmpty(txtEDSNumber.Text) ? String.Empty : txtEDSNumber.Text;
                oListItem["HPE_ID"] = GetHPEID(txtEDSNumber.Text); //txtEDSNumber.Text;
                oListItem["Attn"] = txtAttn.Text;
                oListItem["OPRSubject"] = txtOPRSubject.Text;
                oListItem["Action_OPR"] = ddlActionOPR.SelectedValue;
                oListItem["Other_Action"] = txtOther.Text;
                //oListItem["ReqCoordination"] = txtRequestCoordination.Text;
                oListItem["ReceivedBy"] = txtReceivedBy.Text;
                //oListItem["DateofActionOPR"] = (ddlEditFinancialSeeMemo.SelectedValue == "See Memo") ? String.Empty : txtDateofAction.Text; 
                if (ddlEditFinancialSeeMemo.SelectedValue == "See Memo")
                {
                    oListItem["DateofActionOPR"] = null;
                }
                else if (String.IsNullOrEmpty(txtDateofAction.Text))
                {
                    if (!String.IsNullOrEmpty(txtFinancial.Text))
                    {
                        oListItem["DateofActionOPR"] = Convert.ToDateTime(txtFinancial.Text);
                    }
                    else
                    {
                        oListItem["DateofActionOPR"] = null;
                    }
                }
                else if (txtDateofAction.Text == "See Memo")
                {
                    oListItem["DateofActionOPR"] = null;
                    oListItem["SeeMemo"] = true;
                }
                else
                {
                    oListItem["DateofActionOPR"] = Convert.ToDateTime(txtDateofAction.Text);
                }
                //oListItem["RouteTO"] = txtRouteTo.Text;
                oListItem["OPRStatus"] = ddlOPRStatus.SelectedValue;
                oListItem["OPRMessage"] = txtOPRMessage.Text;
                //oListItem["Proofer"] = ddlCC.SelectedItem.Text; //ddlProofer.SelectedValue; Proofer is Typist per requirement.
                oListItem["PickUp"] = ddlPickUp.SelectedValue;
                oListItem["Approver"] = ddlApprover.SelectedValue;
                //oListItem["FinancialSeeMemo"] = ddlEditFinancialSeeMemo.SelectedValue;
                oListItem["OPRCC"] = txtOPRCC.Text;
                oListItem["FinancialSeeMemo"] = (ddlEditFinancialSeeMemo.SelectedValue == "See Memo") ? ddlEditFinancialSeeMemo.SelectedValue : String.Empty;
                oListItem["Resubmit"] = ddlResubmit.SelectedValue;
                //To Capture completed
                if (ddlOPRStatus.SelectedValue == "Completed" || ddlOPRStatus.SelectedValue == "Cancelled")
                {
                    oListItem["CompletedDate"] = DateTime.Now;
                }
                else
                {
                    oListItem["CompletedDate"] = null;
                }
                /*End-Scan List Dev*/

                oListItem.Update();
                clientContext.ExecuteQuery();
                Label1.Text = "";
                Label2.Text = "OPR updated successfully.";
                gvOPRDeatils.EditIndex = -1;

                if (txtSubmittedDate.Text.Length > 0)
                {
                    // ViewState["searchDate"] = txtSubmittedDate.Text;
                    DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                    GetScanListData(submittedDate, null, null);
                }
                else
                {
                    GetScanListData(DateTime.Now, null, null);
                }
                //GetHPNumbers();

                //if ((ddlResubmit.SelectedValue == "Resubmit" || ddlResubmit.SelectedValue == "Update") && ddlOPRStatus.SelectedValue == "Cancelled")
                //{
                //    UpdateCancelStatus(hlnkDocNumber.Text);
                //}

                //if (ddlResubmit.SelectedValue == "Resubmit")
                //{
                //    //UpdateResbmitRequest(hlnkDocNumber.Text);
                //}
                //else if (ddlResubmit.SelectedValue == "Update" && ddlOPRStatus.SelectedValue == "Cancelled")    //Write to txt file on Cancelled for HPE purpose
                if (ddlResubmit.SelectedValue == "Update" && ddlOPRStatus.SelectedValue == "Cancelled")
                {
                    CancelLetter(hlnkDocNumber.Text, txtOPRSubject.Text, userEntity.DisplayText, ddlCC.SelectedValue);
                }
            }
            else
            {
                ButtonSave.Visible = true;
                Label1.Text = errorMessage;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e) //Need to include Data Not Found
        {

            DateTime submittedDate = String.IsNullOrEmpty(txtSubmittedDate.Text) ? searchDate : DateTime.Parse(txtSubmittedDate.Text);
            GetScanListData(submittedDate, null, null);
            //GetHPNumbers();
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(siteUrl + "/");
        }

        protected void ddlOPRSubType_SelectedIndexChanged(object sender, EventArgs e)
        {

            TextBox txt = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtDir");
            TextBox txt3 = (TextBox)gvOPRDeatils.FooterRow.FindControl("txtAttn");
            DropDownList ddlOPRType = (DropDownList)gvOPRDeatils.FooterRow.FindControl("ddlOPRType");
            DropDownList ddlOPRSubType = (DropDownList)gvOPRDeatils.FooterRow.FindControl("ddlOPRSubType");

            String concatTypeSubType = String.Empty;
            OPRTypeAssignee = GetOPRTypeAssignees();
            if (ddlOPRType.SelectedItem.Value.Equals("Financials") && ddlOPRSubType.SelectedItem.Value.Equals("Lump Sum Payments"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                //txt2.Text = "Jennifer Irwin";
                //txt3.Text = "Brenda Nixon";  ("TYpe:Subtype" , "Assignee:SubAssignee")

                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty; //"Brenda Nixon";
                txt4.Text = "";
                txt4.Enabled = false;

            }
            if ((ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Max Fee")) || (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Procedure Codes")))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Providers"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Sanction of Providers"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("New Customary Charge"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Updated Customary Charge"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }
            if (ddlOPRType.SelectedItem.Value.Equals("File Maintenance") && ddlOPRSubType.SelectedItem.Value.Equals("Nursing Home Rate Changes"))
            {
                txt.Text = String.Empty;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPRType.SelectedItem.Value + ":" + ddlOPRSubType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty;
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

            }

        }

        protected void ddlOPREditType_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlOPREditType = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlOPREditType.Parent.Parent;
            int rowindex = gvr.RowIndex;
            TextBox txt = (TextBox)gvr.FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvr.FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvr.FindControl("txtDir");
            TextBox txt3 = (TextBox)gvr.FindControl("txtAttn");
            String concatTypeSubType = String.Empty;
            DropDownList ddlOPREditSubType = (DropDownList)gvr.FindControl("ddlOPREditSubType");
            DropDownList ddlEditFinancialSeeMemo = (DropDownList)gvr.FindControl("ddlEditFinancialSeeMemo");
            txt4.ReadOnly = true;

            if (ddlOPREditType.SelectedItem.Value.Equals("Financials"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                concatTypeSubType = ddlOPREditType.SelectedItem.Value + ":" + ddlOPREditType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Text = "";
                txt4.Enabled = false;
                ddlEditFinancialSeeMemo.Visible = true;

                ddlOPREditSubType.Visible = true;
                ddlOPREditSubType.DataSource = AddOPRSubTypeFinancial();
                ddlOPREditSubType.DataBind();
            }


            else if (ddlOPREditType.SelectedItem.Value.Equals("Claims Processing"))
            {
                txt.Text = String.Empty;
                //ddl1.Enabled = false;
                ddlOPREditSubType.Visible = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPREditType.SelectedItem.Value + ":" + ddlOPREditType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime claimsDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = claimsDate.ToShortDateString();

            }
            else if (ddlOPREditType.SelectedItem.Value.Equals("File Maintenance"))
            {
                txt.Text = String.Empty;
                //ddl1.Enabled = false;
                txt.Enabled = false;
                txt.BackColor = System.Drawing.Color.Silver;
                concatTypeSubType = ddlOPREditType.SelectedItem.Value + ":" + ddlOPREditType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Enabled = true;
                DateTime FMDate = checkWeekEnd(DateTime.Now.AddDays(14));
                txt4.Text = FMDate.ToShortDateString();

                ddlOPREditSubType.Visible = true;
                ddlOPREditSubType.DataSource = AddOPRSubTypes();
                ddlOPREditSubType.DataBind();

            }
            //gvOPRDeatils.ShowFooter = true; //Show Footer on Subject_1
        }

        protected void ddlOPREditSubType_SelectedIndexChanged(object sender, EventArgs e)
        {
            //String errorMessage = String.Empty;
            DropDownList ddlOPREditSubType = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlOPREditSubType.Parent.Parent;
            DropDownList ddlOPREditType = (DropDownList)gvr.FindControl("ddlOPREditType");
            TextBox txt = (TextBox)gvr.FindControl("txtFinancial");
            TextBox txt4 = (TextBox)gvr.FindControl("txtDateofAction");
            TextBox txt2 = (TextBox)gvr.FindControl("txtDir");
            TextBox txt3 = (TextBox)gvr.FindControl("txtAttn");
            String concatTypeSubType = String.Empty;
            DropDownList ddlEditFinancialSeeMemo = (DropDownList)gvr.FindControl("ddlEditFinancialSeeMemo");
            if (ddlOPREditType.SelectedItem.Value.Equals("Financials") && ddlOPREditSubType.SelectedItem.Value.Equals("Lump Sum Payments"))
            {
                txt.Enabled = true;
                txt.BackColor = System.Drawing.Color.Red;
                concatTypeSubType = ddlOPREditType.SelectedItem.Value + ":" + ddlOPREditType.SelectedItem.Value;
                txt2.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[0] : String.Empty; //"Jennifer Irwin";
                txt3.Text = OPRTypeAssignee.ContainsKey(concatTypeSubType) ? OPRTypeAssignee[concatTypeSubType].Split(':')[1] : String.Empty;
                txt4.Text = "";
                txt4.Enabled = false;
            }

        }

        public static void CreateMergedPDF(string targetPDF, string sourceDir)
        {

        }

        protected void ddlFinancialSeeMemo_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlFinancialSeeMemo = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlFinancialSeeMemo.Parent.Parent;
            //TextBox txtFinancial = (TextBox)gvr.Cells[5].FindControl("txtFinancial");
            TextBox txtFinancial = (TextBox)gvr.FindControl("txtFinancial");
            if (ddlFinancialSeeMemo.SelectedItem.Value.Equals("See Memo"))
            {
                txtFinancial.Visible = false;
            }
            else
            {
                txtFinancial.Visible = true;
            }
        }

        protected void ddlEditFinancialSeeMemo_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlEditFinancialSeeMemo = (DropDownList)sender;
            GridViewRow gvr = (GridViewRow)ddlEditFinancialSeeMemo.Parent.Parent;
            //TextBox txtFinancial = (TextBox)gvr.Cells[9].FindControl("txtFinancial");
            TextBox txtFinancial = (TextBox)gvr.FindControl("txtFinancial");

            if (ddlEditFinancialSeeMemo.SelectedItem.Value.Equals("See Memo"))
            {
                txtFinancial.Visible = false;
            }
            else
            {
                txtFinancial.Visible = true;
            }
        }

        public static void GeneratePDF()
        {
            iTextSharp.text.Font boldHeaderfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 16, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font contentFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8, iTextSharp.text.Font.NORMAL);
            iTextSharp.text.Font boldfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 10, iTextSharp.text.Font.BOLD);
            var document = new itextSharpText.Document(itextSharpText.PageSize.A4, 10, 10, 25, 25);
            var outputMemory = new MemoryStream();
            var pdfWriter = PdfWriter.GetInstance(document, outputMemory);
            var Font = boldfont;
            document.Open();

            PdfContentByte pdfContentByte = pdfWriter.DirectContent;
            pdfContentByte.SetLineWidth(1.0f);
            pdfContentByte.MoveTo(10, document.Bottom - 10f);
            pdfContentByte.LineTo(580, document.Bottom - 10f);
            pdfContentByte.Stroke();

            itextSharpText.Paragraph headerFirst = new itextSharpText.Paragraph("FISCAL AGENT LIAISON OFFICE", boldHeaderfont);

            headerFirst.Alignment = itextSharpText.Element.ALIGN_CENTER;
            headerFirst.SpacingAfter = 10f;
            document.Add(headerFirst);
            itextSharpText.Paragraph headerSecond = new itextSharpText.Paragraph("CORRESPONDENCE TRACKING FORM", boldHeaderfont);
            headerSecond.Alignment = itextSharpText.Element.ALIGN_CENTER;
            headerSecond.SpacingAfter = 10f;
            document.Add(headerSecond);

            PdfPTable parentTable = new PdfPTable(1);

            //parentTable.DefaultCell.Border = 1;

            PdfPTable firstable = new PdfPTable(3);
            firstable.DefaultCell.Border = 0;
            PdfPTable SDNTable = new PdfPTable(1);
            SDNTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;

            //itextSharpText.Phrase statePhrase = new itextSharpText.Phrase("STATE DOCUMENT NUMBER", boldfont);
            SDNTable.AddCell(new itextSharpText.Phrase("STATE DOCUMENT NUMBER", boldfont));
            SDNTable.AddCell("" + Environment.NewLine + Environment.NewLine);
            SDNTable.AddCell("");
            SDNTable.AddCell("OPR-16-18");
            firstable.AddCell(SDNTable);

            PdfPTable AuthorTable = new PdfPTable(1);

            AuthorTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            AuthorTable.AddCell("AUTHOR" + Environment.NewLine + Environment.NewLine);
            AuthorTable.AddCell("");
            AuthorTable.AddCell("Tilak Rapaka");
            firstable.AddCell(AuthorTable);

            PdfPTable DOLTable = new PdfPTable(1);
            DOLTable.DefaultCell.Border = 0;
            DOLTable.AddCell("DATE OF LETTER" + Environment.NewLine + Environment.NewLine);
            DOLTable.AddCell("28/05/2016");
            DOLTable.AddCell("");
            firstable.AddCell(DOLTable);
            parentTable.AddCell(firstable);

            PdfPTable secondtable = new PdfPTable(3);
            secondtable.DefaultCell.Border = 0;
            PdfPTable SubjectTable = new PdfPTable(1);
            SubjectTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            SubjectTable.AddCell("SUBJECT" + Environment.NewLine + Environment.NewLine);
            SubjectTable.AddCell("");
            SubjectTable.AddCell("File Maintenance");
            SubjectTable.AddCell("Updated Customary");
            secondtable.AddCell(SubjectTable);

            PdfPTable HPNTable = new PdfPTable(1);
            HPNTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            HPNTable.AddCell("HP DOCUMENT #" + Environment.NewLine + Environment.NewLine);
            HPNTable.AddCell("");
            HPNTable.AddCell("HP-15414");
            secondtable.AddCell(HPNTable);

            PdfPTable ActionTable = new PdfPTable(1);
            ActionTable.DefaultCell.Border = 0;
            ActionTable.AddCell("ACTION " + Environment.NewLine + Environment.NewLine);
            ActionTable.AddCell("");
            ActionTable.AddCell("For Response");
            secondtable.AddCell(ActionTable);

            parentTable.AddCell(secondtable);

            PdfPTable thirdTable = new PdfPTable(3);
            thirdTable.DefaultCell.Border = 0;
            PdfPTable directedToTable = new PdfPTable(1);
            directedToTable.DefaultCell.Border = 0;
            directedToTable.AddCell("ROUTE TO:" + Environment.NewLine);
            directedToTable.AddCell("");
            thirdTable.AddCell(directedToTable);

            PdfPTable receivedByTable = new PdfPTable(1);
            receivedByTable.DefaultCell.Border = 0;
            receivedByTable.AddCell("DATE");
            receivedByTable.AddCell("");
            thirdTable.AddCell(receivedByTable);

            parentTable.AddCell(thirdTable);

            PdfPTable DirectedTOTable = new PdfPTable(2);
            DirectedTOTable.DefaultCell.Border = 0;
            PdfPTable DirectedTable = new PdfPTable(1);
            DirectedTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            DirectedTable.AddCell("DIRECTED TO:" + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine);
            DirectedTable.AddCell("");
            DirectedTable.AddCell("");
            DirectedTable.AddCell("ATTENTION:" + Environment.NewLine + Environment.NewLine);
            DirectedTOTable.AddCell(DirectedTable);

            PdfPTable ReceivedTable = new PdfPTable(1);
            ReceivedTable.DefaultCell.Border = 0;
            ReceivedTable.AddCell("RECEIVED BY (PLEASE SIGN)" + Environment.NewLine + Environment.NewLine);
            ReceivedTable.AddCell("___________________________" + Environment.NewLine + Environment.NewLine);
            ReceivedTable.AddCell("");
            ReceivedTable.AddCell("");
            ReceivedTable.AddCell("");
            ReceivedTable.AddCell("DATE:______________________" + Environment.NewLine);
            DirectedTOTable.AddCell(ReceivedTable);

            parentTable.AddCell(DirectedTOTable);

            PdfPTable MessageActionTable = new PdfPTable(1);
            MessageActionTable.DefaultCell.Border = 0;
            MessageActionTable.AddCell("MESSAGE/ACTION TO TAKE" + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine);
            MessageActionTable.AddCell("");
            MessageActionTable.AddCell("ACTION MUST BE TAKEN BY");
            MessageActionTable.AddCell("");
            MessageActionTable.AddCell("9/07/2016");
            parentTable.AddCell(MessageActionTable);

            PdfPTable reqCoordinatedTable = new PdfPTable(1);
            reqCoordinatedTable.DefaultCell.Border = 0;
            reqCoordinatedTable.AddCell("REQUEST SHOULD BE COORDINATED WITH " + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine + Environment.NewLine);
            reqCoordinatedTable.AddCell("");
            parentTable.AddCell(reqCoordinatedTable);

            PdfPTable routToParent1Table = new PdfPTable(2);
            routToParent1Table.DefaultCell.Border = 0;
            PdfPTable routTO1Table = new PdfPTable(1);
            routTO1Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO1Table.AddCell("ROUTE TO:" + Environment.NewLine + Environment.NewLine);
            routTO1Table.AddCell("");
            routTO1Table.AddCell("");
            routTO1Table.AddCell("");
            routToParent1Table.AddCell(routTO1Table);

            PdfPTable date1Table = new PdfPTable(1);
            date1Table.DefaultCell.Border = 0;
            date1Table.AddCell("DATE");
            date1Table.AddCell("");
            date1Table.AddCell("");
            routToParent1Table.AddCell(date1Table);

            parentTable.AddCell(routToParent1Table);

            PdfPTable routToParent2Table = new PdfPTable(2);
            routToParent2Table.DefaultCell.Border = 0;
            PdfPTable routTO2Table = new PdfPTable(1);
            routTO2Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO2Table.AddCell("ROUTE TO:" + Environment.NewLine + Environment.NewLine);
            routTO2Table.AddCell("");
            routTO2Table.AddCell("");
            routToParent2Table.AddCell(routTO2Table);

            PdfPTable date2Table = new PdfPTable(1);
            date2Table.DefaultCell.Border = 0;
            date2Table.AddCell("DATE" + Environment.NewLine + Environment.NewLine);
            date2Table.AddCell("");
            routToParent2Table.AddCell(date2Table);

            parentTable.AddCell(routToParent2Table);

            PdfPTable routToParent3Table = new PdfPTable(2);
            routToParent3Table.DefaultCell.Border = 0;
            PdfPTable routTO3Table = new PdfPTable(1);
            routTO3Table.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            routTO3Table.AddCell("ROUTE TO:" + Environment.NewLine + Environment.NewLine);
            routTO3Table.AddCell("");
            routToParent3Table.AddCell(routTO3Table);

            PdfPTable date3Table = new PdfPTable(1);
            date3Table.DefaultCell.Border = 0;
            date3Table.AddCell("DATE" + Environment.NewLine + Environment.NewLine);
            date3Table.AddCell("");
            routToParent3Table.AddCell(date3Table);

            parentTable.AddCell(routToParent3Table);

            PdfPTable responseParentTable = new PdfPTable(2);
            responseParentTable.DefaultCell.Border = 0;
            PdfPTable respDueTable = new PdfPTable(1);
            respDueTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            respDueTable.AddCell("RESPONSE DUE:" + Environment.NewLine + Environment.NewLine);
            respDueTable.AddCell("");
            responseParentTable.AddCell(respDueTable);

            PdfPTable responseTable = new PdfPTable(1);
            responseTable.DefaultCell.Border = 0;
            responseTable.AddCell("RESPONDENT" + Environment.NewLine + Environment.NewLine);
            responseTable.AddCell("");
            responseTable.AddCell("");
            responseParentTable.AddCell(responseTable);

            parentTable.AddCell(responseParentTable);

            PdfPTable dateRespParentTable = new PdfPTable(2);
            dateRespParentTable.DefaultCell.Border = 0;
            PdfPTable dateRespTable = new PdfPTable(1);
            dateRespTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            dateRespTable.AddCell("DATE RESPONDED:" + Environment.NewLine + Environment.NewLine);
            dateRespTable.AddCell("");
            dateRespParentTable.AddCell(dateRespTable);

            PdfPTable otherTable = new PdfPTable(1);
            otherTable.DefaultCell.Border = 0;
            otherTable.AddCell("OTHER STATE DOCUMENT #" + Environment.NewLine + Environment.NewLine);
            otherTable.AddCell("");
            dateRespParentTable.AddCell(otherTable);

            parentTable.AddCell(dateRespParentTable);


            document.Add(parentTable);
            document.Close();
            document.Dispose();

            HttpContext.Current.Response.BufferOutput = true;
            HttpContext.Current.Response.Clear();
            HttpContext.Current.Response.ClearHeaders();
            HttpContext.Current.Response.ContentType = "application/pdf";   //"application/octet-stream";
            HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=report.pdf");
            HttpContext.Current.Response.BinaryWrite(outputMemory.ToArray());
            HttpContext.Current.Response.End();

        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    GeneratePDF();
        //}

        protected void gvOPRDeatils_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            //gvOPRDeatils.PageIndex = e.NewPageIndex;
            //if (txtSubmittedDate.Text.Length > 0)
            //{
            //    // ViewState["searchDate"] = txtSubmittedDate.Text;
            //    DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
            //    GetScanListData(submittedDate, Convert.ToInt32(ddlRecordsPerPage.SelectedValue));
            //}
            //else
            //{
            //    GetScanListData(DateTime.Now, Convert.ToInt32(ddlRecordsPerPage.SelectedValue));
            //}
        }

        public void CancelLetter(String OPRNumber, String OPRSubject, String CCOPR, String CC_OPR)
        {
            iTextSharp.text.Font boldHeaderfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 16, iTextSharp.text.Font.BOLD);
            iTextSharp.text.Font contentFont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8, iTextSharp.text.Font.NORMAL);
            iTextSharp.text.Font boldfont = new iTextSharp.text.Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 10, iTextSharp.text.Font.BOLD);
            var document = new itextSharpText.Document(itextSharpText.PageSize.A4, 10, 10, 25, 25);
            var outputMemory = new MemoryStream();
            var pdfWriter = PdfWriter.GetInstance(document, outputMemory);
            var Font = boldfont;
            document.Open();

            PdfContentByte pdfContentByte = pdfWriter.DirectContent;
            pdfContentByte.SetLineWidth(1.0f);
            pdfContentByte.MoveTo(10, document.Bottom - 10f);
            pdfContentByte.LineTo(580, document.Bottom - 10f);
            pdfContentByte.Stroke();

            itextSharpText.Paragraph headerFirst = new itextSharpText.Paragraph("OPR CANCELLATION NOTICE", boldHeaderfont);

            headerFirst.Alignment = itextSharpText.Element.ALIGN_CENTER;
            headerFirst.SpacingAfter = 10f;
            document.Add(headerFirst);


            PdfPTable parentTable = new PdfPTable(1);
            parentTable.DefaultCell.Border = 0;
            //Date
            PdfPTable dateParentTable = new PdfPTable(2);
            dateParentTable.DefaultCell.Border = 0;

            PdfPTable dateChildTable = new PdfPTable(1);
            dateChildTable.DefaultCell.Border = 0;
            //dateChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            dateChildTable.AddCell("DATE:" + Environment.NewLine);
            //routTO2Table.AddCell("");
            //routTO2Table.AddCell("");
            dateParentTable.AddCell(dateChildTable);

            PdfPTable dateChildValueTable = new PdfPTable(1);
            dateChildValueTable.DefaultCell.Border = 0;
            dateChildValueTable.AddCell(DateTime.Now.ToString("d")); //date
            //date2Table.AddCell("");
            dateParentTable.AddCell(dateChildValueTable);

            parentTable.AddCell(dateParentTable);

            //TO
            PdfPTable toParentTable = new PdfPTable(2);
            toParentTable.DefaultCell.Border = 0;
            PdfPTable toChildTable = new PdfPTable(1);
            toChildTable.DefaultCell.Border = 0;
            // toChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            toChildTable.AddCell("TO:" + Environment.NewLine);

            toParentTable.AddCell(toChildTable);

            PdfPTable toChildValueTable = new PdfPTable(1);
            toChildValueTable.DefaultCell.Border = 0;
            String OriginatorName = CCOPR;
            OriginatorName = OriginatorName.Split(',')[1] + " " + OriginatorName.Split(',')[0]; //Originator Name - Not in Dev
            toChildValueTable.AddCell(OriginatorName + Environment.NewLine);
            //toChildValueTable.AddCell("Clinical Support/ DME" );
            toParentTable.AddCell(toChildValueTable);

            parentTable.AddCell(toParentTable);

            //THROUGH
            PdfPTable throughParentTable = new PdfPTable(2);
            throughParentTable.DefaultCell.Border = 0;
            PdfPTable throughChildTable = new PdfPTable(1);
            throughChildTable.DefaultCell.Border = 0;
            //throughChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            throughChildTable.AddCell("THROUGH:" + Environment.NewLine);
            throughParentTable.AddCell(throughChildTable);

            PdfPTable throughChildValueTable = new PdfPTable(1);
            throughChildValueTable.DefaultCell.Border = 0;
            throughChildValueTable.AddCell("Steve Mahan, Associate Director" + Environment.NewLine);
            throughChildValueTable.AddCell("Fiscal Agent Policy and System Management");
            throughParentTable.AddCell(throughChildValueTable);

            parentTable.AddCell(throughParentTable);

            //FROM
            PdfPTable fromParentTable = new PdfPTable(2);
            fromParentTable.DefaultCell.Border = 0;
            PdfPTable fromChildTable = new PdfPTable(1);
            fromChildTable.DefaultCell.Border = 0;
            //fromChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            fromChildTable.AddCell("FROM:" + Environment.NewLine);
            fromParentTable.AddCell(fromChildTable);

            PdfPTable fromChildValueTable = new PdfPTable(1);
            fromChildValueTable.DefaultCell.Border = 0;
            String typistName = CC_OPR;
            typistName = typistName.Split(',')[1] + " " + typistName.Split(',')[0];
            fromChildValueTable.AddCell(typistName + Environment.NewLine);
            fromChildValueTable.AddCell("Policy Management" + Environment.NewLine);
            fromParentTable.AddCell(fromChildValueTable);

            parentTable.AddCell(fromParentTable);

            //RE
            PdfPTable redParentTable = new PdfPTable(2);
            redParentTable.DefaultCell.Border = 0;
            PdfPTable reChildTable = new PdfPTable(1);
            reChildTable.DefaultCell.Border = 0;
            //reChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            reChildTable.AddCell("RE:" + Environment.NewLine);
            redParentTable.AddCell(reChildTable);

            PdfPTable reChildValueTable = new PdfPTable(1);
            reChildValueTable.DefaultCell.Border = 0;
            //reChildValueTable.AddCell("Procedure Code 99999" + Environment.NewLine + Environment.NewLine);
            reChildValueTable.AddCell(OPRSubject + Environment.NewLine + Environment.NewLine);
            redParentTable.AddCell(reChildValueTable);

            parentTable.AddCell(redParentTable);

            //Cancellation Message
            PdfPTable msgParentTable = new PdfPTable(1);
            msgParentTable.DefaultCell.Border = 0;
            PdfPTable msgChildTable = new PdfPTable(1);
            msgChildTable.DefaultCell.Border = 0;
            // msgChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            msgChildTable.AddCell("This document is official notification of cancellation for " + OPRNumber + ".");
            msgParentTable.AddCell(msgChildTable);

            parentTable.AddCell(msgParentTable);

            //Reason
            PdfPTable reasonParentTable = new PdfPTable(2);
            reasonParentTable.DefaultCell.Border = 0;
            PdfPTable reasonChildTable = new PdfPTable(1);
            reasonChildTable.DefaultCell.Border = 0;
            //reasonChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            reasonChildTable.AddCell("Reason:" + Environment.NewLine + Environment.NewLine);
            reasonParentTable.AddCell(reasonChildTable);

            PdfPTable reasonChildValueTable = new PdfPTable(1);
            reasonChildValueTable.DefaultCell.Border = 0;
            reasonChildValueTable.AddCell("Request of Originator" + Environment.NewLine);
            reasonParentTable.AddCell(reasonChildValueTable);

            parentTable.AddCell(reasonParentTable);


            //Cancellation Message
            PdfPTable cancDateParentTable = new PdfPTable(1);
            cancDateParentTable.DefaultCell.Border = 0;
            PdfPTable cancDateChildTable = new PdfPTable(1);
            cancDateChildTable.DefaultCell.Border = 0;
            //cancDateChildTable.DefaultCell.Border = iTextSharp.text.Rectangle.RIGHT_BORDER;
            cancDateChildTable.AddCell("Date of Cancellation: " + DateTime.Now.ToString("d"));
            cancDateParentTable.AddCell(cancDateChildTable);

            parentTable.AddCell(cancDateParentTable);

            document.Add(parentTable);
            document.Close();
            document.Dispose();

            byte[] FileContent = outputMemory.ToArray();
            SendMail(FileContent, OPRNumber, CCOPR);


        }

        public void SendMail(byte[] FileContent, String OPRNumber, String Originator)
        {
            //bool mailSent = false;
            SmtpClient smtpClient = null;

            string from = string.Empty;
            string smtpAddress = string.Empty;
            string to = SPContext.Current.Web.EnsureUser(Originator).Email;
            //string to = "Tilak.Rapaka@medicaid.alabama.gov";
            string subject = "Cancel Letter";
            string body = "Cancel Letter";
            String ccEmailAddress = GetCCEmailAddress();
            String bcc = null;
            from = "no-reply@medicaid.alabama.gov";
            smtpAddress = "10.131.89.54";

            try
            {
                // Assign SMTP address 
                smtpClient = new SmtpClient();
                smtpClient.Host = smtpAddress;

                //Create an email message 
                MailMessage mailMessage = new MailMessage(from, to, subject, body);
                if (!String.IsNullOrEmpty(ccEmailAddress))
                {
                    String[] ccEmailAddressArray = ccEmailAddress.Split(';');
                    foreach (String emailAddress in ccEmailAddressArray)
                    {
                        mailMessage.CC.Add(new MailAddress(emailAddress));
                    }
                }
                if (!String.IsNullOrEmpty(bcc))
                {
                    MailAddress BCCAddress = new MailAddress(bcc);
                    mailMessage.Bcc.Add(BCCAddress);
                }
                mailMessage.IsBodyHtml = true;

                // Send the email 
                mailMessage.Attachments.Add(new System.Net.Mail.Attachment(new MemoryStream(FileContent), OPRNumber + ".pdf"));
                smtpClient.Send(mailMessage);
                //mailSent = true;
            }
            catch (Exception)
            {
                //mailSent = false;
            }

            //return mailSent;
        }

        protected void ddlRecordsPerPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtSubmittedDate.Text.Length > 0)
            {
                // ViewState["searchDate"] = txtSubmittedDate.Text;
                DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                GetScanListData(submittedDate, null, null);
            }
            else
            {
                GetScanListData(DateTime.Now, null, null);
            }
            //GetHPNumbers();
        }

        protected String GetCCEmailAddress() //Reading CC'ed Emails from CancelLetter List
        {
            String CCEmail = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList ccEmailList = currentWeb.Lists["CancelLetter"];
                    SPQuery camlQuery = new SPQuery();
                    SPListItemCollection itemColl = ccEmailList.GetItems(camlQuery);
                    foreach (SPListItem item in itemColl)
                    {
                        CCEmail += Convert.ToString(item["Email"]) + ";";
                    }
                    CCEmail = CCEmail.Remove(CCEmail.LastIndexOf(';'), 1);
                }
            }
            return CCEmail;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            if (txtSubmittedDate.Text.Length > 0)
            {
                searchDate = DateTime.Parse(txtSubmittedDate.Text);
            }
            String pageInfo = ViewState["Prev"] as String;
            SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            GetScanListData(searchDate, oPos, "prev");
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            if (txtSubmittedDate.Text.Length > 0)
            {
                searchDate = DateTime.Parse(txtSubmittedDate.Text);
            }
            String pageInfo = ViewState["Next"] as String;
            SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            GetScanListData(searchDate, oPos, "next");
        }

        public string PDFURlFormat(object oprID)
        {
            return "OpenPdfInClient(" + String.Format("/teams/FiscalAgent/director/Scan%20OPR/OPR-17-1024-23.pdf", Convert.ToString(oprID)) + ")";
        }
    }
}
