﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using System.IO;
using Microsoft.SharePoint;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Globalization;
using System.Web;
using Microsoft.SharePoint.Utilities;

namespace Medicaid_OPRForm.DataMigration
{
    [ToolboxItemAttribute(false)]
    public partial class DataMigration : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public DataMigration()
        {
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        String folderBALPath = @"C:\Users\txrapaka\Desktop\FAL\BA_1";
        //String folderCSR_RequestsPath = @"C:\Users\txrapaka\Desktop\FAL\CSR_Requests";
        //String folderCSR_RequestsPath = @"D:\Privacy_Requests"; //Privacy
        String folderCSR_RequestsPath = @"D:\OPR_Forms"; //OPR_Forms
        //String folderCSR_RequestsPath = @"C:\Users\txrapaka\Desktop\FAL\OPR_Forms"; //Test Folder
        //String folderCSR_RequestsPath = @"D:\EDS_Forms"; //HPE Requests
        //String fileName = String.Empty;
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void btnUploadData_Click(object sender, EventArgs e)
        {
            //BALUpload();
            CSRRequests();

        }
        public void CSRRequests()
        {
            //String[] files = Directory.GetFiles(folderCSR_RequestsPath).Select(s => Path.GetFileName(s)).ToArray();
            //String selectedFile = files.Select(x => x.Contains(fileName)).ToString();
            SPUtility.ValidateFormDigest();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                String[] directories = Directory.GetDirectories(folderCSR_RequestsPath).ToArray();
                String directoryName = String.Empty;
                foreach (String directory in directories)
                {
                    Int32 lastIndex = directory.LastIndexOf("\\");
                    directoryName = directory.Substring(lastIndex + 1, (directory.Length - lastIndex) - 1);
                    String fileName = folderCSR_RequestsPath + "\\fddpglist" + directoryName;
                    CSRReuestUpload(fileName, directoryName);
                    //EDSReuestUpload(fileName, directoryName);
                    //break;
                }
            });
        }
        public void EDSReuestUpload(String fileName, String directoryName)
        {
            String[] dataArray;
            SPUtility.ValidateFormDigest();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                var rows = File.ReadLines(fileName + ".txt").Select(a => a.Split('\n'));
                foreach (String[] row in rows)
                {
                    dataArray = SplitCSV(row[0]);
                    UploadEDSDataToList(dataArray, directoryName);
                    //break;
                }
            });
        }
        public static string[] SplitCSV(string input)
        {
            Regex csvSplit = new Regex("(?:^|,)(\"(?:[^\"]+|\"\")*\"|[^,]*)", RegexOptions.Compiled);
            List<string> list = new List<string>();
            string curr = null;
            foreach (Match match in csvSplit.Matches(input))
            {
                curr = match.Value;
                if (0 == curr.Length)
                {
                    list.Add("");
                }

                list.Add(curr.TrimStart(','));
            }

            return list.ToArray<string>();
        }

        public void CSRReuestUpload(String fileName, String directoryName)
        {
            String[] dataArray;
            SPUtility.ValidateFormDigest();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                var rows = File.ReadLines(fileName + ".txt").Select(a => a.Split('\n'));
                foreach (String[] row in rows)
                {
                    //dataArray = row.SingleOrDefault().Split(',');
                    dataArray = SplitCSV(row[0]);
                    UploadCSrRequestDataToList(dataArray, directoryName);
                    //break;
                }
            });
        }

        public void UploadEDSDataToList(String[] dataArray, String directoryName)
        {
            String csrFileName = String.Empty;
            String OPR_Subject = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList CSRRequestsList = currentWeb.Lists["Scan List"];
                    SPListItem item = CSRRequestsList.AddItem();
                    item["OPR_Date"] = Convert.ToString(dataArray[0]);
                    item["OPR_Test"] = Convert.ToString(dataArray[1]);
                    if (!String.IsNullOrEmpty(dataArray[2]))
                    {
                        OPR_Subject = dataArray[2];
                        OPR_Subject = dataArray[2].Replace("\"", "").Trim('\"');//HPE_Subject.Replace("\"", ""); //
                        //String pattern = @"""[^""\\]*(?:\\.[^""\\]*)*""";
                        //Regex.Replace(HPE_Subject,pattern,String.Empty);
                        //HPE_Subject = HttpUtility.HtmlEncode(HPE_Subject);// HPE_Subject.Substring(1, (HPE_Subject.Length - 1));
                    }
                    item["OPRSubject"] = OPR_Subject;
                    item["OPRMessage"] = String.IsNullOrEmpty(dataArray[3]) ? String.Empty : "OPR-" + dataArray[2];
                    item["Division"] = Convert.ToString(dataArray[4]); //New Column
                    item["ExpectedCompletedDate"] = Convert.ToString(dataArray[5]); //Old OPR Column
                    item["OPRStatus"] = Convert.ToString(dataArray[6]); //OPRStatus
                    item["HP_OPR"] = Convert.ToString(dataArray[7]); //HP_OPR
                    item["EDSCompletedDate"] = Convert.ToString(dataArray[8]); //New Column
                    item["CCOPR"] = Convert.ToString(dataArray[9]); //Originator
                    item["CSRNumber"] = Convert.ToString(dataArray[10]);
                    item["ITBNumber"] = Convert.ToString(dataArray[11]);
                    //item["DateReceived"] = DateTime.Parse(dataArray[4]).ToShortDateString(); //DateTime.ParseExact(dataArray[4], "dd/MM/yyyy", new CultureInfo("en-US"), DateTimeStyles.None); 
                    //csrFileName = dataArray[5];
                    item.Update();

                    Int32 lastIndex = csrFileName.LastIndexOf("/");
                    //csrFileName = csrFileName.Substring(lastIndex + 1, (csrFileName.Length - lastIndex) - 5);
                    csrFileName = csrFileName.Substring(lastIndex + 1, (csrFileName.Length - lastIndex) - 1);
                    //String folderFullPath = folderCSR_RequestsPath + "\\" + directoryName + "\\" + csrFileName + ".pdf";
                    String folderFullPath = folderCSR_RequestsPath + "\\" + directoryName + "\\" + csrFileName; //+ ".pdf";
                    Byte[] fileArray = File.ReadAllBytes(folderFullPath);
                    //item.Attachments.Add(dataArray[0] + ".pdf", fileArray);
                    item.Attachments.Add(dataArray[0] + "." + csrFileName.Split('.'), fileArray);
                    item.Update();

                }
            }
        }

        public void UploadCSrRequestDataToList(String[] dataArray, String directoryName)
        {
            //if (!dataArray[12].Contains(".docx"))
            ////if (!((dataArray[12].Contains(".tif")) || (dataArray[12].Contains(".msg"))))
            //{
                String csrFileName = String.Empty;
                String OPR_Subject = String.Empty;
                String OPRFileName = String.Empty;
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList CSRRequestsList = currentWeb.Lists["Scan List"];
                        SPListItem item = CSRRequestsList.AddItem();
                        item["OPR_Date"] = Convert.ToString(dataArray[0]);
                        OPRFileName = "OPR-" + Convert.ToString(dataArray[1]);
                        //OPRFileName = Convert.ToString(dataArray[1]);
                        item["OPR_Test"] = OPRFileName;
                        if (!String.IsNullOrEmpty(dataArray[2]))
                        {
                            OPR_Subject = dataArray[2];
                            OPR_Subject = dataArray[2].Replace("\"", "").Trim('\"');//HPE_Subject.Replace("\"", ""); //
                        }
                        item["OPRSubject"] = OPR_Subject;
                        item["OPRMessage"] = dataArray[3];
                        item["Division"] = Convert.ToString(dataArray[4]); //New Column
                        item["ExpectedCompletedDate"] = String.IsNullOrEmpty(dataArray[5]) ? null : dataArray[5]; //Old OPR Column
                        item["OPRStatus"] = Convert.ToString(dataArray[6]); //OPRStatus
                        item["HP_OPR"] = Convert.ToString(dataArray[7]); //HP_OPR
                        item["EDSCompletedDate"] = Convert.ToString(dataArray[8]); //New Column
                        item["CCOPR"] = Convert.ToString(dataArray[9]); //Originator
                        item["CSRNumber"] = Convert.ToString(dataArray[10]);
                        item["ITBNumber"] = Convert.ToString(dataArray[11]);
                        csrFileName = dataArray[12];
                        item.Update();

                        Int32 lastIndex = csrFileName.LastIndexOf("/");
                        //csrFileName = csrFileName.Substring(lastIndex + 1, (csrFileName.Length - lastIndex) - 5);
                        csrFileName = csrFileName.Substring(lastIndex + 1, (csrFileName.Length - lastIndex) - 1);
                        if (csrFileName.Split('.')[1] == "tif")
                        {
                            csrFileName = csrFileName.Split('.')[0] + ".pdf";
                        }
                        if (csrFileName.Split('.')[1] == "msg")
                        {
                            csrFileName = csrFileName.Split('.')[0] + ".msg";
                        }
                        //String folderFullPath = folderCSR_RequestsPath + "\\" + directoryName + "\\" + csrFileName + ".pdf";

                        UploadCSRRequestsFileToDocumentLibrary(csrFileName, OPRFileName, directoryName);
                    }
                }
            }
        //}

        public void UploadCSRRequestsFileToDocumentLibrary(String fileName, String newFileName, String directoryName)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList CSRRequestsLibrary = currentWeb.Lists["Scan OPR"];
                    //String folderFullPath = folderCSR_RequestsPath + "\\" + directoryName + "\\" + fileName + ".pdf";
                    String folderFullPath = folderCSR_RequestsPath + "\\" + directoryName + "\\" + fileName;
                    Byte[] fileArray = File.ReadAllBytes(folderFullPath);
                    //SPFile file = currentWeb.Files.Add(CSRRequestsLibrary.RootFolder + "/" + newFileName + ".pdf", fileArray, true);
                    SPFile file = currentWeb.Files.Add(CSRRequestsLibrary.RootFolder + "/" + newFileName + "." + fileName.Split('.')[1], fileArray, true);

                    CSRRequestsLibrary.Update();
                }
            }
        }

        public void BALUpload()
        {
            String[] dataArray;
            SPUtility.ValidateFormDigest();
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                var rows = File.ReadLines(@"C:\Users\txrapaka\Desktop\fddpglist0000000001.txt").Select(a => a.Split('\n'));
                foreach (String[] row in rows)
                {
                    dataArray = row.SingleOrDefault().Split(',');
                    UploadDataToList(dataArray);
                    //break;
                }
            });
        }

        public void UploadDataToList(String[] dataArray)
        {
            String fileName = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList HPEList = currentWeb.Lists["BusinessAssociates"];
                    SPListItem item = HPEList.AddItem();
                    item["BANumber"] = dataArray[0];
                    item["BAName"] = dataArray[1];
                    item["BADate"] = dataArray[2];
                    item["BAOwner"] = dataArray[3];
                    fileName = dataArray[4];
                    item.Update();
                    Int32 lastIndex = fileName.LastIndexOf("/");
                    fileName = fileName.Substring(lastIndex + 1, (fileName.Length - lastIndex) - 5);
                    UploadFileToDocumentLibrary(fileName, dataArray[0]);
                }
            }
        }

        public void UploadFileToDocumentLibrary(String fileName, String newFileName)
        {


            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList BusinessAssociatesLibrary = currentWeb.Lists["Business-Associates"];
                    String folderFullPath = folderBALPath + "\\" + fileName + ".pdf";
                    Byte[] fileArray = File.ReadAllBytes(folderFullPath);
                    SPFile file = currentWeb.Files.Add(BusinessAssociatesLibrary.RootFolder + "/" + newFileName + ".pdf", fileArray, true);
                    BusinessAssociatesLibrary.Update();
                }
            }
        }
    }
}
