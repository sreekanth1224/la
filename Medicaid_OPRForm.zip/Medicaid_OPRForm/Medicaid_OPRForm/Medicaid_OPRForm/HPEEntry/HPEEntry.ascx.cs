﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CL = Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.Text;
using System.Net;



namespace Medicaid_OPRForm.HPEEntry
{
    [ToolboxItemAttribute(false)]
    public partial class HPEEntry : WebPart
    {

        public HPEEntry()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        //String userID = "txrapaka";
        //String pwd = "Prattville@1";
        //String domain = "SPDev";
        String userID = "svc.sp.appservice";
        String pwd = "@this40r";
        String domain = "MS-Medicaid";
        String strQuery = String.Empty;
        public void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetEDS_Numbers();
                //GenerateOPRIDs(ddlOPRNumber);
                if (grvStudentDetails.Rows.Count == 0)
                {
                    GetHPEntryDetails(DateTime.Now);
                }
            }
        }

        public void GetHPEntryDetails(DateTime requestedDate)
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList HPEList = currentWeb.Lists["HPE"];
                        SPQuery query = new SPQuery();
                        strQuery = "<Where>" +
                                        "<Eq>" +
                                             "<FieldRef Name='DateReceived'/>" +
                                             "<Value Type='DateTime' IncludeTimeValue='Flase'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(requestedDate.Date) + "</Value>" +
                                        "</Eq>" +
                                    "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.RowLimit = 20;
                        query.ViewFields = string.Concat(
                                    "<FieldRef Name='ID' />",
                                    "<FieldRef Name='Author_HPE' />",
                                    "<FieldRef Name='DateReceived' />",
                                    "<FieldRef Name='EDS_Number' />",
                                    "<FieldRef Name='OPR_Number' />",
                                     "<FieldRef Name='Subject_HPE' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        SPListItemCollection listColl = HPEList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DataTable dtHPE = listColl.GetDataTable();
                            grvStudentDetails.DataSource = dtHPE;
                            grvStudentDetails.DataBind();
                            ViewState["HPEntryDetails"] = dtHPE;
                        }
                        else
                        {
                            DataTable dt = new DataTable();
                            grvStudentDetails.DataSource = dt;
                            grvStudentDetails.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /*Generate OPRID*/
        //public void GenerateOPRIDs(DropDownList dropdownOPRNumber)
        //{
        //    dropdownOPRNumber.DataSource = GetOPRIDCollection();
        //    dropdownOPRNumber.DataBind();
        //}

        public void GetEDS_Numbers()
        {
            int i = 0;
            System.Web.UI.WebControls.ListItemCollection coll = new System.Web.UI.WebControls.ListItemCollection();
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanList = currentWeb.Lists["HPE"];
                    SPQuery query = new SPQuery();
                    query.DatesInUtc = false;
                    SPListItemCollection listColl = scanList.GetItems(query);
                    if (listColl != null)
                    {
                        DataRow[] dataRows = listColl.GetDataTable().Select();
                        foreach (DataRow dataRow in dataRows)
                        {
                            if (String.IsNullOrEmpty(Convert.ToString(dataRow["Author_HPE"])))
                            {
                                coll.Insert(i, new System.Web.UI.WebControls.ListItem(dataRow["EDS_Number"].ToString()));
                                i++;
                            }
                        }
                        coll.Insert(0, String.Empty);
                        ddlEDSNumber.DataSource = coll;
                        ddlEDSNumber.DataBind();
                    }
                }
            }
        }

        //protected System.Web.UI.WebControls.ListItemCollection GetOPRIDCollection()
        //{
        //    int i = 0;

        //    System.Web.UI.WebControls.ListItemCollection coll = new System.Web.UI.WebControls.ListItemCollection();
        //    using (SPSite site = new SPSite(siteUrl))
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            SPList scanList = currentWeb.Lists["Scan List"];
        //            SPQuery query = new SPQuery();
        //            query.DatesInUtc = false;
        //            SPListItemCollection listColl = scanList.GetItems(query);
        //            if (listColl != null)
        //            {
        //                DataRow[] dataRows = listColl.GetDataTable().Select();
        //                foreach (DataRow dataRow in dataRows)
        //                {
        //                    coll.Insert(i, new System.Web.UI.WebControls.ListItem(dataRow["OPR_Test"].ToString()));
        //                    i++;
        //                }
        //                coll.Insert(0, String.Empty);

        //            }
        //        }
        //    }
        //    return coll;
        //}

        public void ButtonSave_Click(object sender, EventArgs e) //Save Records to List
        {
            String errorMessage = String.Empty;

            if (txtDateReceived.Text == "")
            {
                errorMessage = "Please enter date received";
            }
            else if (ddlEDSNumber.SelectedIndex == 0)
            {
                errorMessage = "Please enter HP Number";
            }
            else if (txtSubject.Text == "")
            {
                errorMessage = "Please enter Subject";
            }
            else if (txtAuthorHPE.Text == "")
            {
                errorMessage = "Please enter Author";
            }
            

            if (String.IsNullOrEmpty(errorMessage))
            {
                using (ClientContext context = new ClientContext(siteUrl))
                {
                    context.Credentials = new NetworkCredential(userID, pwd, domain);

                    lblErrorMessage.Text = String.Empty;
                    List oList = context.Web.Lists.GetByTitle("HPE");
                    CamlQuery camlQuery = new CamlQuery();
                    camlQuery.ViewXml = "<View><Query><Where><Eq><FieldRef Name='EDS_Number'/>" +
                        "<Value Type='Text'>" + ddlEDSNumber.SelectedValue + "</Value></Eq></Where></Query></View>";
                    CL.ListItemCollection listItems = oList.GetItems(camlQuery);
                    context.Load(listItems);
                    context.ExecuteQuery();
                    foreach (CL.ListItem oListItem in listItems)
                    {
                        oListItem["Author_HPE"] = txtAuthorHPE.Text;
                        oListItem["DateReceived"] = DateTime.Parse(txtDateReceived.Text);
                        oListItem["EDS_Number"] = ddlEDSNumber.SelectedValue;
                        oListItem["OPR_Number"] = txtOPRNumber.Text;
                        oListItem["Subject_HPE"] = txtSubject.Text;
                        oListItem.Update();
                    }

                    context.ExecuteQuery();
                    lblSuccessMessage.Text = "HP Request submitted successfully.";
                    Page.Response.Redirect(siteUrl + "SitePages/hpentry.aspx"); //Dev Site
                    GetHPEntryDetails(DateTime.Now);
                }
            }
            else
            {
                lblErrorMessage.Text = errorMessage;
            }
        }

        protected void grvStudentDetails_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvStudentDetails.EditIndex = e.NewEditIndex;
            DataTable dtHPEntryDetails = ViewState["HPEntryDetails"] as DataTable;
            grvStudentDetails.DataSource = dtHPEntryDetails;
            grvStudentDetails.DataBind();

        }

        protected void grvStudentDetails_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvStudentDetails.EditIndex = -1;
            DataTable dtHPEntryDetails = ViewState["HPEntryDetails"] as DataTable;
            grvStudentDetails.DataSource = dtHPEntryDetails;
            grvStudentDetails.DataBind();
            GetHPEntryDetails(DateTime.Now);

        }

        protected void grvStudentDetails_RowUpdating(object sender, GridViewUpdateEventArgs e) //Update records upon edit
        {

            btnSave.Visible = true;
            TextBox txtEditAuthorHPE = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtEditAuthorHPE");
            TextBox txtEditOPRNumber = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtEditOPRNumber");
            TextBox txtEditSubject = (TextBox)grvStudentDetails.Rows[e.RowIndex].FindControl("txtEditSubject");
            //DropDownList ddlEditOPRNumber = (DropDownList)grvStudentDetails.Rows[e.RowIndex].FindControl("ddlEditOPRNumber");
            HiddenField hiddenItemID = (HiddenField)grvStudentDetails.Rows[e.RowIndex].FindControl("hiddenID");

            String errorMessage = String.Empty;

            if (txtEditAuthorHPE.Text == "")
            {
                errorMessage = "Please Enter Author";
            }
            else if (txtEditSubject.Text == "")
            {
                errorMessage = "Please Enter Subject";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {
                ClientContext clientContext = new ClientContext(siteUrl);
                clientContext.Credentials = new NetworkCredential(userID, pwd, domain);
                //clientContext.Credentials = new NetworkCredential("txrapaka", "Prattville@1", "SPDev");
                //clientContext.Credentials = new NetworkCredential("svc.sp.appservice", "@this40r", "MS-Medicaid");

                lblErrorMessage.Text = String.Empty;
                //ClientContext clientContext = new ClientContext(siteUrl);
                List oList = clientContext.Web.Lists.GetByTitle("HPE");

                int listItemID = Convert.ToInt32(hiddenItemID.Value);
                CL.ListItem oListItem = oList.GetItemById(listItemID);
                oListItem["Author_HPE"] = txtEditAuthorHPE.Text;
                oListItem["Subject_HPE"] = txtEditSubject.Text;
                oListItem["OPR_Number"] = txtEditOPRNumber.Text;
                //if (ddlEditOPRNumber.SelectedValue != "Please select")
                //{
                //    oListItem["OPR_Number"] = ddlEditOPRNumber.SelectedItem.Value;
                //}
                //else
                //{
                //    oListItem["OPR_Number"] = "";
                //}

                oListItem.Update();
                clientContext.ExecuteQuery();
                lblSuccessMessage.Text = "HP Request updated successfully.";
                Page.Response.Redirect(siteUrl + "SitePages/hpentry.aspx"); //Dev Site
                //Page.Response.Redirect(siteUrl + "SitePages/hpentry.aspx"); 

                grvStudentDetails.EditIndex = -1;
                if (txtSubmittedDate.Text.Length > 0)
                {
                    // ViewState["searchDate"] = txtSubmittedDate.Text;
                    DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                    GetHPEntryDetails(submittedDate);       //Submitted Date Values
                }
                else
                {
                    GetHPEntryDetails(DateTime.Now);
                }

                //GetHPEntryDetails(DateTime.Now);

            }
            else
            {
                lblErrorMessage.Text = errorMessage;
            }
        }

        protected void grvStudentDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            //if (e.Row.RowType == DataControlRowType.DataRow)
            //{
            //    if (grvStudentDetails.EditIndex == e.Row.RowIndex)
            //    {

            //        //DropDownList ddlEditOPRNumber = (DropDownList)e.Row.FindControl("ddlEditOPRNumber");
            //        //GenerateOPRIDs(ddlEditOPRNumber);
            //        //ddlEditOPRNumber.SelectedValue = ((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[4] as String;

            //    }
            //    else
            //    {
            //        //Label lblDateReceived = (Label)e.Row.FindControl("lblDateReceived");
            //        //lblDateReceived.Text = DateTime.Parse(((System.Data.DataRowView)(e.Row.DataItem)).Row.ItemArray[2] as String).ToShortDateString();
            //    }
            //}

        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(siteUrl + "/");

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (txtSubmittedDate.Text != null)
            {
                DateTime submittedDate = DateTime.Parse(txtSubmittedDate.Text);
                GetHPEntryDetails(submittedDate);
            }
        }


    }
}
