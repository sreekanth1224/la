﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using System;
using System.ComponentModel;
using System.Net;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using Microsoft.SharePoint.Administration.Claims;
using System.Web;
using System.IO;
using System.Web.UI.WebControls;

namespace Medicaid_OPRForm.ApprovalWorkflow
{
    [ToolboxItemAttribute(false)]
    public partial class ApprovalWorkflow : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        //String userID = "txrapaka";
        //String pwd = "Prattville@1";
        //String domain = "SPDev";
        //String userID = "svc.sp.appservice";
        //String pwd = "@this40r";
        //String domain = "MS-Medicaid";
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        public ApprovalWorkflow()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //GetApproverorProofer();
            if (!Page.IsPostBack)
            {
                lblSuccessMsg.Text = String.Empty;
                lblApprovalmsg.Text = String.Empty;
                ddlPendingRejectedItems.Items.Add("Pending");
                ddlPendingRejectedItems.Items.Add("Resubmitted");
                GetPendingOPRItems("Pending");
            }
        }

        public void GetPendingOPRItems(String itemStatus)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
                    SPQuery camlQuery = new SPQuery();
                    if (itemStatus == "Pending")
                    {
                        camlQuery.Query = "<Where>" +
                                            "<And>" +
                                            "<Eq>" +
                                               "<FieldRef Name='EmailSent'/>" +
                                               "<Value Type='Boolean'>1</Value>" +
                                             "</Eq>" +
                                             "<IsNull>" +
                                               "<FieldRef Name='ApprovalStatus'/>" +
                                             "</Eq>" +
                                              "</IsNull>" +
                                         "</Where>";
                    }
                    else
                    {
                        camlQuery.Query = "<Where>" +
                                           "<And>" +
                                           "<Eq>" +
                                              "<FieldRef Name='EmailSent'/>" +
                                              "<Value Type='Boolean'>1</Value>" +
                                            "</Eq>" +
                                            "<Eq>" +
                                              "<FieldRef Name='ApprovalStatus'/>" +
                                              "<Value Type='Text'>Resubmitted</Value>" +
                                            "</Eq>" +
                                             "</And>" +
                                        "</Where>";
                    }
                    SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);

                    if (itemColl != null && itemColl.Count > 0)
                    {
                        gvWorkflowItems.DataSource = itemColl.GetDataTable();
                        gvWorkflowItems.DataBind();
                    }
                    else
                    {
                        gvWorkflowItems.DataSource = null;
                        gvWorkflowItems.DataBind();
                    }
                }
            }
        }

        protected void ddlPendingRejectedItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            GetPendingOPRItems(ddlPendingRejectedItems.SelectedValue);
        }

        public void GetApproverorProofer()
        {
            //try
            //{
            //    String siteUrl = SPContext.Current.Site.Url + "/director/";
            //    ClientContext clientContext = new ClientContext(siteUrl);
            //    clientContext.Credentials = new NetworkCredential(userID, pwd, domain);
            //    String userName = SPContext.Current.Web.CurrentUser.Name;

            //    //validate user
            //    List listOPRApprovers = clientContext.Web.Lists.GetByTitle("OPR Approvers");
            //    CamlQuery camlQuery = new CamlQuery();
            //    camlQuery.ViewXml = "<View><Query><Where><Eq><FieldRef Name='Name'/>" +
            //        "<Value Type='Text'>" + userName + "</Value></Eq></Where></Query></View>";
            //    ListItemCollection listItems = listOPRApprovers.GetItems(camlQuery);
            //    clientContext.Load(listItems);
            //    clientContext.ExecuteQuery();
            //    String userType = String.Empty;
            //    List<String> userTypeList = new List<String>();
            //    foreach (ListItem listItem in listItems)
            //    {
            //        userTypeList.Add(Convert.ToString(listItem["UserType"]));
            //    }

            //    List oList = clientContext.Web.Lists.GetByTitle("Scan OPR");
            //    int scanListID = Convert.ToInt32(Page.Request.QueryString["listid"]);
            //    ListItem oListItem = oList.GetItemById(scanListID);
            //    clientContext.Load(oListItem);
            //    clientContext.ExecuteQuery();
            //    String approverStatus = Convert.ToString(oListItem["ApprovalStatus"]);
            //    String OPRApprovalStatus = Convert.ToString(oListItem["Status"]);//Check 'OPR Approval' workflow status 
            //    if (OPRApprovalStatus == "Cancelled")
            //    {
            //        lblApprovalmsg.ForeColor = System.Drawing.Color.Red;
            //        lblApprovalmsg.Font.Bold = true;
            //        lblApprovalmsg.Text = "Workflow has been cancelled";
            //        btnApprove.Enabled = false;
            //        btnReject.Enabled = false;
            //        txtComment.Enabled = false;
            //    }
            //    else
            //    {
            //        if (userTypeList.Contains("Proofer") && String.IsNullOrEmpty(approverStatus) && String.IsNullOrEmpty(Convert.ToString(oListItem["Proofer"])))
            //        {
            //            userType = "Proofer";
            //        }
            //        else if (userTypeList.Contains("Approver") && approverStatus == "Proofer Approved" && String.IsNullOrEmpty(Convert.ToString(oListItem["Approver"])))
            //        {
            //            userType = "Approver";
            //        }
            //        else if (userTypeList.Contains("Proofer") && approverStatus == "Proofer Rejected" && String.IsNullOrEmpty(Convert.ToString(oListItem["Approver"])))
            //        {
            //            userType = "Proofer";
            //        }
            //        else if (userTypeList.Contains("Approver") && approverStatus == "Approver Rejected" && String.IsNullOrEmpty(Convert.ToString(oListItem["Approver"])))
            //        {
            //            userType = "Approver";
            //        }
            //        String OPRNumber = Convert.ToString(oListItem["FileLeafRef"]);

            //        lblWorflowMessage.Text = userType + " : " + OPRNumber.Split('.')[0] + "/" + Convert.ToString(oListItem["Subject_1"]) + "/" + Convert.ToString(oListItem["OPRMessage"]);
            //    }

            //}
            //catch (Exception ex)
            //{
            //    lblWorflowMessage.Text = HttpContext.Current.User.Identity.Name;

            //}
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            String errorMessage = String.Empty;
            Boolean isRejeced = false;
            foreach (GridViewRow row in gvWorkflowItems.Rows)
            {
                Label lblID = row.FindControl("lblID") as Label;
                TextBox txtComments = row.FindControl("txtComments") as TextBox;
                DropDownList ddlApproveReject = row.FindControl("ddlApproveReject") as DropDownList;
                HyperLink hlnkOPRNumber = row.FindControl("hlnkDocNumber") as HyperLink;
                String strOPRNumber = hlnkOPRNumber.Text.Split('.')[0];

                if (ddlApproveReject.SelectedValue != "Select" || ddlApproveReject.SelectedValue == "Select")
                {
                    if (ddlApproveReject.SelectedValue == "Select")
                    {
                        //isRejeced = true;
                        //errorMessage += strOPRNumber + ", ";
                        lblSuccessMsg.Text = String.Empty;
                        lblApprovalmsg.Text = "Please select Approve or Reject";
                    }
                    else if (ddlApproveReject.SelectedValue == "Reject" && txtComments.Text.Length == 0)
                    {
                        isRejeced = true;
                        errorMessage += strOPRNumber + ", ";
                        lblSuccessMsg.Text = String.Empty;
                        lblApprovalmsg.Text = "Please enter comments for the rejected OPRs: " + errorMessage;
                    }
                    else
                    {
                        UpdateListItem(Convert.ToInt32(lblID.Text), ddlApproveReject.SelectedValue, txtComments.Text);
                        UpdateScanListItem(strOPRNumber, ddlApproveReject.SelectedValue);
                        GetPendingOPRItems(ddlPendingRejectedItems.SelectedValue);
                        lblApprovalmsg.Text = String.Empty;
                        btnSubmit.Visible = false;
                        lblSuccessMsg.Text = "OPRs status submitted successfully.";
                    }
                }
            }
            if (isRejeced)
            {
                errorMessage = errorMessage.Remove(errorMessage.LastIndexOf(','));
            }
        }

        public void UpdateScanListItem(String OPRNumber, String status)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanList = currentWeb.Lists["Scan List"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                         "<Eq>" +
                                            "<FieldRef Name='OPR_Test'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                            "<Value Type='Text'>" + OPRNumber + "</Value>" +
                                          "</Eq>" +
                                      "</Where>";
                    SPListItemCollection itemColl = scanList.GetItems(camlQuery);

                    if (itemColl != null && itemColl.Count > 0)
                    {
                        SPListItem item = itemColl[0];
                        item["ApprovalStatus"] = (status == "Approve") ? "Approver Approved" : "Approver Rejected";
                        item.Update();
                    }
                }
            }
        }

        public void UpdateListItem(Int32 itemID, String status, String comments)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
                    SPListItem scanListItem = scanOPRLib.GetItemById(itemID);
                    SPFile file = scanListItem.File;
                    file.Item.Properties["EmailSent"] = false;
                    file.Item.Properties["ApprovalStatus"] = (status == "Approve") ? "Approver Approved" : "Approver Rejected";
                    file.Item.Properties["Approver"] = (status == "Approve") ? "Approver" : "";
                    file.Item.Properties["UserComment"] = comments;
                    file.Item.SystemUpdate();
                    file.Update();
                    scanOPRLib.Update();
                }
            }
        }

        //protected void OPRApproval(String reqStatus, String userComment)
        //{
        //    try
        //    {
        //        String siteUrl = SPContext.Current.Site.Url + "/director/";
        //        ClientContext clientContext = new ClientContext(siteUrl);
        //        clientContext.Credentials = new NetworkCredential(userID, pwd, domain);
        //        String userName = SPContext.Current.Web.CurrentUser.Name;

        //        //validate user
        //        List listOPRApprovers = clientContext.Web.Lists.GetByTitle("OPR Approvers");
        //        CamlQuery camlQuery = new CamlQuery();
        //        camlQuery.ViewXml = "<View><Query><Where><Eq><FieldRef Name='Name'/>" +
        //            "<Value Type='Text'>" + userName + "</Value></Eq></Where></Query></View>";
        //        ListItemCollection listItems = listOPRApprovers.GetItems(camlQuery);
        //        clientContext.Load(listItems);
        //        clientContext.ExecuteQuery();
        //        String userType = String.Empty;
        //        List<String> userTypeList = new List<String>();
        //        foreach (ListItem listItem in listItems)
        //        {
        //            //userType = Convert.ToString(listItem["UserType"]); //UserType to determine proofer/approver
        //            userTypeList.Add(Convert.ToString(listItem["UserType"]));
        //        }


        //        List oList = clientContext.Web.Lists.GetByTitle("Scan OPR");
        //        int scanListID = Convert.ToInt32(Page.Request.QueryString["listid"]);
        //        ListItem oListItem = oList.GetItemById(scanListID);
        //        clientContext.Load(oListItem);
        //        clientContext.ExecuteQuery();
        //        String scanOPRNumber = Convert.ToString(oListItem["FileLeafRef"]);
        //        scanOPRNumber = scanOPRNumber.Split('.')[0];

        //        //Scan List-Match and update OPR Number from Scan OPR to Scan List
        //        List scanList = clientContext.Web.Lists.GetByTitle("Scan List");
        //        CamlQuery scanCamlQuery = new CamlQuery();
        //        scanCamlQuery.ViewXml = "<View><Query><Where><Eq><FieldRef Name='OPR_Test'/><Value Type='Text'>" + scanOPRNumber + "</Value></Eq></Where></Query></View>";
        //        ListItemCollection scanListItemColl = scanList.GetItems(scanCamlQuery);
        //        clientContext.Load(scanListItemColl);
        //        clientContext.ExecuteQuery();
        //        ListItem scanListItem = scanListItemColl[0];


        //        String approverStatus = String.Empty;
        //        String approvalMsg = String.Empty;
        //        Boolean userStatus = false;
        //        //approvalMsg = userType + ":" + reqStatus + ":" + siteUrl + ":" + userName;
        //        if (userTypeList.Contains("Proofer") && reqStatus == "approved" && String.IsNullOrEmpty(Convert.ToString(oListItem["Proofer"])))
        //        {
        //            userType = "Proofer";
        //            approverStatus = "Proofer Approved";
        //            approvalMsg = "Proofer Request has been approved, Thankyou.";
        //            userStatus = true;
        //        }
        //        else if (userTypeList.Contains("Proofer") && reqStatus == "rejected" && String.IsNullOrEmpty(Convert.ToString(oListItem["Proofer"])))
        //        {
        //            userType = "Proofer";
        //            approverStatus = "Proofer Rejected";
        //            approvalMsg = "Proofer Request has been Rejected, Thankyou.";
        //            userStatus = true;
        //        }
        //        else if (userTypeList.Contains("Approver") && reqStatus == "approved" && String.IsNullOrEmpty(Convert.ToString(oListItem["Approver"])))
        //        {
        //            userType = "Approver";
        //            approverStatus = "Approver Approved";
        //            approvalMsg = "Approver Request has been approved, Thankyou.";
        //            userStatus = true;
        //        }
        //        else if (userTypeList.Contains("Approver") && reqStatus == "rejected" && String.IsNullOrEmpty(Convert.ToString(oListItem["Approver"])))
        //        {
        //            userType = "Approver";
        //            approverStatus = "Approver Rejected";
        //            approvalMsg = "Approver Request has been Rejected, Thankyou.";
        //            userStatus = true;
        //        }
        //        else if (userTypeList.Contains("Proofer") && Convert.ToString(oListItem["Proofer"]) != "") //Proofer Status
        //        {
        //            approvalMsg = "Request is already submitted";
        //        }
        //        else if (userTypeList.Contains("Approver") && Convert.ToString(oListItem["Approver"]) != "") //Approver Status
        //        {
        //            approvalMsg = "Request is already submitted";
        //        }
        //        if(userStatus)
        //        {
        //            if (Convert.ToString(oListItem["ApprovalStatus"]) == approverStatus)
        //            {
        //                btnApprove.Enabled = false;
        //                btnReject.Enabled = false;
        //            }
        //            else
        //            {
        //                oListItem["ApprovalStatus"] = approverStatus;
        //                Boolean isRejected = (reqStatus == "rejected") ? true : false;
        //                if (userType == "Approver")
        //                {
        //                    oListItem["Approver"] = isRejected ? "" : "Approver"; //Approver rejects, blank the approver field
        //                    scanListItem["ApprovalStatus"] = approverStatus;//"Approver"; //Scan List Update
        //                }
        //                if (userType == "Proofer")
        //                {
        //                    oListItem["Proofer"] = isRejected ? "" : "Proofer"; //Proofer rejects, blank the Proofer field
        //                    scanListItem["ApprovalStatus"] = approverStatus;// "Proofer"; //Scan List Update
        //                }

        //                oListItem["UserComment"] = userComment; //Comment Section
        //                oListItem.Update();
        //                scanListItem.Update(); //Scan List Update
        //            }
        //        }
        //        clientContext.ExecuteQuery();
        //        lblApprovalmsg.Text = approvalMsg;

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        //protected void btnApprove_Click(object sender, EventArgs e)
        //{
        //    OPRApproval("approved", txtComment.Text);
        //    btnApprove.Enabled = false;
        //    btnReject.Enabled = false;
        //}

        //protected void btnReject_Click(object sender, EventArgs e)
        //{
        //    if (txtComment.Text.Length != 0)
        //    {
        //        OPRApproval("rejected", txtComment.Text);
        //        btnApprove.Enabled = false;
        //        btnReject.Enabled = false;
        //    }
        //    else
        //    {
        //        lblApprovalmsg.Text = "Please submit comment";
        //    }
        //}
    }
}
