﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
    public class CSRSearchEntity
    {
        public int ID { get; set; }
        public string ITBNumber { get; set; }
        public string CSRNumber { get; set; }
        public DateTime CSRDate { get; set; }
        public string DocumentType { get; set; }
        public string Status { get; set; }
        public string Originator { get; set; }
        public string OPRNumber { get; set; }
        public DateTime Created { get; set; }
        public string CSRReqFile { get; set; }
    }
}
