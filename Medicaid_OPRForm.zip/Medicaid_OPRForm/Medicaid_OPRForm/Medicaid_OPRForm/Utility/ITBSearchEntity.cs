﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
    public class ITBSearchEntity
    {
        public int ID { get; set; }
        public string ITBNumber { get; set; }
        public string Author { get; set; }
        public DateTime ITBDate { get; set; }
        public string Subject { get; set; }
        public string Status { get; set; }
    }
}
