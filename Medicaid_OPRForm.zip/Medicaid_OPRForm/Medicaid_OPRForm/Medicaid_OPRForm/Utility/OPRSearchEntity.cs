﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
   public class OPRSearchEntity
    {
        public int ID { get; set; }
        public string OPR_Test { get; set; }
        public string AuthorOPR { get; set; }
        public string CCOPR { get; set; }
        public string CC_OPR { get; set; }
        public string OPRType { get; set; }
        public DateTime OPR_Date { get; set; }
        public string OPRSubject { get; set; }
        public string OPRMessage { get; set; }
        public DateTime ExpectedCompletedDate { get; set; }
        public string CSRNumber { get; set; }
        public string ITBNumber { get; set; }
        public string HP_OPR { get; set; }
        public string OPRStatus { get; set; }
        public DateTime Created { get; set; }
        public string OPRSubType { get; set; }
    }
}
