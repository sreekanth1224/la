﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
   public class ScanListEntity
    {
        public int ID { get; set; }
        public string OPR_Test { get; set; }
        public string OPRSubject { get; set; }
        public string OPRMessage { get; set; }
        public string CCOPR { get; set; }
        public DateTime DateofActionOPR { get; set; }
    }
}
