﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using Microsoft.SharePoint.Utilities;
using Medicaid_OPRForm.Utility;
using System.Text;

namespace Medicaid_OPRForm.SearchWebparts.FAL_YrlyPndgRpts
{
    [ToolboxItemAttribute(false)]
    public partial class FAL_YrlyPndgRpts : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public FAL_YrlyPndgRpts()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindYears();
                ddlYear.SelectedValue = DateTime.Now.Year.ToString();
            }
        }
        public void BindYears()
        {
            try
            {
                Int32 currentYear = DateTime.Now.Year;
                for (Int32 year = 2017; year <= currentYear; year++)
                {
                    ddlYear.Items.Add(year.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        protected List<ScanListEntity> GetYearlyReport(String paging)
        {
            Int32 selectedYear = Convert.ToInt32(ddlYear.SelectedValue);
            Int32 firstMonth = 1;
            Int32 monthLastDay = 31;
            Int32 monthStartDay = 1;
            Int32 lastMonth = 12;
            DateTime startDate = new DateTime(selectedYear, firstMonth, monthStartDay);
            DateTime endDate = new DateTime(selectedYear, lastMonth, monthLastDay);
            String strPageInfo = String.Empty;
            Int32 pageIndex = 0;
            Int32 dropdownPageSize = 0;
            List<ScanListEntity> scanEntityList = new List<ScanListEntity>();
            DateTime tempDate;
            if (!DateTime.TryParse(txtDueDate.Text, out tempDate))
            {
                try
                {
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            List<string> objColumns = new List<string>();
                            SPQuery query = new SPQuery();
                            //String whereClause = "scanListCollection.Where(";

                            ViewState["OPRTable"] = null;
                            ViewState["pageIndex"] = null;
                            if (!String.IsNullOrEmpty(ddlYear.SelectedValue))
                            {
                                objColumns.Add("OPR_Date;DateTime;Geq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate.Date));   //Sort by OPRDate
                            }
                            if (!String.IsNullOrEmpty(ddlYear.SelectedValue))
                            {
                                objColumns.Add("OPR_Date;DateTime;Leq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate.Date));
                                objColumns.Add("OPRStatus;Text;Eq;Pending");
                            }
                            if (txtOPRNumber.Text != "OPR Number" && txtOPRNumber.Text.Length > 0)
                            {
                                objColumns.Add("OPR_Test;Text;Contains;" + txtOPRNumber.Text.Trim());
                            }
                            if (txtSubject1.Text != "Subject1" && txtSubject1.Text.Length > 0)
                            {
                                objColumns.Add("OPRSubject;Text;Contains;" + txtSubject1.Text.Trim());
                            }
                            if (txtSubject2.Text != "Subject2" && txtSubject2.Text.Length > 0)
                            {
                                objColumns.Add("OPRMessage;Text;Contains;" + txtSubject2.Text.Trim());
                            }
                            if (txtOriginator.Text != "Originator" && txtOriginator.Text.Length > 0)
                            {
                                objColumns.Add("CCOPR;Text;Contains;" + txtOriginator.Text.Trim());
                            }
                            if (txtDueDate.Text != "Due Date" && txtDueDate.Text.Length > 0)
                            {
                                objColumns.Add("DateofActionOPR;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDueDate.Text)));
                            }
                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";
                            }

                            query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='OPR_Test' />",
                                        "<FieldRef Name='OPRSubject' />",
                                        "<FieldRef Name='OPRMessage' />",
                                        "<FieldRef Name='CCOPR' />",
                                        "<FieldRef Name='DateofActionOPR' />");
                            query.DatesInUtc = false;
                            query.ViewFieldsOnly = true;
                            query.ViewAttributes = "Scope=\"RecursiveAll\"";

                            SPList ScanOPRList = currentWeb.Lists["Scan List"];
                            SPListItemCollection listColl = ScanOPRList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (scanListCount > 0)
                            {
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }

                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Gray;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                lblRecordCount.Text = Convert.ToString(scanListCollection.Count());

                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    scanEntityList.Add(new ScanListEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        OPR_Test = Convert.ToString(item["OPR_Test"]),
                                        OPRSubject = Convert.ToString(item["OPRSubject"]),
                                        OPRMessage = Convert.ToString(item["OPRMessage"]),
                                        CCOPR = Convert.ToString(item["CCOPR"]),
                                        DateofActionOPR = Convert.ToDateTime(item["DateofActionOPR"])
                                    });
                                }
                                //gvYearlyPendingReport.DataSource = scanEntityList.ToList();
                                //gvYearlyPendingReport.DataBind();

                            }
                            else
                            {
                                gvYearlyPendingReport.DataSource = null;
                                gvYearlyPendingReport.EmptyDataText = "No Records Found";
                                gvYearlyPendingReport.DataBind();
                                lblRecordCount.Text = "0";
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return scanEntityList;
        }

        public string ProcessDateTime(object value)
        {
            if (Convert.ToString(value) == "1/1/0001")
            {
                value = String.Empty;
            }

            return Convert.ToString(value);
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            //GetYearlyReport(null);
            gvYearlyPendingReport.DataSource = GetYearlyReport(null);
            gvYearlyPendingReport.DataBind();

        }

        public void ClearSearchFields()
        {
            if (txtOPRNumber.Text == "OPR Number")
            {
                txtOPRNumber.Text = "";
            }
            if (txtOriginator.Text == "Originator")
            {
                txtOriginator.Text = "";
            }
            if (txtSubject1.Text == "Subject1")
            {
                txtSubject1.Text = "";
            }
            if (txtSubject2.Text == "Subject2")
            {
                txtSubject2.Text = "";
            }
            if (txtDueDate.Text == "Due Date")
            {
                txtDueDate.Text = "";
            }
        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>");
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        //protected void ddlYear_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    GetYearlyReport(ddlYear.SelectedValue);
        //}

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GetYearlyReport(null);
            gvYearlyPendingReport.DataSource = GetYearlyReport(null);
            gvYearlyPendingReport.DataBind();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            //txtEDS_Number.Text = "DXC_Number";
            txtOPRNumber.Text = "OPR Number";
            txtOriginator.Text = "Originator";
            txtSubject1.Text = "Subject1";
            txtSubject2.Text = "Subject2";
            txtDueDate.Text = "Due Date";
            Page.Response.Redirect(siteUrl + "Pages/ypr.aspx");

        }

        public void SortColumn(String sortExpression)
        {
            List<ScanListEntity> scanEntityList = GetYearlyReport(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "OPR_Test":
                    gvYearlyPendingReport.DataSource = (sortDirection == "ASC") ? scanEntityList.OrderBy(x => x.OPR_Test).ToList() : scanEntityList.OrderByDescending(x => x.OPR_Test).ToList();
                    break;
                case "OPRSubject":
                    gvYearlyPendingReport.DataSource = (sortDirection == "ASC") ? scanEntityList.OrderBy(x => x.OPRSubject).ToList() : scanEntityList.OrderByDescending(x => x.OPRSubject).ToList();
                    break;
                case "OPRMessage":
                    gvYearlyPendingReport.DataSource = (sortDirection == "ASC") ? scanEntityList.OrderBy(x => x.OPRMessage).ToList() : scanEntityList.OrderByDescending(x => x.OPRMessage).ToList();
                    break;
                case "CCOPR":
                    gvYearlyPendingReport.DataSource = (sortDirection == "ASC") ? scanEntityList.OrderBy(x => x.CCOPR).ToList() : scanEntityList.OrderByDescending(x => x.CCOPR).ToList();
                    break;
                case "DateofActionOPR":
                    gvYearlyPendingReport.DataSource = (sortDirection == "ASC") ? scanEntityList.OrderBy(x => x.DateofActionOPR).ToList() : scanEntityList.OrderByDescending(x => x.DateofActionOPR).ToList();
                    break;
            }
            gvYearlyPendingReport.DataBind();
        }

        protected void gvYearlyPendingReport_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);

        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            ClearSearchFields();
            //ViewState["pageindex"] = 1;
            //String pageInfo = ViewState["Prev"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //GetYearlyReport("prev");
            gvYearlyPendingReport.DataSource = GetYearlyReport(null);
            gvYearlyPendingReport.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            ClearSearchFields();
            //ViewState["pageindex"] = 1;
            //String pageInfo = ViewState["Next"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //GetYearlyReport("next");
            gvYearlyPendingReport.DataSource = GetYearlyReport(null);
            gvYearlyPendingReport.DataBind();
        }
    }
}

