﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_OPRForm.Utility;

namespace Medicaid_OPRForm.HPE_Search
{
    [ToolboxItemAttribute(false)]
    public partial class HPE_Search : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public HPE_Search()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        String siteUrl = SPContext.Current.Site.Url + "/director/";
        Int32 pageIndex = 0; //PageIndex
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        List<DXCSearchEntity> searchEntity = new List<DXCSearchEntity>();
        DateTime tempDate;
        DateTime tempDate1;
        DateTime tempDate2;

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public List<DXCSearchEntity> GetHPEListData(String paging) //Get Date specific List data 
        {
            bool isDueDateValid = (txtDateReceived.Text == "Date Received" || txtDateReceived.Text.Length == 0) ? true : DateTime.TryParse(txtDateReceived.Text, out tempDate);
            bool isDueDateValid1 = (txtDateRangeFrom.Text == "Date Range From" || txtDateRangeFrom.Text.Length == 0) ? true : DateTime.TryParse(txtDateRangeFrom.Text, out tempDate1);
            bool isDueDateValid2 = (txtDateRangeTo.Text == "Date Range To" || txtDateRangeTo.Text.Length == 0) ? true : DateTime.TryParse(txtDateRangeTo.Text, out tempDate2);
            if (isDueDateValid && isDueDateValid1 && isDueDateValid2)
            {
                try
                {
                    String loginName = String.Empty;
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);

                    pageIndex = 0;  //Page Index
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            lblErrorMsg.Text = String.Empty;
                            //ViewState["HPETable"] = null;
                            SPList scanList = currentWeb.Lists["HPE"];
                            //scanList.EnableThrottling = false; //Query Throttle to false
                            List<string> objColumns = new List<string>();

                            //itemCount = scanList.Items.Count;   //ItemCount
                            //totalPages = itemCount / Convert.ToInt32(ddlRowCount.SelectedValue); //Total Pages
                            // here, format is like: "Column name(internal name of column);Column type; Conditional operator; Search string (input by user)

                            SPQuery query = new SPQuery();
                            //query.QueryThrottleMode = SPQueryThrottleOption.Override; //List Threshlod Limit
                            //query.RowLimit = Convert.ToUInt32(dropdownPageSize); //Row Limit

                            if (txtEDS_Number.Text != "DXC Number" && txtEDS_Number.Text.Length > 0)
                            {
                                objColumns.Add("EDS_Number;Text;Contains;" + txtEDS_Number.Text.Trim());
                            }
                            if (txtSubject_HPE.Text != "Subject" && txtSubject_HPE.Text.Length > 0)
                            {
                                objColumns.Add("Subject_HPE;Text;Contains;" + txtSubject_HPE.Text.Trim());
                            }
                            if (txtOPR_Number.Text != "OPR Number" && txtOPR_Number.Text.Length > 0)
                            {
                                objColumns.Add("OPR_Number;Text;Contains;" + txtOPR_Number.Text.Trim());
                            }
                            if (txtDateReceived.Text != "Date Received" && txtDateReceived.Text.Length > 0)
                            {
                                objColumns.Add("DateReceived;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateReceived.Text)));
                            }
                            if (txtAuthor_HPE.Text != "Author" && txtAuthor_HPE.Text.Length > 0)
                            {
                                objColumns.Add("Author_HPE;Text;Contains;" + txtAuthor_HPE.Text.Trim());
                            }
                            if (txtDateRangeFrom.Text != "Date Range From" && txtDateRangeFrom.Text.Length > 0)
                            {
                                objColumns.Add("DateReceived;DateTime;Geq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateRangeFrom.Text)));
                            }
                            if (txtDateRangeTo.Text != "Date Range To" && txtDateRangeTo.Text.Length > 0)
                            {
                                objColumns.Add("DateReceived;DateTime;Leq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateRangeTo.Text)));
                            }

                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='DateReceived' Ascending='FALSE'/></OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                       "<FieldRef Name='EDS_Number' />",
                                       "<FieldRef Name='Subject_HPE' />",
                                       "<FieldRef Name='Author_HPE' />",
                                       "<FieldRef Name='DateReceived' />",
                                       "<FieldRef Name='OPR_Number' />",
                                       "<FieldRef Name='Created' />",
                                       "<FieldRef Name='ID' />");
                            query.ViewFieldsOnly = true;

                            //if (itemPoistion != null) //Item Position
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}

                            SPListItemCollection listColl = scanList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (listColl != null && listColl.Count > 0)
                            {
                                //DataTable PrivacyTable = listColl.GetDataTable();
                                //DataView PrivacyView = PrivacyTable.DefaultView;
                                //PrivacyView.Sort = "Created DESC";  //Display Grid Records in Descending Order
                                //ViewState["PrivacyTable"] = PrivacyView.ToTable();
                                //gvPrivacySearch.DataSource = ViewState["PrivacyTable"];
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                //lblRecordCount.Text = Convert.ToString(scanListCollection.Count());

                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new DXCSearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        EDS_Number = Convert.ToString(item["EDS_Number"]),
                                        Subject_HPE = Convert.ToString(item["Subject_HPE"]),
                                        DateReceived = Convert.ToDateTime(item["DateReceived"]),
                                        Author_HPE = Convert.ToString(item["Author_HPE"]),
                                        OPR_Number = Convert.ToString(item["OPR_Number"]),
                                        Created = Convert.ToDateTime(item["Created"])
                                    });
                                }
                            }
                            else
                            {
                                gvHPESearch.DataSource = null;
                                gvHPESearch.DataBind();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }

        public void ClearSearchFields()
        {
            if (txtEDS_Number.Text == "DXC Number")
            {
                txtEDS_Number.Text = "";
            }
            if (txtSubject_HPE.Text == "Subject")
            {
                txtSubject_HPE.Text = "";
            }
            if (txtOPR_Number.Text == "OPR Number")
            {
                txtOPR_Number.Text = "";
            }
            if (txtDateReceived.Text == "Date Received")
            {
                txtDateReceived.Text = "";
            }
            if (txtAuthor_HPE.Text == "Author")
            {
                txtAuthor_HPE.Text = "";
            }
            if (txtDateRangeFrom.Text == "Date Range From")
            {
                txtDateRangeFrom.Text = "";
            }
            if (txtDateRangeTo.Text == "Date Range To")
            {
                txtDateRangeTo.Text = "";
            }
           
        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>");
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void gvHPESearch_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            //ClearSearchFields();
            //gvHPESearch.PageIndex = e.NewPageIndex;
            //GetHPEListData();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtEDS_Number.Text = "DXC Number";
            txtSubject_HPE.Text = "Subject";
            txtOPR_Number.Text = "OPR Number";
            txtDateReceived.Text = "Date Received";
            txtAuthor_HPE.Text = "Author";
            txtDateRangeFrom.Text = "Date Range From";
            txtDateRangeTo.Text = "Date Range To";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/SitePages/DXC%20Search.aspx");
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            ClearSearchFields();
            gvHPESearch.DataSource = GetHPEListData(null);
            gvHPESearch.DataBind();
        }

        protected void gvHPESearch_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvHPESearch.DataSource = GetHPEListData(null);
            gvHPESearch.DataBind();
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            gvHPESearch.DataSource = GetHPEListData("prev");
            gvHPESearch.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            gvHPESearch.DataSource = GetHPEListData("next");
            gvHPESearch.DataBind();
        }

        public void SortColumn(String sortExpression)
        {
            List<DXCSearchEntity> DXCSearchEntityList = GetHPEListData(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "EDS_Number":
                    gvHPESearch.DataSource = (sortDirection == "ASC") ? DXCSearchEntityList.OrderBy(x => x.EDS_Number).ToList() : DXCSearchEntityList.OrderByDescending(x => x.EDS_Number).ToList();
                    break;
                case "Subject_HPE":
                    gvHPESearch.DataSource = (sortDirection == "ASC") ? DXCSearchEntityList.OrderBy(x => x.Subject_HPE).ToList() : DXCSearchEntityList.OrderByDescending(x => x.Subject_HPE).ToList();
                    break;
                case "Author_HPE":
                    gvHPESearch.DataSource = (sortDirection == "ASC") ? DXCSearchEntityList.OrderBy(x => x.Author_HPE).ToList() : DXCSearchEntityList.OrderByDescending(x => x.Author_HPE).ToList();
                    break;
                case "OPR_Number":
                    gvHPESearch.DataSource = (sortDirection == "ASC") ? DXCSearchEntityList.OrderBy(x => x.OPR_Number).ToList() : DXCSearchEntityList.OrderByDescending(x => x.OPR_Number).ToList();
                    break;
                case "DateReceived":
                    gvHPESearch.DataSource = (sortDirection == "ASC") ? DXCSearchEntityList.OrderBy(x => x.DateReceived).ToList() : DXCSearchEntityList.OrderByDescending(x => x.DateReceived).ToList();
                    break;
            }
            gvHPESearch.DataBind();
        } 
    }
}
