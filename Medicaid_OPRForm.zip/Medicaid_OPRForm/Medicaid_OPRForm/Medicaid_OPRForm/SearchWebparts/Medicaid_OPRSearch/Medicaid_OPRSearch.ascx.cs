﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_OPRForm.Utility;

namespace Medicaid_OPRForm.Medicaid_OPRSearch
{
    [ToolboxItemAttribute(false)]
    public partial class Medicaid_OPRSearch : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public Medicaid_OPRSearch()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        Int32 pageIndex = 0;    //Page Index
         Int32 itemCount = 0;
         Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        List<OPRSearchEntity> searchEntity = new List<OPRSearchEntity>();
        DateTime tempDate;
        DateTime tempDate1;
        DateTime tempDate2;
        DateTime tempDate3;
        DateTime tempDate4;

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public List<OPRSearchEntity> GetScanListData(String paging) //Get Date specific List data 
        {
            bool isDueDateValid = (txtOPRDate.Text == "OPR Date" || txtOPRDate.Text.Length == 0) ? true : DateTime.TryParse(txtOPRDate.Text, out tempDate);
            bool isDueDateValid1 = (txtDateRangeFrom.Text == "Date Range From" || txtDateRangeFrom.Text.Length == 0) ? true : DateTime.TryParse(txtDateRangeFrom.Text, out tempDate1);
            bool isDueDateValid2 = (txtDateRangeTo.Text == "Date Range To" || txtDateRangeTo.Text.Length == 0) ? true : DateTime.TryParse(txtDateRangeTo.Text, out tempDate2);
            bool isDueDateValid3 = (txtDateofActionOPR.Text == "Date of Action" || txtDateofActionOPR.Text.Length == 0) ? true : DateTime.TryParse(txtDateofActionOPR.Text, out tempDate3);
            bool isDueDateValid4 = (txtExpectedCompletedDate.Text == "Expected Completion Date" || txtExpectedCompletedDate.Text.Length == 0) ? true : DateTime.TryParse(txtExpectedCompletedDate.Text, out tempDate4);
            if (isDueDateValid && isDueDateValid1 && isDueDateValid2 && isDueDateValid3 && isDueDateValid4)
            {
                try
                {
                    String loginName = String.Empty;
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);

                    pageIndex = 0;
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            //ViewState["OPRTable"] = null;
                            SPList scanList = currentWeb.Lists["Scan List"];

                            List<string> objColumns = new List<string>();

                            //itemCount = scanList.ItemCount;
                            //totalPages = itemCount / Convert.ToInt32(ddlRowCount.SelectedValue);

                            SPQuery query = new SPQuery();
                            //query.QueryThrottleMode = SPQueryThrottleOption.Override; //List Threshlod Limit
                            //query.RowLimit = Convert.ToUInt32(dropdownPageSize); //Row Limit

                            //if (txtOPRNumber.Text != "OPR Number" && txtOPRNumber.Text.Length > 0)
                            //{
                            //    objColumns.Add("OPR_Test;Text;Contains;" + txtOPRNumber.Text.Trim());
                            //}

                            if (txtOPRDate.Text != "OPR Date" && txtOPRDate.Text.Length > 0)
                            {
                                objColumns.Add("OPR_Date;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtOPRDate.Text)));
                            }
                            if (txtOPRNumber.Text != "OPR Number" && txtOPRNumber.Text.Length > 0)
                            {
                                objColumns.Add("OPR_Test;Text;Contains;" + txtOPRNumber.Text.Trim());
                            }
                            if (txtOPRSubject.Text != "Subject1" && txtOPRSubject.Text.Length > 0)
                            {
                                objColumns.Add("OPRSubject;Text;Contains;" + txtOPRSubject.Text.Trim());
                            }
                            if (txtOPRMessage.Text != "Subject2" && txtOPRMessage.Text.Length > 0)
                            {
                                objColumns.Add("OPRMessage;Text;Contains;" + txtOPRMessage.Text.Trim());
                            }
                            if (txtOPRType.Text != "OPR Type" && txtOPRType.Text.Length > 0)
                            {
                                objColumns.Add("OPRType;Text;Contains;" + txtOPRType.Text.Trim());
                            }
                            if (txtDateofActionOPR.Text != "Date of Action" && txtDateofActionOPR.Text.Length > 0)
                            {
                                objColumns.Add("DateofActionOPR;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateofActionOPR.Text)));
                            }
                            if (txtOPRStatus.Text != "OPR Status" && txtOPRStatus.Text.Length > 0)
                            {
                                objColumns.Add("OPRStatus;Text;Contains;" + txtOPRStatus.Text.Trim());
                            }
                            if (txtHPNumber.Text != "DXC Number" && txtHPNumber.Text.Length > 0)
                            {
                                objColumns.Add("HP_OPR;Text;Contains;" + txtHPNumber.Text.Trim());
                            }
                            if (txtOriginator.Text != "Originator" && txtOriginator.Text.Length > 0)
                            {
                                objColumns.Add("CCOPR;Text;Contains;" + txtOriginator.Text.Trim());
                            }
                            //new
                            if (txtExpectedCompletedDate.Text != "Expected Completion Date" && txtExpectedCompletedDate.Text.Length > 0)
                            {
                                //objColumns.Add("ExpectedCompletedDate;Text;Contains;" + txtExpectedCompletedDate.Text.Trim());
                                objColumns.Add("ExpectedCompletedDate;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtExpectedCompletedDate.Text)));
                            }
                            if (txtCSRNumber.Text != "CSR Number" && txtCSRNumber.Text.Length > 0)
                            {
                                objColumns.Add("CSRNumber;Text;Contains;" + txtCSRNumber.Text.Trim());
                            }
                            if (txtITBNumber.Text != "ITB Number" && txtITBNumber.Text.Length > 0)
                            {
                                objColumns.Add("ITBNumber;Text;Contains;" + txtITBNumber.Text.Trim());
                            }
                            if (txtOPRSubType.Text != "OPR SubType" && txtOPRSubType.Text.Length > 0)
                            {
                                objColumns.Add("OPRSubType;Text;Contains;" + txtOPRSubType.Text.Trim());
                            }
                            if (txtDateRangeFrom.Text != "Date Range From" && txtDateRangeFrom.Text.Length > 0)
                            {
                                objColumns.Add("Created;DateTime;Geq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateRangeFrom.Text)));
                            }
                            if (txtDateRangeTo.Text != "Date Range To" && txtDateRangeTo.Text.Length > 0)
                            {
                                objColumns.Add("Created;DateTime;Leq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateRangeTo.Text)));
                            }

                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                       "<FieldRef Name='OPR_Test' />",
                                       "<FieldRef Name='AuthorOPR' />",
                                       "<FieldRef Name='CCOPR' />",
                                       "<FieldRef Name='CC_OPR' />",
                                       "<FieldRef Name='OPRType' />",
                                       "<FieldRef Name='OPR_Date' />",
                                       "<FieldRef Name='OPRSubject' />",
                                       "<FieldRef Name='OPRMessage' />",
                                       "<FieldRef Name='ExpectedCompletedDate' />",
                                       "<FieldRef Name='CSRNumber' />",
                                       "<FieldRef Name='ITBNumber' />",
                                       "<FieldRef Name='HP_OPR' />",
                                       "<FieldRef Name='OPRStatus' />",
                                       "<FieldRef Name='Created' />",
                                       "<FieldRef Name='ID' />",
                                       "<FieldRef Name='OPRSubType' />");
                            query.ViewFieldsOnly = true;

                            //if (itemPoistion != null)
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}
                            SPListItemCollection listColl = scanList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (listColl != null && scanListCount > 0)
                            {
                                //DataTable OPRTable = listColl.GetDataTable();
                                //DataView OPRView = OPRTable.DefaultView;
                                //ViewState["OPRTable"] = OPRView.ToTable();
                                //itemPoistion = listColl.ListItemCollectionPosition; //Item Position
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                //lblRecordCount.Text = Convert.ToString(scanListCollection.Count());

                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new OPRSearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        OPR_Test = Convert.ToString(item["OPR_Test"]),
                                        AuthorOPR = Convert.ToString(item["AuthorOPR"]),
                                        CCOPR = Convert.ToString(item["CCOPR"]),
                                        CC_OPR = Convert.ToString(item["CC_OPR"]),
                                        OPRType = Convert.ToString(item["OPRType"]),
                                        OPR_Date = Convert.ToDateTime(item["OPR_Date"]),
                                        OPRSubject = Convert.ToString(item["OPRSubject"]),
                                        OPRMessage = Convert.ToString(item["OPRMessage"]),
                                        ExpectedCompletedDate = Convert.ToDateTime(item["ExpectedCompletedDate"]),
                                        CSRNumber = Convert.ToString(item["CSRNumber"]),
                                        ITBNumber = Convert.ToString(item["ITBNumber"]),
                                        HP_OPR = Convert.ToString(item["HP_OPR"]),
                                        OPRStatus = Convert.ToString(item["OPRStatus"]),
                                        Created = Convert.ToDateTime(item["Created"]),
                                        OPRSubType = Convert.ToString(item["OPRSubType"])
                                    });
                                }
                            }
                            else
                            {
                                gvOPRSearch.DataSource = null;
                                gvOPRSearch.DataBind();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;            
        }

        //public String GetCSRDocumentID(String CSRNumber) //CSRNumber
        //{
        //    using (SPSite site = new SPSite(siteUrl))
        //    {
        //        using (SPWeb currentWeb = site.OpenWeb())
        //        {
        //            String CSRReqFileID = String.Empty;
        //            SPList HPEList = currentWeb.Lists["CSRRequests"];
        //            SPQuery camlQuery = new SPQuery();
        //            camlQuery.Query = "<Where>" +
        //                                 "<Eq>" +
        //                                    "<FieldRef Name='CSRNumber'/>" +   //OPR_Number is the new column in 'Scan OPR'
        //                                    "<Value Type='Text'>" + CSRNumber + "</Value>" +
        //                                  "</Eq>" +
        //                              "</Where>";
        //            SPListItemCollection itemColl = HPEList.GetItems(camlQuery);

        //            if (itemColl != null && itemColl.Count > 0)
        //            {
        //                CSRReqFileID = Convert.ToString(itemColl[0]["CSRReqFile"]);
        //            }
        //            return CSRReqFileID;
        //        }
        //    }
        //}

        //public DateTime GetExpectedCompletedDate(String ExpectedCompletedDate)
        //{
        //    DateTime CompletedDate = default(DateTime);
        //    if (!String.IsNullOrEmpty(ExpectedCompletedDate))
        //    {
        //        CompletedDate = Convert.ToDateTime(ExpectedCompletedDate);
        //    }
        //             return CompletedDate;
        //}

        public void ClearSearchFields()
        {
            if (txtOPRDate.Text == "OPR Date")
            {
                txtOPRDate.Text = "";
            }
            if (txtOPRNumber.Text == "OPR Number")
            {
                txtOPRNumber.Text = "";
            }
            if (txtOPRSubject.Text == "Subject1")
            {
                txtOPRSubject.Text = "";
            }
            if (txtOPRMessage.Text == "Subject2")
            {
                txtOPRMessage.Text = "";
            }
            if (txtOPRType.Text == "OPR Type")
            {
                txtOPRType.Text = "";
            }
            if (txtDateofActionOPR.Text == "Date of Action")
            {
                txtDateofActionOPR.Text = "";
            }
            if (txtOPRStatus.Text == "OPR Status")
            {
                txtOPRStatus.Text = "";
            }
            if (txtHPNumber.Text == "DXC Number")
            {
                txtHPNumber.Text = "";
            }
            if (txtOriginator.Text == "Originator")
            {
                txtOriginator.Text = "";
            }
            if (txtExpectedCompletedDate.Text == "Expected Completetion Date")
            {
                txtExpectedCompletedDate.Text = "";
            }
            if (txtCSRNumber.Text == "CSR Number")
            {
                txtCSRNumber.Text = "";
            }
            if (txtITBNumber.Text == "ITB Number")
            {
                txtITBNumber.Text = "";
            }
            if (txtOPRSubType.Text == "OPR SubType")
            {
                txtOPRSubType.Text = "";
            }
            if (txtDateRangeFrom.Text == "Date Range From")
            {
                txtDateRangeFrom.Text = "";
            }
            if (txtDateRangeTo.Text == "Date Range To")
            {
                txtDateRangeTo.Text = "";
            }
        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>"); //Ascending to FALSE
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            ClearSearchFields();
            //GetScanListData(null,null);
            gvOPRSearch.DataSource = GetScanListData(null);
            gvOPRSearch.DataBind();
        }

        protected void gvOPRSearch_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            //ClearSearchFields();
            //gvOPRSearch.PageIndex = e.NewPageIndex;
            //GetScanListData();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtOPRDate.Text = "OPR Date";
            txtOPRNumber.Text = "OPR Number";
            txtOPRSubject.Text = "Subject1";
            txtOPRMessage.Text = "Subject2";
            txtOPRType.Text = "OPR Type";
            txtDateofActionOPR.Text = "Date of Action";
            txtOPRStatus.Text = "OPR Status";
            txtHPNumber.Text = "DXC Number";
            txtOriginator.Text = "Originator";
            txtExpectedCompletedDate.Text = "Expected Completion Date";
            txtCSRNumber.Text = "CSR Number";
            txtITBNumber.Text = "ITB Number";
            txtOPRSubType.Text = "OPR SubType";
            txtDateRangeFrom.Text = "Date Range From";
            txtDateRangeTo.Text = "Date Range To";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/SitePages/OPR%20Search.aspx");
        }

        protected void gvOPRSearch_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
            //if (ViewState["OPRTable"] != null)
            //{
            //    DataTable dt = ViewState["OPRTable"] as DataTable;

            //    if (dt != null)
            //    {
            //        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
            //        gvOPRSearch.DataSource = ViewState["OPRTable"];
            //        gvOPRSearch.DataBind();
            //    }
            //}
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ClearSearchFields();
            
            //GetScanListData(null, null);

            gvOPRSearch.DataSource = GetScanListData(null);
            gvOPRSearch.DataBind();
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            gvOPRSearch.DataSource = GetScanListData("prev");
            gvOPRSearch.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            gvOPRSearch.DataSource = GetScanListData("next");
            gvOPRSearch.DataBind();
        }

        public string ProcessDateTime(object value) //Used to show proper Date for Expected completed date
        {
            if (Convert.ToString(value) == "1/1/0001")
            {
                value = String.Empty;
            }

            return Convert.ToString(value);
        }
        public void SortColumn(String sortExpression)
        {
            List<OPRSearchEntity> OPRSearchEntityList = GetScanListData(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "OPR_Test":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPR_Test).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPR_Test).ToList();
                    break;
                case "OPRSubject":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPRSubject).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPRSubject).ToList();
                    break;
                case "OPRMessage":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPRMessage).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPRMessage).ToList();
                    break;
                case "CCOPR":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.CCOPR).ToList() : OPRSearchEntityList.OrderByDescending(x => x.CCOPR).ToList();
                    break;
                case "CC_OPR":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.CCOPR).ToList() : OPRSearchEntityList.OrderByDescending(x => x.CC_OPR).ToList();
                    break;
                case "OPR_Date":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPR_Date).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPR_Date).ToList();
                    break;
                case "OPRType":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPRType).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPRType).ToList();
                    break;
                case "OPRStatus":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPRStatus).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPRStatus).ToList();
                    break;
                case "HP_OPR":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.HP_OPR).ToList() : OPRSearchEntityList.OrderByDescending(x => x.HP_OPR).ToList();
                    break;
                case "ExpectedCompletedDate":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.ExpectedCompletedDate).ToList() : OPRSearchEntityList.OrderByDescending(x => x.ExpectedCompletedDate).ToList();
                    break;
                case "CSRNumber":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.CSRNumber).ToList() : OPRSearchEntityList.OrderByDescending(x => x.CSRNumber).ToList();
                    break;
                case "ITBNumber":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.ITBNumber).ToList() : OPRSearchEntityList.OrderByDescending(x => x.ITBNumber).ToList();
                    break;
                case "OPRSubType":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.OPRSubType).ToList() : OPRSearchEntityList.OrderByDescending(x => x.OPRSubType).ToList();
                    break;
                case "AuthorOPR":
                    gvOPRSearch.DataSource = (sortDirection == "ASC") ? OPRSearchEntityList.OrderBy(x => x.AuthorOPR).ToList() : OPRSearchEntityList.OrderByDescending(x => x.AuthorOPR).ToList();
                    break;
            }
            gvOPRSearch.DataBind();
        } 

        //protected void gvOPRSearch_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        System.Data.DataRowView rowView = e.Row.DataItem as System.Data.DataRowView;
        //        String HPENumber = Convert.ToString(rowView["HP_OPR"]);
        //        String HPEID = "";
        //        using (SPSite site = new SPSite(siteUrl))
        //        {
        //            using (SPWeb currentWeb = site.OpenWeb())
        //            {
        //                SPList HPEList = currentWeb.Lists["HPE"];
        //                SPQuery camlQuery = new SPQuery();
        //                camlQuery.Query = "<Where>" +
        //                                     "<Eq>" +
        //                                        "<FieldRef Name='EDS_Number'/>" +   //OPR_Number is the new column in 'Scan OPR'
        //                                        "<Value Type='Text'>" + HPENumber + "</Value>" +
        //                                      "</Eq>" +
        //                                  "</Where>";
        //                SPListItemCollection itemColl = HPEList.GetItems(camlQuery);
        //                HPEID = Convert.ToString(itemColl[0]["ID"]);
        //            }
        //        }
        //        HyperLink hlnkHPENumber = (HyperLink)e.Row.FindControl("hlnkHPENumber");
        //        hlnkHPENumber.NavigateUrl = String.Format("/teams/FiscalAgent/director/Lists/HPE/Attachments/{0}/{1}.pdf", HPEID, HPENumber);
        //    }
        //}

    }
}
