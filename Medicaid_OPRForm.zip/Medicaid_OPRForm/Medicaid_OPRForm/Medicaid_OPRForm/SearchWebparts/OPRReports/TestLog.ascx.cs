﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using System.Data;
using System.IO;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using System.Web;
using System.Linq;

namespace Medicaid_OPRForm.SearchWebparts.OPRReports
{
    [ToolboxItemAttribute(false)]
    public partial class TestLog : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public TestLog()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        String strQuery = String.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            GetOPRReports(DateTime.Now, DateTime.Now.AddDays(5));
        }
        public void GetOPRReports(DateTime currentDate, DateTime requestedDate) //Get Date specific List data 
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList OPRList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        strQuery = "<Where>" +
                                    "<And>" +
                                        "<And>" +
                                            "<Geq>" +
                                                 "<FieldRef Name='DateofActionOPR'/>" +
                                                 "<Value Type='DateTime' IncludeTimeValue='Flase'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(currentDate.Date) + "</Value>" +
                                            "</Geq>" +
                                            "<Leq>" +
                                                 "<FieldRef Name='DateofActionOPR'/>" +
                                                 "<Value Type='DateTime' IncludeTimeValue='Flase'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(requestedDate.Date) + "</Value>" +
                                            "</Leq>" +
                                        "</And>" +
                                        "<Eq>" +
                                             "<FieldRef Name='OPRStatus'/>" +
                                             "<Value Type='Text' >Pending</Value>" +
                                        "</Eq>" +
                                     "</And>" +
                                    "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='OPRType' Ascending='TRUE'/>" +
                                         "</OrderBy>";
                        query.RowLimit = 20;
                        query.ViewFields = string.Concat(
                                    "<FieldRef Name='ID' />",
                                    "<FieldRef Name='OPR_Test' />",
                                    "<FieldRef Name='AuthorOPR' />",
                                    "<FieldRef Name='OPRType' />",
                                    "<FieldRef Name='DateofActionOPR' />",
                                    "<FieldRef Name='OPRSubject' />",
                                     "<FieldRef Name='OPRStatus' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        SPListItemCollection listColl = OPRList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DataTable dtHPE = listColl.GetDataTable();
                            gvOPRReports.DataSource = dtHPE;
                            gvOPRReports.DataBind();
                            ViewState["HPEntryDetails"] = dtHPE;
                        }
                        else
                        {
                            DataTable dt = new DataTable();
                            gvOPRReports.DataSource = dt;
                            gvOPRReports.DataBind();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            //CreateDocument("sample123.docx");
            GeneratePDF();
        }

        public void CreateDocument(String docName)
        {
            using (MemoryStream mem = new MemoryStream())
            {
                //Create Document
                using (WordprocessingDocument wordDocument =
                    WordprocessingDocument.Create(mem, WordprocessingDocumentType.Document, true))
                {
                    //Add a main document part. 
                    MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();

                    //Create the document structure and add some text.
                    mainPart.Document = new Document();
                    Body body = mainPart.Document.AppendChild(new Body());

                    // Create a new table
                    Table tbl = new Table();

                    // Create a new row
                    TableRow tr = new TableRow();
                    // Add a cell to each column in the row
                    TableCell tcName1 = new TableCell(new Paragraph(new Run(new Text("DocNumber"))));
                    TableCell tcId = new TableCell(new Paragraph(new Run(new Text("1"))));
                    TableCell tcId1 = new TableCell(new Paragraph(new Run(new Text("2"))));
                    // Add the cells to the row
                    tr.Append(tcName1, tcId, tcId1);
                    //Create a new row
                    TableRow tr1 = new TableRow();
                    TableCell tcName2 = new TableCell(new Paragraph(new Run(new Text("Subject"))));
                    TableCell tcId2 = new TableCell(new Paragraph(new Run(new Text("2"))));
                    TableCell tcId3 = new TableCell(new Paragraph(new Run(new Text("3"))));
                    // Add the cells to the row
                    tr1.Append(tcName2, tcId2, tcId3);
                    // Add the rows to the table
                    tbl.AppendChild(tr);
                    tbl.AppendChild(tr1);

                    // Add the table to the body
                    body.AppendChild(tbl);

                    Paragraph para = body.AppendChild(new Paragraph());
                    Run run = para.AppendChild(new Run());
                    //run.AppendChild(new Text("Hello world!"));
                    mainPart.Document.Save();
                    //System.IO.File.WriteAllBytes(@"C:\Users\txrapaka\Desktop\test3.docx", mem.ToArray());
                }
                //AddToSharePoint(mem, docName);
                System.IO.File.WriteAllBytes(@"C:\Test\test01.docx", mem.ToArray());
                
            }
        }

        //public void CreateDocument(string docName)
        //{
        //    using (MemoryStream memStream = new MemoryStream())
        //    {
        //        using (WordprocessingDocument doc = WordprocessingDocument.Create(memStream, WordprocessingDocumentType.Document))
        //        {
        //            doc.AddMainDocumentPart();
        //            doc.MainDocumentPart.Document =
        //            new Document(new Body(new Paragraph(new Run(
        //            new Text("Its a new Document")))));

        //            // Save changes to the main document part.
        //            doc.MainDocumentPart.Document.Save();

        //            //System.IO.File.WriteAllBytes(@"C:\Users\txrapaka\Desktop\test1.docx", memStream.ToArray());
        //            //Adding Document to SharePoint.
        //            AddToSharePoint(memStream, docName);
        //        }
        //    }
        //}

        protected void AddToSharePoint(MemoryStream memoryStream, string fileName)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList docLib = currentWeb.Lists["Documents"];
                    SPFile file = docLib.RootFolder.Files.Add(fileName, memoryStream.ToArray(), true);
                    file.Update();
                }
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtRequestedDate.Text = String.Empty;
        }

        public DataRow[] GetDailyLogSheet() //Get Date specific List data 
        {

            DataRow[] dataRows = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        //SPWebApplication webApp = this.Parent as SPWebApplication;
                        //SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
                        SPList scanList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        DateTime table = DateTime.Now;
                        int hour = DateTime.Now.Hour;
                        bool isTime = hour < 14;

                        query.DatesInUtc = false;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null)
                        {
                            dataRows = listColl.GetDataTable().Select();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataRows;
        }

        public void GeneratePDF()
        {
            try
            {

                DataRow[] logSheetArray = GetDailyLogSheet();
                String dateOfAction = String.Empty;
                String fromDate = DateTime.Now.Date.AddDays(-1).ToShortDateString();
                String toDate = DateTime.Now.Date.ToShortDateString();
                TimeSpan timespan = DateTime.Now.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
                if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                {
                    fromDate = DateTime.Now.Date.ToShortDateString();
                    toDate = DateTime.Now.Date.AddDays(1).ToShortDateString();
                }
                //var SacnListColl = logSheetArray.Where(s => Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();
                //var SacnListColl = logSheetArray.ToList();
                var SacnListColl = logSheetArray.Where(s => (Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved"
                                                && Convert.ToDateTime(s["Modified"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Modified"]) <= DateTime.Parse(toDate + " 14:30:00"))
                                                || (Convert.ToString(s["OPRStatus"]) != "Pending" && Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00"))).ToList();

                if (SacnListColl.Count > 0)
                {
                    using (MemoryStream mem = new MemoryStream())
                    {
                        using (WordprocessingDocument wordDocument =
                            WordprocessingDocument.Create(mem, WordprocessingDocumentType.Document, true))
                        {
                            MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();

                            mainPart.Document = new Document();
                            Body body = mainPart.Document.AppendChild(new Body());

                            Table tblLogSheet = new Table();

                            TableRow trHeader = new TableRow();
                            TableCell tcDocNumber = new TableCell(new Paragraph(new Run(new Text("Doc Number"))));
                            tcDocNumber.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));

                            TableCell tcAuthor = new TableCell(new Paragraph(new Run(new Text("Author"))));
                            tcAuthor.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            TableCell tcSubject = new TableCell(new Paragraph(new Run(new Text("Subject"))));
                            tcSubject.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            TableCell tcHP = new TableCell(new Paragraph(new Run(new Text("DXC"))));
                            tcHP.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            TableCell tcAction = new TableCell(new Paragraph(new Run(new Text("Action"))));
                            tcAction.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            TableCell tcCompleted = new TableCell(new Paragraph(new Run(new Text("Completed"))));
                            tcCompleted.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            TableCell tcPickUp = new TableCell(new Paragraph(new Run(new Text("Pick Up"))));
                            tcPickUp.Append(new TableCellProperties(
                            new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));

                            trHeader.Append(tcDocNumber, tcAuthor, tcSubject, tcHP, tcAction, tcCompleted, tcPickUp);
                            tblLogSheet.AppendChild(trHeader);

                            foreach (var item in SacnListColl)
                            {
                                TableRow trRow = new TableRow();

                                TableCell tcRowDocNumber = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPR_Test"])))));
                                TableCell tcRowAuthor = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["AuthorOPR"])))));
                                TableCell tcRowSubject = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPRType"]) + "\r\n" + Convert.ToString(item["OPRSubject"])))));
                                //TableCell tcRowSubject = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPRSubject"])))));
                                TableCell tcRowHP = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["HP_OPR"])))));
                                TableCell tcRowCompleted = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPRStatus"])))));
                                TableCell tcRowPickUp = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["PickUp"])))));

                                if (Convert.ToString(item["SeeMemo"]) == "1" || Convert.ToString(item["FinancialSeeMemo"]) == "See Memo")
                                {
                                    dateOfAction = "See Memo";
                                }
                                else if (String.IsNullOrEmpty(Convert.ToString(item["DateofActionOPR"])))
                                {
                                    dateOfAction = "";
                                }
                                else if (String.IsNullOrEmpty(Convert.ToString(item["FinancialOPR"])))
                                {
                                    dateOfAction = Convert.ToDateTime(item["DateofActionOPR"]).ToShortDateString();
                                }
                                else
                                {
                                    dateOfAction = Convert.ToDateTime(item["FinancialOPR"]).ToShortDateString();
                                }
                                TableCell tcRowAction = new TableCell(new Paragraph(new Run(new Text(dateOfAction))));
                                trRow.Append(tcRowDocNumber, tcRowAuthor, tcRowSubject, tcRowHP, tcRowAction, tcRowCompleted, tcRowPickUp);
                                tblLogSheet.AppendChild(trRow);
                            }
                            body.AppendChild(tblLogSheet);
                            mainPart.Document.Save();
                            //String fileName = DateTime.Now.ToString("dd-MM-yyyy") + ".docx";
                            //// AddToSharePoint(mem, fileName);
                            //System.IO.File.WriteAllBytes(@"C:\Test\test3.docx", mem.ToArray());
                        }
                        String fileName = DateTime.Now.ToString("dd-MM-yyyy") + ".docx";
                        AddToSharePoint(mem, fileName);
                        //System.IO.File.WriteAllBytes(@"C:\Test\test4.docx", mem.ToArray());
                    }
                    
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
