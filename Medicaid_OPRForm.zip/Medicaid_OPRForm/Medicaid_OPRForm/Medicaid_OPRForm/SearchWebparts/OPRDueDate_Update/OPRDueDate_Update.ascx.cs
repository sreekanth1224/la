﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace Medicaid_OPRForm.SearchWebparts.OPRDueDate_Update
{
    [ToolboxItemAttribute(false)]
    public partial class OPRDueDate_Update : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public OPRDueDate_Update()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblSuccessMsg.Text = String.Empty;
            GetOPRSearchResults(txtSearchOPR.Text, txtSearchDate.Text);
        }

        public void GetOPRSearchResults(String searchedOPRNumber, String searchDate)
        {
            String errorMessage = String.Empty;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList OPRList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        String strQuery = String.Empty;
                       
                        DateTime tempDate;
                        bool isDueDateValid = (txtSearchDate.Text == "Enter OPR Date" || txtSearchDate.Text.Length == 0) ? false : DateTime.TryParse(txtSearchDate.Text, out tempDate);
                        bool isOPRNumberValid = (txtSearchOPR.Text == "Enter OPR Number" || txtSearchOPR.Text.Length == 0) ? false : true;
                        if (isOPRNumberValid)
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                            "<Eq>" +
                                                 "<FieldRef Name='OPR_Test'/>" +
                                                 "<Value Type='Text'>" + searchedOPRNumber + "</Value>" +
                                            "</Eq>" +
                                             "<Eq>" +
                                                 "<FieldRef Name='OPRStatus'/>" +
                                                 "<Value Type='Text'>Pending</Value>" +
                                            "</Eq>" +
                                            "</And>" +
                                        "</Where>";
                        }
                        else if (isDueDateValid)
                        {
                            DateTime requestedDate = DateTime.Parse(searchDate);
                            String fromDate = DateTime.Parse(searchDate).AddDays(-1).ToShortDateString();
                            String toDate = requestedDate.Date.ToShortDateString();
                            TimeSpan timespan = requestedDate.Date.Subtract(DateTime.Parse(fromDate + " 14:30:00"));
                            if ((requestedDate.Date == DateTime.Now.Date && requestedDate.Hour == 14 && requestedDate.Minute >= 30) || (requestedDate.Date == DateTime.Now.Date && requestedDate.Hour >= 15))
                            {
                                fromDate = requestedDate.Date.ToShortDateString();
                                toDate = requestedDate.AddDays(1).Date.ToShortDateString();
                            }
                            else if (requestedDate.Date.DayOfWeek == DayOfWeek.Monday)
                            {
                                fromDate = requestedDate.Date.AddDays(-3).ToShortDateString();
                            }

                            strQuery = "<Where>" +
                                               "<And>" +
                                                   "<Contains>" +
                                                        "<FieldRef Name='OPRStatus'/>" +
                                                        "<Value Type='Text'>Pending</Value>" +
                                                   "</Contains>" +
                                                   "<And>" +
                                                   "<Geq>" +
                                                        "<FieldRef Name='Created'/>" +
                                                        "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(fromDate + " 14:30:00")) + "</Value>" +
                                                   "</Geq>" +
                                                    "<Leq>" +
                                                        "<FieldRef Name='Created'/>" +
                                                        "<Value Type='DateTime' IncludeTimeValue='TRUE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.Parse(toDate + " 14:30:00")) + "</Value>" +
                                                   "</Leq>" +
                                                   "</And>" +
                                                "</And>" +
                                       "</Where>";
                        }
                        else
                        {
                            errorMessage = "Please search with OPR Number or Date";
                        }

                        if (String.IsNullOrEmpty(errorMessage))
                        {
                            query.Query = strQuery +
                                             "<OrderBy>" +
                                                "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                             "</OrderBy>";
                            query.ViewFields = string.Concat(
                                        "<FieldRef Name='ID' />",
                                        "<FieldRef Name='OPR_Test' />",
                                        "<FieldRef Name='OPRStatus' />",
                                        "<FieldRef Name='SeeMemo' />",
                                        "<FieldRef Name='FinancialSeeMemo' />",
                                        "<FieldRef Name='DateofActionOPR' />");
                            query.DatesInUtc = false;
                            query.ViewFieldsOnly = true;
                            SPListItemCollection listColl = OPRList.GetItems(query);
                            if (listColl.Count > 0)
                            {
                                lblErrorMsg.Text = String.Empty;
                                DataTable OPRTable = listColl.GetDataTable();
                                gvPendingOPRUpdate.DataSource = OPRTable;
                                gvPendingOPRUpdate.DataBind();
                            }
                            else
                            {
                                lblErrorMsg.Text = "No Record Found";
                            }
                        }
                        else
                        {
                            lblErrorMsg.Text = errorMessage;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnUpdateDate_Click(object sender, EventArgs e)
        {
            Boolean isValid = true;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList OPRList = currentWeb.Lists["Scan List"];

                    foreach (GridViewRow row in gvPendingOPRUpdate.Rows)
                    {
                        Label rowID = (Label)row.FindControl("lblID");
                        TextBox txtDateofAction = (TextBox)row.FindControl("txtDateofAction");
                        if (txtDateofAction.Text.Length > 0)
                        {
                            isValid = false;
                            SPListItem lisItem = OPRList.GetItemById(Convert.ToInt32(rowID.Text));
                            lisItem["DateofActionOPR"] = Convert.ToDateTime(txtDateofAction.Text);
                            lisItem.Update();
                        }
                    }

                    if (isValid)
                    {
                        lblErrorMsg.Text = "Please enter a valid date";
                    }
                    else
                    {
                        lblErrorMsg.Text = String.Empty;
                        lblSuccessMsg.Text = "Date updated successfully.";
                    }
                }
            }
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtSearchDate.Text = "";
            txtSearchOPR.Text = "";
            //gvPendingOPRUpdate
            Page.Response.Redirect(SPContext.Current.Site.Url + "/director/SitePages/Edit%20OPR%20Due%20Date.aspx");

        }

        protected void gvPendingOPRUpdate_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                TextBox txtDateofAction = (TextBox)e.Row.FindControl("txtDateofAction");
                Label lblDateofAction = (Label)e.Row.FindControl("lblDateofAction");
                Label lblSeeMemo = (Label)e.Row.FindControl("lblSeeMemo");
                Label lblFinancialSeeMemo = (Label)e.Row.FindControl("lblFinancialSeeMemo");
                String DateofActionOPR = String.IsNullOrEmpty(lblDateofAction.Text) ? (Convert.ToBoolean(Convert.ToInt32(lblSeeMemo.Text)) || !String.IsNullOrEmpty(lblFinancialSeeMemo.Text) ? "See Memo" : String.Empty) :
                                                           Convert.ToDateTime(lblDateofAction.Text).ToShortDateString();
                lblDateofAction.Text = DateofActionOPR;
                txtDateofAction.Visible = !(lblDateofAction.Text == "See Memo");
            }

        }

        //protected void btnClear_Click1(object sender, EventArgs e)
        //{

        //}

        protected void btnCcancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(SPContext.Current.Site.Url + "/director/SitePages/Edit%20OPR%20Due%20Date.aspx");
        }
    }
}
