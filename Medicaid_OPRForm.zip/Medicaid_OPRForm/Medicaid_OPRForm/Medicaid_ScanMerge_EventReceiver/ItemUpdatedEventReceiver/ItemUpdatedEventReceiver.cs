﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Microsoft.SharePoint.Administration;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using iTextSharp.text.pdf;
using itextSharpText = iTextSharp.text;
using System.Text.RegularExpressions;
using iTextSharp.text;
using System.Net;
using System.Collections;
using System.Net.Mail;

namespace Medicaid_ScanMerge_EventReceiver.ItemUpdatedEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class ItemUpdatedEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            SPSecurity.RunWithElevatedPrivileges(delegate ()
            {
                if (properties.ListTitle == "Scan Merge Doc")
                {
                    try
                    {
                        EventFiringEnabled = false;
                        MergePDFDocuments(properties);
                        EventFiringEnabled = true;
                    }

                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            });
        }

        public void MergePDFDocuments(SPItemEventProperties properties)
        {
            List<String> lstFiles = new List<String>();
            String fileName = String.Empty;
            String fileScanOPRPath = String.Empty;
            String fileScanMergeDocPath = String.Empty;
            String fileUrl = String.Empty;
            String siteUrl = String.Empty;
            //using (SPWeb currentWeb = properties.OpenWeb())
            //{
            //siteUrl = currentWeb.Site.Url + "/director";
            siteUrl = properties.WebUrl;
            fileName = properties.ListItem.File.Name;

            fileScanOPRPath = siteUrl + "/Scan Merge Doc/" + fileName;
            fileScanMergeDocPath = siteUrl + "/Scan OPR/" + fileName;

            lstFiles.Add(fileScanMergeDocPath);
            lstFiles.Add(fileScanOPRPath);

            //Method to merge file fetched from Scan Opr & Scan Merge Doc Document Libraries
            ScanMergeDocuments(lstFiles, fileName, siteUrl);

            //using (SPWeb currentWeb = properties.OpenWeb())
            //{
            //Update Document into Scan OPR library
            //SPList scanOPRLib = currentWeb.Lists["Scan OPR"];
            String outputPdfPath = @"C:/Merge/" + fileName;
            FileStream fs = File.OpenRead(outputPdfPath);
            //Byte[] fileArrayMerge = File.ReadAllBytes(outputPdfPath);
            byte[] fileConetnt = new byte[fs.Length];
            fs.Read(fileConetnt, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            fs.Dispose();
            //SPFile file = currentWeb.Files.Add("Scan OPR/" + fileName, fileConetnt, true);
            //SPWeb web = properties.Web;
            var metaData = new Hashtable { { "fileUpdated", true } };
            SPFile file = properties.Web.Files.Add("Scan OPR/" + fileName, fileConetnt, metaData, true);

            //SPList docLib = currentWeb.Lists["Scan OPR"];
            //SPList docLib = web.Lists["Scan OPR"];
            //SPListItem Updatefileprop = docLib.Items[file.UniqueId];
            //Updatefileprop["fileUpdated"] = true;
            //Updatefileprop.Update();

            ////Delete file from Merge Document Library
            //SPFile fileDelete = currentWeb.GetFile(siteUrl + "/Scan Merge Doc/" + fileName);
            //fileDelete.Delete();


            //}
            //Delete file from Merge Document Library
            properties.ListItem.Delete();
            //Delete Merge folder documents
            String networkFolderPath = @"C:/Merge";
            String[] files = Directory.GetFiles(networkFolderPath);
            foreach (String filePath in files)
            {
                if (filePath.Contains(fileName))
                {
                    File.Delete(filePath);
                }
            }
        }

        public static void ScanMergeDocuments(List<String> lstFiles, String fileName, String siteUrl)
        {
            List<String> emailList = new List<String>();
            string outputPdfPath = @"C:/Merge/" + fileName; //Merge Folder
            using (var fs = new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create))
            {
                using (var sourceDocument = new Document())
                {
                    using (var pdfCopyProvider = new PdfCopy(sourceDocument, fs))
                    {
                        sourceDocument.Open();
                        try
                        {
                            foreach (String file in lstFiles)
                            {
                                using (PdfReader reader = new PdfReader(file))
                                {
                                    pdfCopyProvider.AddDocument(reader);
                                    reader.Close();
                                    reader.Dispose();
                                }
                            }
                            lstFiles.Clear();
                            sourceDocument.Close();
                        }
                        catch (Exception ex)
                        {
                            emailList = GetEmailList(siteUrl);
                            SendEmail(emailList, fileName);
                            throw ex;
                        }
                        finally
                        {
                            //reader.Dispose();
                            sourceDocument.Dispose();
                            pdfCopyProvider.Dispose();
                        }
                    }
                }
            }
        }

        public static List<String> GetEmailList(String siteUrl)
        {
            List<String> emailList = new List<String>();
            String emailAddress = String.Empty;
            using (SPSite currentSite = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = currentSite.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["ScanErrors"];
                    SPQuery camlQuery = new SPQuery();
                    SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);
                    if (itemColl != null && itemColl.Count > 0)
                    {
                        foreach (SPListItem item in itemColl)
                        {
                            emailAddress = Convert.ToString(item["Notification"]);
                            if (!String.IsNullOrEmpty(emailAddress))
                            {
                                emailAddress = emailAddress.Contains('#') ? emailAddress.Split('#')[1] : emailAddress;
                                emailList.Add(emailAddress);
                            }
                        }
                    }
                }
            }
            return emailList;

        }

        public static void SendEmail(List<String> emailToEmailAddress, String fileName)
        {
            try
            {
                String emailBody = String.Empty;
                String smtpServer = SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
                MailMessage mailMessage = new MailMessage();
                emailBody = "<div class='divContainer'>";
                emailBody += "<div><b>The scanned OPR(s) below did not process. Please try again.</b></div><br/>";
                emailBody += "<div>" + fileName + "</div><br/>";
                foreach (String emailAddress in emailToEmailAddress)
                {
                    if (!String.IsNullOrEmpty(emailAddress))
                    {
                        mailMessage.To.Add(new MailAddress(emailAddress));
                    }
                }
                mailMessage.From = new MailAddress("no-reply@medicaid.alabama.gov");
                mailMessage.Subject = "Scanned OPRs - Error";
                mailMessage.Body = emailBody;
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}