﻿namespace MergeEventReceiver.VisualWebPart1
{
    public partial class VisualWebPart1UserControl
    {
    }
}
