﻿//using System;
//using System.Collections.Generic;
using System.Linq;
//using System.Text;
using Microsoft.SharePoint.Administration;
//using Microsoft.SharePoint;
//using System.Collections.Specialized;
//using Microsoft.SharePoint.Utilities;
using System.Net.Mail;
//using System.Data;
//using System.IO;
//using System.Net;
//using DocumentFormat.OpenXml.Wordprocessing;
//using DocumentFormat.OpenXml.Packaging;
//using DocumentFormat.OpenXml;

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Collections;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Utilities;
using System.Data;
using System.IO;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml;
using System.Web;

namespace EmailLogSheetTimerJob
{
    class EmailLogSheet : SPJobDefinition
    {
        public EmailLogSheet() : base() { }

        public EmailLogSheet(SPWebApplication webApp)
            : base("TimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "TimerJob";
        }

        public EmailLogSheet(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public EmailLogSheet(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            GeneratePDF();
        }

        public DataRow[] GetDailyLogSheet() //Get Date specific List data 
        {

            DataRow[] dataRows = null;
            try
            {
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
                SPList scanList = currentWeb.Lists["Scan List"];
                SPQuery query = new SPQuery();
                DateTime table = DateTime.Now;
                int hour = DateTime.Now.Hour;
                bool isTime = hour < 14;

                query.DatesInUtc = false;
                SPListItemCollection listColl = scanList.GetItems(query);
                if (listColl != null)
                {
                    dataRows = listColl.GetDataTable().Select();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataRows;
        }

        public void GeneratePDF()
        {
            try
            {

                DataRow[] logSheetArray = GetDailyLogSheet();
                String dateOfAction = String.Empty;
                String CompletionDate = String.Empty;
                String fromDate = DateTime.Now.Date.AddDays(-1).ToShortDateString();
                String toDate = DateTime.Now.Date.ToShortDateString();
                TimeSpan timespan = DateTime.Now.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
                if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                {
                    fromDate = DateTime.Now.Date.ToShortDateString();
                    toDate = DateTime.Now.Date.AddDays(1).ToShortDateString();
                }
                //var SacnListColl = logSheetArray.Where(s => Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();
                //var SacnListColl = logSheetArray.ToList();
                var SacnListColl = logSheetArray.Where(s => (Convert.ToString(s["OPRStatus"]) == "Pending" && Convert.ToString(s["ApprovalStatus"]) == "Approver Approved"
                                                && Convert.ToDateTime(s["Modified"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Modified"]) <= DateTime.Parse(toDate + " 14:30:00"))
                                                || (Convert.ToString(s["OPRStatus"]) != "Pending" && Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:31:00") && Convert.ToDateTime(s["Created"]) <= DateTime.Parse(toDate + " 14:30:00"))).ToList();

                if (SacnListColl.Count > 0)
                {
                    using (MemoryStream mem = new MemoryStream())
                    {
                        using (WordprocessingDocument wordDocument =
                            WordprocessingDocument.Create(mem, WordprocessingDocumentType.Document, true))
                        {
                            MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();

                            mainPart.Document = new Document();
                            Body body = mainPart.Document.AppendChild(new Body());

                            Table tblLogSheet = new Table();
                           
                            TableRow trHeader = new TableRow();

                            TableProperties tblProperties = new TableProperties();
                            //// Create Table Borders
                            TableBorders tblBorders = new TableBorders();
                            TopBorder topBorder = new TopBorder();
                            topBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            topBorder.Color = "000000";
                            tblBorders.AppendChild(topBorder);
                            BottomBorder bottomBorder = new BottomBorder();
                            bottomBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            bottomBorder.Color = "000000";
                            tblBorders.AppendChild(bottomBorder);
                            RightBorder rightBorder = new RightBorder();
                            rightBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            rightBorder.Color = "000000";
                            tblBorders.AppendChild(rightBorder);
                            LeftBorder leftBorder = new LeftBorder();
                            leftBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            leftBorder.Color = "000000";
                            tblBorders.AppendChild(leftBorder);
                            InsideHorizontalBorder insideHBorder = new InsideHorizontalBorder();
                            insideHBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            insideHBorder.Color = "000000";
                            tblBorders.AppendChild(insideHBorder);
                            InsideVerticalBorder insideVBorder = new InsideVerticalBorder();
                            insideVBorder.Val = new EnumValue<BorderValues>(BorderValues.Thick);
                            insideVBorder.Color = "000000";
                            tblBorders.AppendChild(insideVBorder);
                            //// Add the table borders to the properties
                            tblProperties.AppendChild(tblBorders);
                            //// Add the table properties to the table
                            tblLogSheet.AppendChild(tblProperties);

                            Bold fontbold = new Bold();
                            RunProperties rpDocNumber = new RunProperties();
                            Paragraph paraghDocNumber = new Paragraph();
                            Text headerTextDocNumber = new Text("Doc Number");
                            Run runHeaderRun = new Run();
                            runHeaderRun.Append(rpDocNumber);
                            runHeaderRun.Append(headerTextDocNumber);
                            rpDocNumber.Append(fontbold);
                            paraghDocNumber.Append(runHeaderRun);
                            TableCell tcDocNumber = new TableCell();
                            tcDocNumber.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcDocNumber.Append(paraghDocNumber);
                            
                            Bold fontbold1 = new Bold();
                            RunProperties runHeader = new RunProperties();
                            Paragraph paraHeader = new Paragraph();
                            Text heading_text = new Text("Author");
                            Run runHeaderRun1 = new Run();
                            runHeaderRun1.Append(runHeader);
                            runHeaderRun1.Append(heading_text);
                            runHeader.Append(fontbold1);
                            paraHeader.Append(runHeaderRun1);
                            TableCell tcAuthor = new TableCell();
                            tcAuthor.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcAuthor.Append(paraHeader);

                            Bold fontboldSub = new Bold();
                            RunProperties runHeaderSub = new RunProperties();
                            Paragraph paraHeadersub = new Paragraph();
                            Text headingSub = new Text("Subject");
                            Run runHeaderRunSub = new Run();
                            runHeaderRunSub.Append(runHeaderSub);
                            runHeaderRunSub.Append(headingSub);
                            runHeaderSub.Append(fontboldSub);
                            paraHeadersub.Append(runHeaderRunSub);
                            TableCell tcSubject = new TableCell();
                            tcSubject.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcSubject.Append(paraHeadersub);

                            Bold fontboldDXC = new Bold();
                            RunProperties runHeaderDXC = new RunProperties();
                            Paragraph paraHeaderDXC = new Paragraph();
                            Text headingDXC = new Text("DXC");
                            Run runHeaderRunDXC = new Run();
                            runHeaderRunDXC.Append(runHeaderDXC);
                            runHeaderRunDXC.Append(headingDXC);
                            runHeaderDXC.Append(fontboldDXC);
                            paraHeaderDXC.Append(runHeaderRunDXC);
                            TableCell tcHP = new TableCell();
                            tcHP.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcHP.Append(paraHeaderDXC);

                            Bold fontboldCompleted = new Bold();
                            RunProperties runHeaderCompleted = new RunProperties();
                            Paragraph paraHeaderCompleted = new Paragraph();
                            Text headingCompleted = new Text("Status");
                            Run runHeaderRunCompleted = new Run();
                            runHeaderRunCompleted.Append(runHeaderCompleted);
                            runHeaderRunCompleted.Append(headingCompleted);
                            runHeaderCompleted.Append(fontboldCompleted);
                            paraHeaderCompleted.Append(runHeaderRunCompleted);
                            TableCell tcCompleted = new TableCell();
                            tcCompleted.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcCompleted.Append(paraHeaderCompleted);

                            Bold fontboldPickUp = new Bold();
                            RunProperties runHeaderPickUp = new RunProperties();
                            Paragraph paraHeaderPickUp = new Paragraph();
                            Text headingPickUp = new Text("Pick Up");
                            Run runHeaderRunPickUp = new Run();
                            runHeaderRunPickUp.Append(runHeaderPickUp);
                            runHeaderRunPickUp.Append(headingPickUp);
                            runHeaderPickUp.Append(fontboldPickUp);
                            paraHeaderPickUp.Append(runHeaderRunPickUp);
                            TableCell tcPickUp = new TableCell();
                            tcPickUp.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcPickUp.Append(paraHeaderPickUp);

                            Bold fontboldAction = new Bold();
                            RunProperties runHeaderAction = new RunProperties();
                            Paragraph paraHeaderAction = new Paragraph();
                            Text headingAction = new Text("Date of Action");
                            Run runHeaderRunAction = new Run();
                            runHeaderRunAction.Append(runHeaderAction);
                            runHeaderRunAction.Append(headingAction);
                            runHeaderAction.Append(fontboldAction);
                            paraHeaderAction.Append(runHeaderRunAction);
                            TableCell tcAction = new TableCell();
                            tcAction.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcAction.Append(paraHeaderAction);

                            Bold fontboldCompDate = new Bold();
                            RunProperties runHeaderCompDate = new RunProperties();
                            Paragraph paraHeaderCompDate = new Paragraph();
                            Text headingCompDate = new Text("Completed");
                            Run runHeaderRunCompDate = new Run();
                            runHeaderRunCompDate.Append(runHeaderCompDate);
                            runHeaderRunCompDate.Append(headingCompDate);
                            runHeaderCompDate.Append(fontboldCompDate);
                            paraHeaderCompDate.Append(runHeaderRunCompDate);
                            TableCell tcCompDate = new TableCell();
                            tcCompDate.Append(new TableCellProperties(new TableCellWidth() { Type = TableWidthUnitValues.Dxa, Width = "2400" }));
                            tcCompDate.Append(paraHeaderCompDate);

                            trHeader.Append(tcDocNumber, tcAuthor, tcSubject, tcHP, tcAction, tcCompleted, tcPickUp, tcCompDate);
                            tblLogSheet.AppendChild(trHeader);
                            
                            foreach (var item in SacnListColl)
                            {
                                TableRow trRow = new TableRow();

                                TableCell tcRowDocNumber = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPR_Test"])))));
                                TableCell tcRowAuthor = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["AuthorOPR"])))));
                                TableCell tcRowSubject = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPRType"]) + "\r\n" + Convert.ToString(item["OPRSubject"])))));
                                TableCell tcRowHP = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["HP_OPR"])))));
                                TableCell tcRowCompleted = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["OPRStatus"])))));
                                TableCell tcRowPickUp = new TableCell(new Paragraph(new Run(new Text(Convert.ToString(item["PickUp"])))));
                                

                                if (Convert.ToString(item["SeeMemo"]) == "1" || Convert.ToString(item["FinancialSeeMemo"]) == "See Memo")
                                {
                                    dateOfAction = "See Memo";
                                }
                                else if (String.IsNullOrEmpty(Convert.ToString(item["DateofActionOPR"])))
                                {
                                    dateOfAction = "";
                                }
                                else if (String.IsNullOrEmpty(Convert.ToString(item["FinancialOPR"])))
                                {
                                    dateOfAction = Convert.ToDateTime(item["DateofActionOPR"]).ToShortDateString();
                                }
                                else
                                {
                                    dateOfAction = Convert.ToDateTime(item["FinancialOPR"]).ToShortDateString();
                                }
                                TableCell tcRowAction = new TableCell(new Paragraph(new Run(new Text(dateOfAction))));

                                if (Convert.ToString(item["OPRStatus"]) == "Completed" || Convert.ToString(item["OPRStatus"]) == "Cancelled")
                                {
                                    CompletionDate = Convert.ToDateTime(item["CompletedDate"]).ToShortDateString();
                                }
                                else
                                {
                                    CompletionDate = null;
                                }
                                TableCell tcRowCompDate = new TableCell(new Paragraph(new Run(new Text(CompletionDate))));

                                trRow.Append(tcRowDocNumber, tcRowAuthor, tcRowSubject, tcRowHP, tcRowAction, tcRowCompleted, tcRowPickUp, tcRowCompDate);
                                tblLogSheet.AppendChild(trRow);
                               
                            }
                            body.AppendChild(tblLogSheet);
                            mainPart.Document.Save();
                        }
                        String fileName = DateTime.Now.ToString("dd-MM-yyyy") + ".docx";
                        AddToSharePoint(mem, fileName);
                        //System.IO.File.WriteAllBytes(@"C:\Users\txrapaka\Desktop\test1.docx", mem.ToArray());
                    }
                    //AddToSharePoint(mem, docName);

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        protected void AddToSharePoint(MemoryStream memoryStream, string fileName)
        {
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
            SPList docLib = currentWeb.Lists["Documents"];
            SPFile file = docLib.RootFolder.Files.Add(fileName, memoryStream.ToArray(), true);
            file.Update();

            //SPFile file = currentWeb.GetFile(fileName);
            SendLogSheetEmail(file);
            //outputMemory.Close();
            //outputMemory.Dispose();
            //outputMemory.Flush();
        }

        public void SendLogSheetEmail(SPFile file)
        {
            String from = string.Empty;
            String to = string.Empty;
            String subject = string.Empty;
            String body = string.Empty;

            from = "no-reply@medicaid.alabama.gov";
            String smtpServer = SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
            try
            {
                SPWebApplication webApp = this.Parent as SPWebApplication;
                SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["director"];
                SPList scanList = currentWeb.Lists["LogSheetEmailInfo"]; //LogSheetEmailInfo  
                SPQuery query = new SPQuery();
                SPListItemCollection listColl = scanList.GetItems(query);
                if (listColl.Count > 0)
                {
                    to = Convert.ToString(listColl[0]["To"]);
                    subject = Convert.ToString(listColl[0]["Subject"]);
                    body = Convert.ToString(listColl[0]["Body"]);
                }
                //Create an email message 
                MailMessage mailMessage = new MailMessage(from, to, subject, body);
                mailMessage.IsBodyHtml = true;
                mailMessage.Attachments.Add(new Attachment(file.OpenBinaryStream(), file.Name));
                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
          
    }
}
