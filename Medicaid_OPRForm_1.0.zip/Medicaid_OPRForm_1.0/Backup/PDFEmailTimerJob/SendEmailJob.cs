﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint;
using System.Collections.Specialized;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;
using System.Data;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html.simpleparser;
using System.IO;

namespace PDFEmailTimerJob
{
    class SendEmailJob : SPJobDefinition
    {
        public SendEmailJob() : base() { }

        SPWeb mySiteWeb;
        string siteUrl = "";
        public SendEmailJob(SPWebApplication webApp)
            : base("TimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "TimerJob";
        }

        public SendEmailJob(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public SendEmailJob(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            GeneratePDF();
        }
        //String siteUrl = SPContext.Current.Site.Url + "/director/";

        public DataRow[] GetDailyLogSheet() //Get Date specific List data 
        {
            DataRow[] dataRows = null;
            try
            {

                SPWebApplication webApp = this.Parent as SPWebApplication;
               // SPWeb web = webApp.Sites[0].AllWebs["director"];
                SPWeb web = webApp.Sites["FiscalAgent"].AllWebs["director"];
                //using (SPSite sites = new SPSite(SPContext.Current.Site.Url))
                //{
                //    using (SPWeb web = sites.OpenWeb())
                //    {

                        SPList scanList = web.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        DateTime table = DateTime.Now;
                        int hour = DateTime.Now.Hour;
                        bool isTime = hour < 14;

                        query.DatesInUtc = false;
                        SPListItemCollection listColl = scanList.GetItems(query);
                        if (listColl != null)
                        {
                            dataRows = listColl.GetDataTable().Select();
                        }
                //    }
                //}
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dataRows;
        }

        public void GeneratePDF()
        {
            try
            {

                DataRow[] logSheetArray = GetDailyLogSheet();

                String fromDate = DateTime.Now.Date.AddDays(-1).ToShortDateString();
                String toDate = DateTime.Now.Date.ToShortDateString();
                TimeSpan timespan = DateTime.Now.Date.Subtract(DateTime.Parse(fromDate + " 14:29:00"));
                if ((DateTime.Now.Hour == 14 && DateTime.Now.Minute >= 29) || (DateTime.Now.Hour >= 15))
                {
                    fromDate = DateTime.Now.Date.ToShortDateString();
                }
                var SacnListColl = logSheetArray.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Parse(fromDate + " 14:29:00")).ToList();
                //var SacnListColl = logSheetArray.ToList();

                if (SacnListColl.Count > 0)
                {

                    Font boldfont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 9, iTextSharp.text.Font.BOLD);
                    Font contentFont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 8, iTextSharp.text.Font.NORMAL);
                    //Font HeaderFont = new Font(iTextSharp.text.Font.FontFamily.TIMES_ROMAN, 12, iTextSharp.text.Font.BOLD);
                    var document = new Document(PageSize.A4, 10, 10, 25, 25);
                    var outputMemory = new MemoryStream();
                    var pdfWriter = PdfWriter.GetInstance(document, outputMemory);
                    document.Open();

                    PdfPTable tblHeader = new PdfPTable(6);
                    int[] tblHeaderWidth = { 20, 20, 15, 15, 15, 15 };
                    tblHeader.SetWidths(tblHeaderWidth);
                    tblHeader.WidthPercentage = 95;
                    tblHeader.SpacingAfter = 10f;
                    tblHeader.HorizontalAlignment = Element.ALIGN_CENTER;
                    tblHeader.DefaultCell.Border = 0;
                    tblHeader.DefaultCell.PaddingTop = 5;
                    tblHeader.DefaultCell.BorderWidthTop = 0.5f;
                    tblHeader.DefaultCell.BorderWidthBottom = 0.5f;
                    tblHeader.AddCell(new Phrase("DocNumber", boldfont));
                    tblHeader.AddCell(new Phrase("Author", boldfont));
                    tblHeader.AddCell(new Phrase("Subject", boldfont));
                    //tblHeader.AddCell(new Phrase("Subject_2", boldfont));
                    tblHeader.AddCell(new Phrase("HP", boldfont));
                    //tblHeader.AddCell(new Phrase("Date of Action", boldfont));
                    tblHeader.AddCell(new Phrase("Action", boldfont));
                    tblHeader.AddCell(new Phrase("Completed", boldfont));
                    document.Add(tblHeader);

                    PdfPTable tblColumn = new PdfPTable(6);
                    int[] tblColumnWidth = { 20, 20, 15, 15, 15, 15 };
                    tblColumn.SetWidths(tblHeaderWidth);
                    tblColumn.WidthPercentage = 95;
                    tblColumn.SpacingAfter = 10f;
                    tblColumn.HorizontalAlignment = Element.ALIGN_CENTER;
                    tblColumn.DefaultCell.Border = 0;
                    tblColumn.DefaultCell.PaddingTop = 5;
                    tblColumn.DefaultCell.BorderWidthBottom = 0.5f;

                    foreach (var item in SacnListColl)
                    {
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[7]), contentFont)); //DocNumber
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[13]), contentFont)); //Author
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[16] + "\r\n" + item.ItemArray[14]), contentFont)); //Subject_1
                        //tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[14]), contentFont)); //Subject_2
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[1]), contentFont)); //HP
                        //tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[10]), contentFont)); //Date of Letter
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[25]), contentFont)); //Date of Action
                        tblColumn.AddCell(new Phrase(Convert.ToString(item.ItemArray[26]), contentFont)); //Completed
                        document.Add(tblColumn);
                        tblColumn.FlushContent();

                    }

                    PdfContentByte pdfContentByte = pdfWriter.DirectContent;
                    pdfContentByte.SetLineWidth(1.0f);
                    pdfContentByte.MoveTo(10, document.Bottom - 10f);
                    pdfContentByte.LineTo(580, document.Bottom - 10f);
                    pdfContentByte.Stroke();

                    document.Close();
                    document.Dispose();

                    byte[] FileContent = outputMemory.ToArray();

                    SPWebApplication webApp = this.Parent as SPWebApplication;
                   // SPWeb web = webApp.Sites[0].AllWebs["director"];
                    SPWeb web = webApp.Sites["FiscalAgent"].AllWebs["director"];
                    //using (SPSite site = new SPSite(SPContext.Current.Site.Url + "/director/"))
                    //{
                    //    using (SPWeb web = site.OpenWeb())
                    //    {
                            SPList DocLib = web.Lists["Documents"];
                            //Add the file
                            String fileName = DocLib.RootFolder + "/" + DateTime.Now.ToString("dd-MM-yyyy") + ".pdf";
                            web.Files.Add(fileName, FileContent, true);

                            SPFile file = web.GetFile(fileName);
                            SendMail(file);
                    //    }
                    //}

                    outputMemory.Close();
                    outputMemory.Dispose();
                    outputMemory.Flush();


                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public bool SendMail(SPFile file)
        {
            bool mailSent = false;
            SmtpClient smtpClient = null;

            string from = string.Empty;
            string smtpAddress = string.Empty;
            string to = "Tilak.Rapaka@medicaid.alabama.gov";
            string subject = "Daily OPR Log";
            string body = "Daily OPR Attached";
            String cc = null;
            String bcc = null;
            from = "no-reply@medicaid.alabama.gov";
            smtpAddress = "10.131.89.54";

            try
            {
                // Assign SMTP address 
                smtpClient = new SmtpClient();
                smtpClient.Host = smtpAddress;

                //Create an email message 
                MailMessage mailMessage = new MailMessage(from, to, subject, body);
                if (!String.IsNullOrEmpty(cc))
                {
                    MailAddress CCAddress = new MailAddress(cc);
                    mailMessage.CC.Add(CCAddress);
                }
                if (!String.IsNullOrEmpty(bcc))
                {
                    MailAddress BCCAddress = new MailAddress(bcc);
                    mailMessage.Bcc.Add(BCCAddress);
                }
                mailMessage.IsBodyHtml = true;

                // Send the email 
                mailMessage.Attachments.Add(new Attachment(file.OpenBinaryStream(), file.Name));
                smtpClient.Send(mailMessage);
                mailSent = true;
            }
            catch (Exception)
            {
                mailSent = false;
            }

            return mailSent;
        }
    }
}
