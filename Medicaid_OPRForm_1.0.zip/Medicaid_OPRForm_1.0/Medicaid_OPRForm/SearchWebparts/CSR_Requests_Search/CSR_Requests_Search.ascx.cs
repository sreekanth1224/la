﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_OPRForm.Utility;



namespace Medicaid_OPRForm.Webparts.CSR_Requests_Search
{
    [ToolboxItemAttribute(false)]
    public partial class CSR_Requests_Search : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CSR_Requests_Search()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        Int32 pageIndex = 0;    //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        //String strPageInfo = String.Empty;
        List<CSRSearchEntity> searchEntity = new List<CSRSearchEntity>();
        DateTime tempDate;

        public List<CSRSearchEntity> GetCSRData(String paging) //Get Date specific List data 
        {
            bool isDueDateValid = (txtCSRDate.Text == "CSR Date" || txtCSRDate.Text.Length == 0) ? true : DateTime.TryParse(txtCSRDate.Text, out tempDate);
            if (isDueDateValid)
            {
                try
                {
                    String loginName = String.Empty;
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);

                    pageIndex = 0;  //Page Index

                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            lblErrorMsg.Text = String.Empty;
                            //ViewState["CSRTable"] = null;
                            SPList scanList = currentWeb.Lists["CSRRequests"];
                            List<string> objColumns = new List<string>();

                            // here, format is like: "Column name(internal name of column);Column type; Conditional operator; Search string (input by user)

                            SPQuery query = new SPQuery();
                            //query.RowLimit = Convert.ToUInt32(ddlRowCount.SelectedValue);

                            if (txtITBNumber.Text != "ITB Number" && txtITBNumber.Text.Length > 0)
                            {
                                objColumns.Add("ITBNumber;Text;Contains;" + txtITBNumber.Text.Trim());
                            }
                            if (txtCSRNumber.Text != "CSR Number" && txtCSRNumber.Text.Length > 0)
                            {
                                objColumns.Add("CSRNumber;Text;Contains;" + txtCSRNumber.Text.Trim());
                            }
                            if (txtCSRDate.Text != "CSR Date" && txtCSRDate.Text.Length > 0)
                            {
                                objColumns.Add("CSRDate;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtCSRDate.Text)));
                            }
                            if (txtDocumentType.Text != "Document Type" && txtDocumentType.Text.Length > 0)
                            {
                                objColumns.Add("DocumentType;Text;Contains;" + txtDocumentType.Text.Trim());
                            }
                            if (txtStatus.Text != "Status" && txtStatus.Text.Length > 0)
                            {
                                objColumns.Add("Status;Text;Contains;" + txtStatus.Text.Trim());
                            }
                            if (txtOriginator.Text != "Originator" && txtOriginator.Text.Length > 0)
                            {
                                objColumns.Add("Originator;Text;Contains;" + txtOriginator.Text.Trim());
                            }
                            if (txtOPRNumber.Text != "OPR Number" && txtOPRNumber.Text.Length > 0)
                            {
                                objColumns.Add("OPRNumber;Text;Contains;" + txtOPRNumber.Text.Trim());
                            }

                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='CSRDate' Ascending='FALSE'/></OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                       "<FieldRef Name='ITBNumber' />",
                                       "<FieldRef Name='CSRNumber' />",
                                       "<FieldRef Name='CSRDate' />",
                                       "<FieldRef Name='DocumentType' />",
                                       "<FieldRef Name='Status' />",
                                       "<FieldRef Name='Originator' />",
                                       "<FieldRef Name='OPRNumber' />",
                                       "<FieldRef Name='Created' />",
                                       "<FieldRef Name='ID' />");
                            query.ViewFieldsOnly = true;

                            //if (itemPoistion != null) //Item Position
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}

                            SPListItemCollection listColl = scanList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (listColl != null && listColl.Count > 0)
                            {
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new CSRSearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        ITBNumber = Convert.ToString(item["ITBNumber"]),
                                        CSRNumber = Convert.ToString(item["CSRNumber"]),
                                        CSRDate = Convert.ToDateTime(item["CSRDate"]),
                                        DocumentType = Convert.ToString(item["DocumentType"]),
                                        Status = Convert.ToString(item["Status"]),
                                        Originator = Convert.ToString(item["Originator"]),
                                        OPRNumber = Convert.ToString(item["OPRNumber"]),
                                        Created = Convert.ToDateTime(item["Created"])
                                    });
                                }

                            }

                            else
                            {
                                gvCSRSearch.DataSource = null;
                                gvCSRSearch.DataBind();
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }

        public void ClearSearchFields()
        {
            if (txtITBNumber.Text == "ITB Number")
            {
                txtITBNumber.Text = "";
            }
            if (txtCSRNumber.Text == "CSR Number")
            {
                txtCSRNumber.Text = "";
            }
            if (txtCSRDate.Text == "CSR Date")
            {
                txtCSRDate.Text = "";
            }
            if (txtDocumentType.Text == "Document Type")
            {
                txtDocumentType.Text = "";
            }
            if (txtStatus.Text == "Status")
            {
                txtStatus.Text = "";
            }
            if (txtOriginator.Text == "Originator")
            {
                txtOriginator.Text = "";
            }
            if (txtOPRNumber.Text == "OPR Number")
            {
                txtOPRNumber.Text = "";
            }

        }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where>");
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            //GetCSRData(null);
            ClearSearchFields();
            gvCSRSearch.DataSource = GetCSRData(null);
            gvCSRSearch.DataBind();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            txtITBNumber.Text = "ITB Number";
            txtCSRNumber.Text = "CSR Number";
            txtCSRDate.Text = "CSR Date";
            txtDocumentType.Text = "Document Type";
            txtStatus.Text = "Status";
            txtOriginator.Text = "Originator";
            txtOPRNumber.Text = "OPR Number";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/SitePages/CSR%20Search.aspx");

        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            gvCSRSearch.DataSource = GetCSRData(null);
            gvCSRSearch.DataBind();
            //GetCSRData(null);
            //if (ViewState["CSRTable"] != null)
            //{
            //    DataTable dt = ViewState["CSRTable"] as DataTable;

            //    if (dt != null)
            //    {
            //        gvCSRSearch.PageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
            //        gvCSRSearch.DataSource = ViewState["CSRTable"];
            //        gvCSRSearch.DataBind();
            //    }
            //}
        }

        protected void gvCSRSearch_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
            //if (ViewState["CSRTable"] != null)
            //{
            //    DataTable dt = ViewState["CSRTable"] as DataTable;

            //    if (dt != null)
            //    {
            //        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
            //        gvCSRSearch.DataSource = ViewState["CSRTable"];
            //        gvCSRSearch.DataBind();
            //    }
            //}
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        protected void gvCSRSearch_PageIndexChanging1(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            //ClearSearchFields();
            //gvCSRSearch.PageIndex = e.NewPageIndex;
            //GetCSRData();
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            //String pageInfo = ViewState["Prev"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
           // oPos.PagingInfo = ViewState["Prev"] as String;
            //GetCSRData(oPos);
            gvCSRSearch.DataSource = GetCSRData("prev");
            gvCSRSearch.DataBind();

        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
        //    String pageInfo = ViewState["Next"] as String;
        //    SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
        //    //oPos.PagingInfo = ViewState["Prev"] as String;
        //    GetCSRData(oPos);
            gvCSRSearch.DataSource = GetCSRData("next");
            gvCSRSearch.DataBind();
        }

        public void SortColumn(String sortExpression)
        {
            List<CSRSearchEntity> CSRSearchEntityList = GetCSRData(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "ITBNumber":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.ITBNumber).ToList() : CSRSearchEntityList.OrderByDescending(x => x.ITBNumber).ToList();
                    break;
                case "CSRNumber":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.CSRNumber).ToList() : CSRSearchEntityList.OrderByDescending(x => x.CSRNumber).ToList();
                    break;
                case "CSRDate":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.CSRDate).ToList() : CSRSearchEntityList.OrderByDescending(x => x.CSRDate).ToList();
                    break;
                case "DocumentType":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.DocumentType).ToList() : CSRSearchEntityList.OrderByDescending(x => x.DocumentType).ToList();
                    break;
                case "Status":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.Status).ToList() : CSRSearchEntityList.OrderByDescending(x => x.Status).ToList();
                    break;
                case "Originator":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.Originator).ToList() : CSRSearchEntityList.OrderByDescending(x => x.Originator).ToList();
                    break;
                case "OPRNumber":
                    gvCSRSearch.DataSource = (sortDirection == "ASC") ? CSRSearchEntityList.OrderBy(x => x.OPRNumber).ToList() : CSRSearchEntityList.OrderByDescending(x => x.OPRNumber).ToList();
                    break;

            }
            gvCSRSearch.DataBind();
        } 
    }
}
    

