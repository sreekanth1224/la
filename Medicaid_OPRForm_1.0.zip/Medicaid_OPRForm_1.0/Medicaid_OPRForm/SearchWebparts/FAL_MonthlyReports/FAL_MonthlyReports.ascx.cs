﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Linq;
using System.Collections.Generic;
using System.Text;

namespace Medicaid_OPRForm.SearchWebparts.FAL_MonthlyReports
{
    [ToolboxItemAttribute(false)]
    public partial class FAL_MonthlyReports : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public FAL_MonthlyReports()
        {
        }
        String siteUrl = SPContext.Current.Site.Url + "/director/";
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindYears();
                ddlYear.SelectedValue = DateTime.Now.Year.ToString();
                ddlMonth.SelectedValue = DateTime.Now.Month.ToString();
                if (!String.IsNullOrEmpty(ddlYear.SelectedValue) && !String.IsNullOrEmpty(ddlMonth.SelectedValue))
                {
                    GetMonthlyReport(ddlYear.SelectedValue, ddlMonth.SelectedValue); //Cmt
                }
            }
        }
        public void BindYears()
        {
            try
            {
                Int32 currentYear = DateTime.Now.Year;
                for (Int32 year = 2006; year <= currentYear; year++)
                {
                    ddlYear.Items.Add(year.ToString());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(ddlYear.SelectedValue) && !String.IsNullOrEmpty(ddlMonth.SelectedValue))
            {
                GetMonthlyReport(ddlYear.SelectedValue, ddlMonth.SelectedValue);
            }
        }
        public void GetMonthlyReport(String Year, String Month) //Get Date specific List data 
        {
            Int32 selectedYear = Convert.ToInt32(Year);//2018
            Int32 selectedMonth = Convert.ToInt32(Month);//3
            Int32 monthLastDay = DateTime.DaysInMonth(selectedYear, selectedMonth);
            Int32 monthStartDay = 1;
            DateTime startDate = new DateTime(selectedYear, selectedMonth, monthStartDay);
            DateTime endDate = new DateTime(selectedYear, selectedMonth, monthLastDay);

            lblCancelled.Text = "0";
            lblCompleted.Text = "0";
            lblPending.Text = "0";

            Int32 cancelledCount = 0;
            Int32 completedCount = 0;
            Int32 pendigCount = 0;
            
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList OPRList = currentWeb.Lists["Scan List"];
                        SPQuery query = new SPQuery();
                        String strQuery = String.Empty;
                        if (Convert.ToInt32(ddlYear.SelectedValue) < 2017 || (Convert.ToInt32(ddlYear.SelectedValue) == 2017 && Convert.ToInt32(ddlMonth.SelectedValue) < 12))
                        {
                            strQuery = "<Where>" +
                                           "<And>" +
                                           "<Geq>" +
                                                "<FieldRef Name='OPR_Date'/>" +
                                                "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate.Date) + "</Value>" +
                                           "</Geq>" +
                                            "<Leq>" +
                                                "<FieldRef Name='OPR_Date'/>" +
                                                "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate.Date) + "</Value>" +
                                           "</Leq>" +
                                           "</And>" +
                                       "</Where>";
                        }
                        else
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                            "<Geq>" +
                                                 "<FieldRef Name='Created'/>" +
                                                 "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate.Date) + "</Value>" +
                                            "</Geq>" +
                                             "<Leq>" +
                                                 "<FieldRef Name='Created'/>" +
                                                 "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate.Date) + "</Value>" +
                                            "</Leq>" +
                                            "</And>" +
                                        "</Where>";
                        }
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                    "<FieldRef Name='ID' />",
                                     "<FieldRef Name='OPRStatus' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        SPListItemCollection listColl = OPRList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DataTable OPRTable = listColl.GetDataTable();

                            var groupedData = from b in OPRTable.AsEnumerable()
                                              group b by b.Field<string>("OPRStatus") into g
                                              let list = g.ToList()
                                              select new
                                              {
                                                  OPRStatus = g.Key,
                                                  Count = list.Count,
                                              };
                            foreach (var data in groupedData)
                            {
                                if (data.OPRStatus == "Pending")
                                {
                                    pendigCount = pendigCount + data.Count;
                                }
                                if (data.OPRStatus == "PENDING")
                                {
                                    pendigCount = pendigCount + data.Count;
                                }
                                if (data.OPRStatus == "Cancelled")
                                {
                                    cancelledCount = cancelledCount + data.Count;
                                }
                                if (data.OPRStatus == "CANCELLED")
                                {
                                    cancelledCount = cancelledCount + data.Count;
                                }
                                if (data.OPRStatus == "Completed")
                                {
                                    completedCount = completedCount + data.Count;
                                }
                                if (data.OPRStatus == "COMPLETED")
                                {
                                    completedCount = completedCount + data.Count;
                                }
                            }
                            Int32 total = pendigCount + cancelledCount + completedCount;
                            lblPending.Text = Convert.ToString(pendigCount);
                            lblCancelled.Text = Convert.ToString(cancelledCount);
                            lblCompleted.Text = Convert.ToString(completedCount);
                            lblTotal.Text = Convert.ToString(total);
                        }
                        else
                        {
                            lblCancelled.Text = "0";
                            lblCompleted.Text = "0";
                            lblPending.Text = "0";
                            lblTotal.Text = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
