﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_OPRForm.Utility;


namespace Medicaid_OPRForm.Webparts.BASearch
{
    [ToolboxItemAttribute(false)]
    public partial class BASearch : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public BASearch()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        String siteUrl = SPContext.Current.Site.Url + "/director/";
        Int32 pageIndex = 0;    //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        //String strPageInfo = String.Empty;
        List<BASearchEntity> searchEntity = new List<BASearchEntity>();
        DateTime tempDate;
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        public List<BASearchEntity> GetBAListData(String paging) //Get Date specific List data 
        {
            bool isDueDateValid = (txtBADate.Text == "BA Date" || txtBADate.Text.Length == 0) ? true : DateTime.TryParse(txtBADate.Text, out tempDate);
            if (isDueDateValid)
            {
                try
                {
                    String loginName = String.Empty;
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);

                    pageIndex = 0;  //Page Index
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb currentWeb = site.OpenWeb())
                        {
                            lblErrorMsg.Text = String.Empty;
                            //ViewState["BATable"] = null;
                            SPList scanList = currentWeb.Lists["BusinessAssociates"];
                            List<string> objColumns = new List<string>();

                            // here, format is like: "Column name(internal name of column);Column type; Conditional operator; Search string (input by user)

                            SPQuery query = new SPQuery();
                            //query.RowLimit = Convert.ToUInt32(dropdownPageSize); //Row Limit

                            if (txtBANumber.Text != "BA Number" && txtBANumber.Text.Length > 0)
                            {
                                objColumns.Add("BANumber;Text;Contains;" + txtBANumber.Text.Trim());
                            }
                            if (txtBAName.Text != "BA Name" && txtBAName.Text.Length > 0)
                            {
                                objColumns.Add("BAName;Text;Contains;" + txtBAName.Text.Trim());
                            }
                            if (txtBADate.Text != "BA Date" && txtBADate.Text.Length > 0)
                            {
                                objColumns.Add("BADate;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtBADate.Text)));
                            }
                            if (txtBAOwner.Text != "BA Owner" && txtBAOwner.Text.Length > 0)
                            {
                                objColumns.Add("BAOwner;Text;Contains;" + txtBAOwner.Text.Trim());
                            }

                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                query.Query = "<OrderBy><FieldRef Name='BADate' Ascending='FALSE'/></OrderBy>";
                            }
                            query.ViewFields = string.Concat(
                                       "<FieldRef Name='BANumber' />",
                                       "<FieldRef Name='BAName' />",
                                       "<FieldRef Name='BADate' />",
                                       "<FieldRef Name='BAOwner' />",
                                       "<FieldRef Name='Created' />",
                                       "<FieldRef Name='ID' />");
                            query.ViewFieldsOnly = true;

                            //if (itemPoistion != null) //Item Position
                            //{
                            //    query.ListItemCollectionPosition = itemPoistion;
                            //}

                            SPListItemCollection listColl = scanList.GetItems(query);
                            Int32 scanListCount = listColl.Count;
                            if (listColl != null && listColl.Count > 0)
                            {
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = scanListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == scanListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (scanListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new BASearchEntity
                                    {
                                        ID = Convert.ToInt32(item["ID"]),
                                        BANumber = Convert.ToString(item["BANumber"]),
                                        BAName = Convert.ToString(item["BAName"]),
                                        BADate = Convert.ToDateTime(item["BADate"]),
                                        BAOwner = Convert.ToString(item["BAOwner"]),
                                        Created = Convert.ToDateTime(item["Created"])
                                    });
                                }

                            }
                            else
                            {
                                gvBASearch.DataSource = null;
                                gvBASearch.DataBind();
                            }

                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }

        public void ClearSearchFields()
        {
            if (txtBANumber.Text == "BA Number")
            {
                txtBANumber.Text = "";
            }
            if (txtBAName.Text == "BA Name")
            {
                txtBAName.Text = "";
            }
            if (txtBADate.Text == "BA Date")
            {
                txtBADate.Text = "";
            }
            if (txtBAOwner.Text == "BA Owner")
            {
                txtBAOwner.Text = "";
            }
         }

        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>");
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        protected void btnSerach_Click(object sender, EventArgs e)
        {
            //GetBAListData(null,null);
            ClearSearchFields();
            gvBASearch.DataSource = GetBAListData(null);
            gvBASearch.DataBind();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            //txtEDS_Number.Text = "DXC_Number";
            txtBANumber.Text = "BA Number";
            txtBAName.Text = "BA Name";
            txtBADate.Text = "BA Date";
            txtBAOwner.Text = "BA Owner";
            Page.Response.Redirect(SPContext.Current.Site.Url + "/SitePages/BA%20Search.aspx");
        }

        protected void gvBASearch_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            //ClearSearchFields();
            //gvBASearch.PageIndex = e.NewPageIndex;
            //GetBAListData();
        }

        protected void ddlRowCount_SelectedIndexChanged(object sender, EventArgs e)
        {
            //GetBAListData(null,null);
            gvBASearch.DataSource = GetBAListData(null);
            gvBASearch.DataBind();
            
        }

        protected void gvBASearch_Sorting(object sender, System.Web.UI.WebControls.GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
            //if (ViewState["BATable"] != null)
            //{
            //    DataTable dt = ViewState["BATable"] as DataTable;

            //    if (dt != null)
            //    {
            //        dt.DefaultView.Sort = e.SortExpression + " " + GetSortDirection(e.SortExpression);
            //        gvBASearch.DataSource = ViewState["BATable"];
            //        gvBASearch.DataBind();
            //    }
            //}
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            //ClearSearchFields();
            //String pageInfo = ViewState["Prev"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //GetBAListData(oPos, "prev");
            gvBASearch.DataSource = GetBAListData("prev");
            gvBASearch.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            //ClearSearchFields();
            //String pageInfo = ViewState["Next"] as String;
            //SPListItemCollectionPosition oPos = new SPListItemCollectionPosition(pageInfo);
            //GetBAListData(oPos, "next");
            gvBASearch.DataSource = GetBAListData("next");
            gvBASearch.DataBind();
        }

        public void SortColumn(String sortExpression)
        {
            List<BASearchEntity> BASearchEntityList = GetBAListData(null);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "BANumber":
                    gvBASearch.DataSource = (sortDirection == "ASC") ? BASearchEntityList.OrderBy(x => x.BANumber).ToList() : BASearchEntityList.OrderByDescending(x => x.BANumber).ToList();
                    break;
                case "BAName":
                    gvBASearch.DataSource = (sortDirection == "ASC") ? BASearchEntityList.OrderBy(x => x.BAName).ToList() : BASearchEntityList.OrderByDescending(x => x.BAName).ToList();
                    break;
                case "BADate":
                    gvBASearch.DataSource = (sortDirection == "ASC") ? BASearchEntityList.OrderBy(x => x.BADate).ToList() : BASearchEntityList.OrderByDescending(x => x.BADate).ToList();
                    break;
                case "BAOwner":
                    gvBASearch.DataSource = (sortDirection == "ASC") ? BASearchEntityList.OrderBy(x => x.BAOwner).ToList() : BASearchEntityList.OrderByDescending(x => x.BAOwner).ToList();
                    break;
                               
            }
            gvBASearch.DataBind();
        } 
    }
}
