  $(document).ready(function () {

        $("[id$=txtFinancial]").datepicker();
        //$("[id$=txtDateofAction]").datepicker();
        $("[id$=txtFooterDateofLetter]").datepicker({ maxDate: new Date, minDate: new Date(2007, 6, 12) });
        $("[id$=txtSubmittedDate]").datepicker({ maxDate: new Date, minDate: new Date(2007, 6, 12) });

        $(".divSearchContainer").hide();
		$("[id$=txtDateofAction]").prop('readonly', true);
        $(".divCollapse").click(function () {
            $(this).next(".divSearchContainer").slideToggle("500");
        });
		
		 $("[id$=txtFooterDateofLetter]").change(function (){	
		 debugger;
			if($("[id$=txtFooterDateofLetter]").length > 0 && !isNaN(new Date($("[id$=txtDateofAction]").val())))
			{
				$("[id$=txtDateofAction]").prop('readonly', false);
				$("[id$=txtDateofAction]").val(getdate());
				$("[id$=txtDateofAction]").prop('readonly', true);
			}
		 });
		 $("[id$=txtDateofLetter]").change(function (){
		 debugger;
			if($("[id$=txtDateofLetter]").length > 0 && !isNaN(new Date($("[id$=txtDateofAction]").val())))
			{
				$("[id$=txtDateofAction]").prop('readonly', false);
				$("[id$=txtDateofAction]").val(getdate());
				$("[id$=txtDateofAction]").prop('readonly', true);
			}
		 });

        var siteurl = _spPageContextInfo.webAbsoluteUrl;
        var availableTags = [];
        $.ajax({
            url: siteurl + "/_api/web/lists/getbytitle('HPE')/items",
            method: "GET",
            headers: { "Accept": "application/json; odata=verbose" },
            success: function (data) {
                if (data.d.results.length > 0) {
                    var results = data.d.results;
                    for (var i = 0; i < results.length; i++) {
                        availableTags.push(results[i].EDS_Number);
                    }
                    //alert(data.d.results.length);
                }
            },
            error: function (data) {
                alert("Error: " + data);
            }
        });

        $('[id$=txtEDSNumber]').autocomplete({
            source: availableTags
        });

        $('[id$=PeopleEditorOriginator]').autocomplete({  
            source: search,  
			autoFocus: true,
            minLength: 3
        });  

    });
	
	function getdate() {
    debugger;
    var date = new Date($("[id$=txtFooterDateofLetter]").val());
    var newdate = new Date(date);

    newdate.setDate(newdate.getDate() + parseInt($("[id$=lblNoOfDays]").text()));
    
    var dd = newdate.getDate();
    var mm = newdate.getMonth() + 1;
    var y = newdate.getFullYear();

    var someFormattedDate = mm + '/' + dd + '/' + y;
    return someFormattedDate;
}

    

    function search(request,response) {  
        //debugger;
		var siteurl = _spPageContextInfo.webAbsoluteUrl;
        var sourceURL = siteurl + "/_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface.clientPeoplePickerSearchUser";  
        var principalType = this.element[0].getAttribute('principalType');  
        $.ajax(
        {
            'url': sourceURL,
            'method': 'POST',
            'data': JSON.stringify({
                'queryParams': {
                    '__metadata': {
                        'type': 'SP.UI.ApplicationPages.ClientPeoplePickerQueryParameters'
                    },
                    'AllowEmailAddresses': true,
                    'AllowMultipleEntities': false,
                    'AllUrlZones': false,
                    'MaximumEntitySuggestions': 50,
                    'PrincipalSource': 15,
                    'PrincipalType': 1,
                    'QueryString': request.term,
                    'Required': false

                }
            }),
            'headers': {
                'accept': 'application/json;odata=verbose',
                'content-type': 'application/json;odata=verbose',
                'X-RequestDigest': $("#__REQUESTDIGEST").val()
            },
            'success': function (data) {
                debugger;
                var d = data;
                var results = JSON.parse(data.d.ClientPeoplePickerSearchUser);
                if (results.length != 0) {
                    response($.map(results, function (item) {
						//debugger;
						if(item.EntityData.Department == "Medicaid"){
							return { label: item.DisplayText, value: item.DisplayText }
						}						
                    }));
                }
				if (results.length == 0) {
					 $('[id$=PeopleEditorOriginator]').val("No match found");
				}
            },
            'error': function (err) {
                console.log(JSON.stringify(err));
            },
			'select': function (event, ui) {
                $(this).val(ui.item.label);
			}
        });
   
    }  