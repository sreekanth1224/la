﻿using System;
using System.Collections.Generic;
using System.Security.Permissions;
using System.Text;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Security;
using System.Web;
using iTextSharp.text.pdf;
using itextSharpText = iTextSharp.text;
using System.IO;
using System.Text.RegularExpressions;
using iTextSharp.text;

namespace Medicaid_OPRForm.EventReceivers.MergeDocEventReceiver
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class MergeDocEventReceiver : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            //EventFiringEnabled = false;

            //////Add code for event ItemUpdated in ScanListEventADD 
            //if (properties.ListTitle == "Scan Merge Doc")
            //{
            //    String siteUrl = properties.WebUrl;
            //    String docUrl = properties.AfterUrl;
            //    AppendPDFPage(siteUrl, docUrl);
            //}
            //EventFiringEnabled = true;
        }

        public static void AppendPDFPage(String siteUrl, String docUrl)
        {
            List<String> lstFiles = new List<String>();
            //String siteUrl = SPContext.Current.Site.Url + "/director/";properties.Site.PrimaryUri
            String fileName = String.Empty;
            String filePath = String.Empty;
            fileName = docUrl.Remove(0, (docUrl.IndexOf('/') +1));
            filePath = siteUrl + "/Scan%20OPR/" + fileName;
            lstFiles.Add(filePath);
            lstFiles.Add(siteUrl + "/" + docUrl);
            //Method to merge file fetched from Sacn Opr  & Scan Merge Doc Document Libraries
            MergeDocuments(lstFiles, fileName, siteUrl);

           
        }

        public static void MergeDocuments(List<String> lstFiles, String fileName, String siteUrl)
        {
            PdfReader reader = null;
            Document sourceDocument = null;
            PdfCopy pdfCopyProvider = null;
            PdfImportedPage importedPage;
            string outputPdfPath = @"C:/Merge/" + fileName; //Merge Folder
            sourceDocument = new Document();
            pdfCopyProvider = new PdfCopy(sourceDocument, new System.IO.FileStream(outputPdfPath, System.IO.FileMode.Create));

            //Open the output file
            sourceDocument.Open();

            try
            {
                //Loop through the files list
                int pages = 0;
                foreach (String file in lstFiles)
                {
                    pages = get_pageCcount(file, siteUrl);
                    reader = new PdfReader(file);
                    //Add pages of current file
                    for (int i = 1; i <= pages; i++)
                    {
                        importedPage = pdfCopyProvider.GetImportedPage(reader, i);
                        pdfCopyProvider.AddPage(importedPage);
                    }
                    reader.Close();
                    reader.Dispose();
                }
                lstFiles.Clear();
                //At the end save the output file
                pdfCopyProvider.Dispose();
                sourceDocument.Close();
                //OverWrite merged document back to Scan OPR Document Library
                SaveMergedDocument(fileName, siteUrl);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public static void SaveMergedDocument(String fileName, String siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLibrary = currentWeb.Lists["Scan OPR"];
                    String outputPdfPath = @"C:/Merge/" + fileName;
                    Byte[] fileArray = File.ReadAllBytes(outputPdfPath);
                    SPFile file = currentWeb.Files.Add(scanOPRLibrary.RootFolder + "/" + fileName, fileArray, true);
                    scanOPRLibrary.Update();                   
                  
                    ////Delete file from Merge Document Library
                    DeleteFileFromMergeDocLib(siteUrl, fileName);
                }
            }
        }

        public static void DeleteFileFromMergeDocLib(String siteUrl,String fileName)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPFile file = currentWeb.GetFile(siteUrl + "/Scan Merge Doc/" + fileName);
                    file.Delete();
                }
            }

            //Delete file from Merge Document Library
            String networkFolderPath = @"C:/Merge";
            String[] files = Directory.GetFiles(networkFolderPath);
            foreach (String filePath in files)
            {
                if (filePath.Contains(fileName))
                {
                    File.Delete(filePath);
                }
            }
        }

        private static int get_pageCcount(string fileUrl, String siteUrl)
        {
            using (SPSite site = new SPSite(siteUrl)) //Dev Site - C
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPFile file = web.GetFile(fileUrl);
                  
                    using (StreamReader sr = new StreamReader(file.OpenBinaryStream()))
                    {
                        Regex regex = new Regex(@"/Type\s*/Page[^s]");
                        MatchCollection matches = regex.Matches(sr.ReadToEnd());

                        return matches.Count;
                    }
                }
            }
        }

        /// <summary>
        /// An item was added
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            //base.ItemAdded(properties);
            SPSecurity.RunWithElevatedPrivileges(delegate()
             {
                 EventFiringEnabled = false;

                 if (properties.ListTitle == "Scan%20Merge%20Doc")
                 {
                     try
                     {
                         String siteUrl = properties.WebUrl;
                         String docUrl = properties.AfterUrl;
                         AppendPDFPage(siteUrl, docUrl);
                         //}
                         EventFiringEnabled = true;
                     }
                     catch (Exception ex)
                     {
                         throw ex;
                     }
                 }
             });   

        }

        /// <summary>
        /// An item was updated
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            SPSecurity.RunWithElevatedPrivileges(delegate()
            {
                EventFiringEnabled = false;

                if (properties.ListTitle == "Scan%20Merge%20Doc")
                {
                    try
                    {
                        String siteUrl = properties.WebUrl;
                        String docUrl = properties.AfterUrl;
                        AppendPDFPage(siteUrl, docUrl);
                        //}
                        EventFiringEnabled = true;
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            });   
        }

    }
}