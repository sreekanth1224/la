﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_OPRForm.ControlTemplates1.Medicaid_OPRForm
{
    public partial class OPRDueDateUpdate : UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
