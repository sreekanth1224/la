﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Linq;

namespace Medicaid_OPRForm.FALSiteCollectionDashboard
{
    [ToolboxItemAttribute(false)]
    public partial class FALSiteCollectionDashboard : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public FALSiteCollectionDashboard()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }
        String siteUrl = SPContext.Current.Site.Url;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetListInformation();
                CheckUserGroup();
            }
        }

        public Boolean UserInGroup(SPUser user, String groupName)
        {
            return user.Groups.Cast<SPGroup>().Any(g => g.Name.Equals(groupName));
        }

        protected void CheckUserGroup()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPUser currentUser = currentWeb.CurrentUser;
                    SPUser user = currentWeb.EnsureUser(currentUser.LoginName);
                    Boolean OPRUser = UserInGroup(user, "OPR_Requests");
                    Boolean HPEUser = UserInGroup(user,"HPE_Requests");
                    Boolean BAUser = UserInGroup(user, "BA_Requests");
                    Boolean CSRUser = UserInGroup(user, "CSR_Requests");
                    Boolean ITBUser = UserInGroup(user, "ITB_Requests");
                    Boolean PrivacyUser = UserInGroup(user, "Privacy_Requests");

                    if (currentUser.IsSiteAdmin || UserInGroup(user, "Fiscal Agent Liaison Owners"))
                    {
                        lnkOPR.Visible = true;
                        lnkHPE.Visible = true;
                        lnkBA.Visible = true;
                        lnkITB.Visible = true;
                        lnkPrivacy.Visible = true;
                        lnkCSR.Visible = true;
                        //lnkPrivacy.Visible = true;
                    }
                    else
                    {
                        if (OPRUser)
                            lnkOPR.Visible = true;
                        if (HPEUser)
                            lnkHPE.Visible = true;
                        if (BAUser)
                            lnkBA.Visible = true;
                        if (CSRUser)
                            lnkCSR.Visible = true;
                        if (ITBUser)
                            lnkITB.Visible = true;
                        if (PrivacyUser)
                            lnkPrivacy.Visible = true;
                    }
                    
                }
            }
        }

        protected void GetListInformation()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                   
                    SPList HPEList = currentWeb.Lists["FALInformation"];
                    SPQuery camlQuery = new SPQuery();
                    SPListItemCollection listColl = HPEList.GetItems(camlQuery);

                    if (listColl.Count > 0)
                    {
                        lblInformation.Text = Convert.ToString(listColl[0]["Information"]);
                    }
                    else
                    {
                        lblInformation.Text = "";
                    }
                }
            }
        }
    }
}
