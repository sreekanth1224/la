﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_OPRForm.Utility
{
    [Serializable()]
    public class PrivacySearchEntity
    {
        public int ID { get; set; }
        public string MedicaidID { get; set; }
        public string SSN { get; set; }
        public DateTime RequestDate { get; set; }
        public string RecipientName { get; set; }
        public string Status { get; set; }
        public string Requesttype { get; set; }
        public string MMISType { get; set; }
        public DateTime Created { get; set; }
        public string PrivacyReqFile { get; set; }
    }
}
