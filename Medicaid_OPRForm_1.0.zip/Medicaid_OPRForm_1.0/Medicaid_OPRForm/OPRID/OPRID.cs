﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;

namespace Medicaid_OPRForm.OPRID
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class OPRID : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);

            if (properties.ListTitle == "Scan List")
            {
                using (SPWeb oWebsite = properties.OpenWeb())
                //using (SPWeb oWebsite = oSite.OpenWeb())
                {
                    SPList _spList = oWebsite.Lists["Scan List"];
                    SPQuery query = new SPQuery();
                    query.RowLimit = 1;
                    query.Query = "<OrderBy><FieldRef Name='ID' Ascending='FALSE' /></OrderBy>";
                    //query.Query = "<OrderBy><FieldRef Name='OPR_Test' Ascending='FALSE' /></OrderBy>";
                    int LastItem = 0;

                    SPListItemCollection listItemCollection = _spList.GetItems(query);
                    if (listItemCollection.Count > 0)
                    {
                        foreach (SPListItem item in listItemCollection)
                        {
                            string ListID = item["OPR_Test"].ToString();

                            if (ListID != null)
                            {
                                string dtTemp = ListID.ToString();
                                string dt = dtTemp.Substring(9, 2);
                                string month = dtTemp.Substring(7, 2);
                                string year = dtTemp.Substring(4, 2);
                                string ID = dtTemp.Substring(12, 2);
                                string s = year + "-" + month + "-" + dt;
                                DateTime dt3 = DateTime.ParseExact(s, "yy-MM-dd", null);
                                string finalID = "";
                                string CompleteID = "";
                                if (LastItem == 0)
                                {
                                    LastItem = Convert.ToInt32(ID);
                                }
                                if (DateTime.Now.ToShortDateString() == dt3.ToShortDateString())
                                {
                                    if (ID != "01")
                                    {
                                        if (Convert.ToInt32(LastItem) - Convert.ToInt32(ID) == 1)
                                        {
                                            LastItem = Convert.ToInt32(ID);
                                        }
                                        else
                                        {
                                            finalID = AppendID(Convert.ToInt32(LastItem) - 1).ToString();
                                            CompleteID = year + "-" + month + dt + "-" + finalID;
                                            break;
                                        }
                                    }
                                }
                                else
                                {
                                    finalID = "01";
                                    int cYear = System.DateTime.Now.Year;
                                    int cMonth = System.DateTime.Now.Month;
                                    int cDt = System.DateTime.Now.Day;
                                    CompleteID = cYear.ToString().Substring(2, 2) + "-" + AppendID(cMonth) + AppendID(cDt) + "-" + finalID;
                                }
                                properties.AfterProperties["OPR_Test"] = "OPR-" + CompleteID;
                            }
                            else
                            {

                            }
                        }
                    }
                    else
                    {
                        string finalIDNew = "01";
                        int cYear = System.DateTime.Now.Year;
                        int cMonth = System.DateTime.Now.Month;
                        int cDt = System.DateTime.Now.Day;
                        string CompleteIDNew = cYear.ToString().Substring(2, 2) + "-" + AppendID(cMonth) + AppendID(cDt) + "-" + finalIDNew;
                        properties.AfterProperties["OPR_Test"] = "OPR-" + CompleteIDNew;
                    }
                }
            }
        }
            protected string AppendID(int ID)
            {
                string _id = "";
                if (ID.ToString().Length != 2)
                {
                    _id = "0" + ID;
                }
                else
                {
                    _id = ID.ToString();
                }
                return _id;
            }
        }
    }
