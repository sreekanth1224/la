﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace Medicaid_OPRForm.Layouts.Medicaid_OPRForm
{
    public partial class OPRDueDate_Update : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
