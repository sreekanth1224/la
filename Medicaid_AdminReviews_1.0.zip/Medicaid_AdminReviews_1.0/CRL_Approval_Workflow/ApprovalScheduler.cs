﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Administration;
using Microsoft.SharePoint;
using System.Collections.Specialized;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;
using System.Data;
using System.IO;
using System.Net;

namespace CRL_Approval_Workflow
{
    class ApprovalScheduler : SPJobDefinition
    {
        public ApprovalScheduler() : base() { }

        public ApprovalScheduler(SPWebApplication webApp)
            : base("TimerJob", webApp, null, SPJobLockType.ContentDatabase)
        {
            this.Title = "TimerJob";
        }

        public ApprovalScheduler(string jobName, SPService service, SPServer server, SPJobLockType targetType)
            : base(jobName, service, server, targetType)
        {

        }

        public ApprovalScheduler(string jobName, SPWebApplication webApplication)
            : base(jobName, webApplication, null, SPJobLockType.None)
        {
            this.Title = jobName;
        }

        public override void Execute(Guid targetInstanceId)
        {
            GetPendingCRLs();
        }

        public void GetPendingCRLs()
        {
            String approverBody = string.Empty;
            String typistBody = string.Empty;
            List<String> assigneeEmailList = new List<String>();
            List<Int32> CRLIDList = new List<Int32>();
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["syssupport"];
            SPList scanOPRLib = currentWeb.Lists["Customer Review Log"];
            SPQuery camlQuery = new SPQuery();
            camlQuery.Query = "<Where>" +
                                  "<Eq>" +
                                    "<FieldRef Name='EmailSent'/>" +   //EmailSent 'No'
                                    "<Value Type='Boolean'>0</Value>" +
                                  "</Eq>" +
                              "</Where>";
            SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);
            //Get Assignee Email List
            SPList emailList = currentWeb.Lists["AssignmentGroup"];
            SPQuery camlQueryAssignee = new SPQuery();
            SPListItemCollection itemCollAssignee = emailList.GetItems(camlQueryAssignee);
            if(itemCollAssignee != null && itemCollAssignee.Count > 0)
            {
                foreach(SPListItem item in itemCollAssignee)
                {
                    assigneeEmailList.Add(Convert.ToString(item["Email"]));
                }
            }

            if (itemColl != null && itemColl.Count > 0)
            {
                String siteUrl = currentWeb.Site.Url;
                String workflowURL = siteUrl + "/syssupport/SitePages/Workflow.aspx";
                foreach (SPListItem item in itemColl)
                {
                    CRLIDList.Add(Convert.ToInt32(item["ID"]));
                }
                approverBody = "<div class='divContainer'>";
                approverBody += "<div><b>Hi,<br/> Please find all the assigned OPRs below</b></div><br/>";
                approverBody += "<div><b><I>Pending OPRs:</I></b><br/></div><br/>";
                approverBody += "<div class='divMessage'><a href=" + workflowURL + ">Click here to proceed</a></div>";
                approverBody += "</div>";
                SendEmail(assigneeEmailList, approverBody, "OPR-Approvals"); 
                //Change EmailStatus & Assignee to true once email is sent
                UpdateEmailStatus(CRLIDList);
            }
        }

        public void SendEmail(List<String> emailToEmailAddress, String emailBody, String emailSubject)
        {
            try
            {
                String smtpServer = SPAdministrationWebApplication.Local.OutboundMailServiceInstance.Server.Address;
                //String smtpServer = "10.131.89.54";
                MailMessage mailMessage = new MailMessage();
                foreach (String emailAddress in emailToEmailAddress)
                {
                    mailMessage.To.Add(new MailAddress(emailAddress.Split('#')[1]));
                }
                mailMessage.From = new MailAddress("no-reply@medicaid.alabama.gov");
                mailMessage.Subject = emailSubject;
                mailMessage.Body = emailBody;
                mailMessage.IsBodyHtml = true;
                SmtpClient smtpClient = new SmtpClient(smtpServer);
                smtpClient.Send(mailMessage);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void UpdateEmailStatus(List<Int32> OPRIDList)
        {
            SPWebApplication webApp = this.Parent as SPWebApplication;
            SPWeb currentWeb = webApp.Sites["teams/FiscalAgent"].AllWebs["syssupport"];
            SPList CRLList = currentWeb.Lists["Customer Review Log"];
            foreach (Int32 OPRID in OPRIDList)
            {
                SPListItem CRLListItem = CRLList.GetItemById(OPRID);
                CRLListItem["EmailSent"] = true;
                //CRLListItem["AssigneeUpdated"] = "Not Assigned";
                CRLList.Update();
            }
        }
    }
}
