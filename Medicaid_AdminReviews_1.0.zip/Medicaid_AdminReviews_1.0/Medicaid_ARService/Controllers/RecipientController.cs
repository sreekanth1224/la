﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Medicaid_ARService.Controllers
{
    public class RecipientController : ApiController
    {
        SqlDataReader dr;
        List<String> recipientList = new List<String>();
        string strConn = ConfigurationManager.ConnectionStrings["connString"].ConnectionString;
        public List<String> Get(String recipientName)
        {
            using (SqlConnection con = new SqlConnection(strConn))
            {
                using (SqlCommand cmd = new SqlCommand())
                {
                    try
                    {
                        cmd.CommandText = "GetRecipientNameList";
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Connection = con;
                        cmd.Parameters.AddWithValue("@recipientName", recipientName);
                        if (cmd.Connection.State == ConnectionState.Closed)
                        {
                            con.Open();
                        }
                        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection);
                        if (dr.HasRows)
                        {
                            while (dr.Read())
                            {
                                recipientList.Add(dr["MEDICAID-FULL_NAME"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }
                }
            }
            return recipientList;
        }
    }
}
