﻿using Microsoft.SharePoint;
//using Microsoft.SharePoint.Client;
//using Microsoft.SharePoint.Client.UserProfiles;
using System;
using System.ComponentModel;
using System.Net;
using System.Web.UI.WebControls.WebParts;
//using System.Collections.Generic;
//using Microsoft.SharePoint.Administration.Claims;
//using System.Web;
//using System.IO;
using System.Web.UI.WebControls;
using System.Data;

namespace Medicaid_AdminReview.CRLAssigneeWorkflow
{
    [ToolboxItemAttribute(false)]
    public partial class CRLAssigneeWorkflow : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]

        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";

        public CRLAssigneeWorkflow()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                lblSuccessMsg.Text = String.Empty;
                lblApprovalmsg.Text = String.Empty;
                GetNewCRLItems();
            }
        }

        public void GetNewCRLItems()
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList scanOPRLib = currentWeb.Lists["Customer Review Log"];
                    SPQuery camlQuery = new SPQuery();
                    camlQuery.Query = "<Where>" +
                                        "<And>" +
                                         "<Eq>" +
                                           "<FieldRef Name='AssigneeUpdated'/>" +
                                           "<Value Type='Text'>Not Assigned</Value>" +
                                         "</Eq>" +
                                          "<IsNull>" +
                                                    "<FieldRef Name='voidReason'/>" +
                                          "</IsNull>" +
                                         "</And>" +
                                     "</Where>" +
                                     "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                    SPListItemCollection itemColl = scanOPRLib.GetItems(camlQuery);

                    if (itemColl != null && itemColl.Count > 0)
                    {
                        gvWorkflowItems.DataSource = itemColl.GetDataTable();
                        gvWorkflowItems.DataBind();
                    }
                    else
                    {
                        gvWorkflowItems.DataSource = null;
                        gvWorkflowItems.DataBind();
                    }
                }
            }
        }

        //protected void btnSubmit_Click(object sender, EventArgs e)
        //{
            
        //}

        public void UpdateListItem(Int32 itemID, String assignedStatus, String Assignee)
        {
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    SPList CRLList = currentWeb.Lists["Customer Review Log"];
                    SPListItem CRLListItem = CRLList.GetItemById(itemID);
                    CRLListItem["AssignedTo"] = Assignee;
                    CRLListItem["AssigneeUpdated"] = assignedStatus;
                    CRLListItem.Update();
                    lblSuccessMsg.Text="Updated successfully";
                }
            }
        }

        //protected void gvWorkflowItems_DataBound(object sender, EventArgs e)
        //{

        //}

        protected void gvWorkflowItems_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView rowView = e.Row.DataItem as DataRowView;
                DropDownList ddlAssignee = (DropDownList)e.Row.FindControl("ddlAssignee");
                ddlAssignee.DataSource = GetAssignedToList().GetDataTable();
                ddlAssignee.DataTextField = "Title";
                ddlAssignee.DataValueField = "Title";
                ddlAssignee.DataBind();
                ddlAssignee.Items.Insert(0, "Select");
                ddlAssignee.SelectedValue = Convert.ToString(rowView["Title"]);
            }
        }

        public SPListItemCollection GetAssignedToList()
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["AssignedTo"];
                        SPQuery query = new SPQuery();
                        query.Query = "<OrderBy><FieldRef Name='Title'/></OrderBy>";
                        listColl = CRLogList.GetItems(query);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        protected void btnSubmit_Click1(object sender, EventArgs e)
        {
            String errorMessage = String.Empty;
            Int32 count = 0;
            lblSuccessMsg.Text = errorMessage;
            lblApprovalmsg.Text = errorMessage;
            foreach (GridViewRow row in gvWorkflowItems.Rows)
            {
                DropDownList ddlAssignee = row.FindControl("ddlAssignee") as DropDownList;
                Label lblID = row.FindControl("lblID") as Label;
                if (ddlAssignee.SelectedValue != "Select")
                {
                    UpdateListItem(Convert.ToInt32(lblID.Text), "Assignee Edited", ddlAssignee.SelectedItem.Text);
                    count++;
                }
            }
            if (count == 0)
            {
                lblSuccessMsg.Text = String.Empty;
                lblApprovalmsg.Text = "Please select Assigned To";
            }
            GetNewCRLItems();
        }
    }
}
