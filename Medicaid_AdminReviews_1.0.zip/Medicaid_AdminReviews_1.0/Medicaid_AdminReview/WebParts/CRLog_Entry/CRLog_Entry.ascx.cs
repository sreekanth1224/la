﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using System.Linq;

namespace Medicaid_AdminReview.WebParts.CRLog_Entry
{
    [ToolboxItemAttribute(false)]
    public partial class CRLog_Entry : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        public CRLog_Entry()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        Int32 pageIndex = 0;    //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String pageInfo = String.Empty;
        DateTime searchDate = DateTime.Now;
        SPListItemCollection listColl = null;
        SPListItemCollectionPosition itemPoistion = null;
        SPListItemCollectionPosition oPos = null;
        String prevPageInfo = null;
        String nextPageInfo = null;
        String idList = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                String todaysDate = DateTime.Today.ToShortDateString();
                txtDateIn.Text = todaysDate;
                GetCurrentDayItems(todaysDate, todaysDate, txtSearchCRLID.Text, null, null);
            }
        }

        public String GetLogEntryID()
        {
            String CRLogID = String.Empty;
            DateTime todaysDate = DateTime.Now.Date;
            int CRLID = 0;
            String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2018
            String MonthFormat = String.Empty;
            String latestCRLID = GetMostRecentItem(todaysDate.ToShortDateString());
            if (latestCRLID != "0")
            {
                CRLogID = latestCRLID.Substring(latestCRLID.LastIndexOf('-') + 1);
                CRLID = Convert.ToInt32(CRLogID) + 1;
                CRLogID = "CRL-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + CRLID;
            }
            else
            {
                CRLogID = "CRL-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + "1";
            }
            return CRLogID;
        }

        public String GetMostRecentItem(String todaysDate)
        {
            String latestCRLID = String.Empty;
            String strQuery = String.Empty;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        DateTime currentDate = new DateTime().Date;
                        currentDate = DateTime.Parse(todaysDate);
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        strQuery = "<Where>" +
                                        "<Eq>" +
                                            "<FieldRef Name='Created'/>" +
                                            "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(currentDate) + "</Value>" +
                                        "</Eq>" +
                                    "</Where>";
                        query.Query = strQuery +
                                        "<OrderBy>" +
                                           "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                        "</OrderBy>";
                        query.ViewFields = String.Concat(
                                            "<FieldRef Name='ID' />",
                                            "<FieldRef Name='Title' />",
                                            "<FieldRef Name='CRLID' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        query.RowLimit = 1;
                        SPListItemCollection listColl = CRLogList.GetItems(query);
                        if (listColl != null && listColl.Count > 0)
                        {
                            latestCRLID = Convert.ToString(listColl[0]["CRLID"]);
                        }
                        else
                        {
                            latestCRLID = "0";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return latestCRLID;
        }

        public void SaveCRLogEntry()
        {
            try
            {
                String errorMessage = String.Empty;
                DateTime tempFirstDateOfService;
                DateTime tempLastDateOfService;
                DateTime tempDateIn;
                DateTime tempDateOut;
                bool isFirstDateValid = (txtFirstDateOfService.Text.Length == 0) ? true : DateTime.TryParseExact(txtFirstDateOfService.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempFirstDateOfService);
                bool isLastDateValid = (txtLastDateOfService.Text.Length == 0) ? true : DateTime.TryParseExact(txtLastDateOfService.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempLastDateOfService);
                bool isDateInValid = (txtDateIn.Text.Length == 0) ? true : DateTime.TryParseExact(txtDateIn.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempDateIn);
                bool isDateOutValid = (txtDateOut.Text.Length == 0) ? true : DateTime.TryParseExact(txtDateOut.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempDateOut);

                if (txtProvider.Text == "")
                {
                    errorMessage = "Please select Provider";
                }
                else if (txtProvider.Text == "No match found")
                {
                    errorMessage = "Please select Provider - No match found is invalid";
                }
                else if (!Regex.IsMatch(txtProvider.Text, @"^[1]\d{9}-S*"))
                {
                    errorMessage = "Please enter Provider in the correct format";
                }
                else if (txtRecipientName.Text == "")
                {
                    errorMessage = "Please select Recipient";
                }
                else if (txtRecipientName.Text == "No match found")
                {
                    errorMessage = "Please select Recipient - No match found is invalid";
                }
                else if (!Regex.IsMatch(txtRecipientName.Text, @"^[5]\d{11}-S*"))
                {
                    errorMessage = "Please enter Recipient Name in the correct format";
                }
                else if (txtFirstDateOfService.Text == "")
                {
                    errorMessage = "Please enter First Date of Service";
                }
                else if (txtLastDateOfService.Text == "")
                {
                    errorMessage = "Please enter Last Date of Service";
                }
                else if (!isFirstDateValid)
                {
                    errorMessage = "Please enter valid First Date of Service";
                }
                else if (!isLastDateValid)
                {
                    errorMessage = "Please enter valid Last Date of Service";
                }
                else if (txtDateIn.Text == "")
                {
                    errorMessage = "Please select Date in";
                }
                else if (!isDateInValid)
                {
                    errorMessage = "Please enter valid Date In";
                }
                else if (!isDateOutValid)
                {
                    errorMessage = "Please enter valid Date out";
                }
                else if (txtAssignedTo.Text == "No match found")
                {
                    errorMessage = "Please select Assigned To - No match found is invalid";
                }
                else if (!String.IsNullOrEmpty(txtFirstDateOfService.Text) && !String.IsNullOrEmpty(txtLastDateOfService.Text))
                {
                    if (Convert.ToDateTime(txtLastDateOfService.Text) < Convert.ToDateTime(txtFirstDateOfService.Text))
                    {
                        errorMessage = "Date of Service To should be equal or greater than Date of Service From";
                    }
                }

                if (String.IsNullOrEmpty(errorMessage))
                {
                    String CRLogID = GetLogEntryID();
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList CRLogList = web.Lists["Customer Review Log"];
                            SPListItemCollection listItems = CRLogList.Items;
                            SPListItem item = listItems.Add();
                            item["Title"] = CRLogID;
                            item["CRLID"] = CRLogID;
                            item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                            item["Provider"] = txtProvider.Text;
                            item["ReceipientName"] = txtRecipientName.Text;
                            item["FirstDateofService"] = Convert.ToDateTime(txtFirstDateOfService.Text);
                            item["LastDateofService"] = Convert.ToDateTime(txtLastDateOfService.Text);
                            item["AssignedTo"] = txtAssignedTo.Text;
                            item["Result"] = txtResult.Text;
                            if (!(String.IsNullOrEmpty(txtDateOut.Text)))
                            {
                                item["DateOut"] = Convert.ToDateTime(txtDateOut.Text);
                            }
                            if (txtAssignedTo.Text == "")
                            {
                                item["AssigneeUpdated"] = "Not Assigned";
                            }
                            else
                            {
                                item["AssigneeUpdated"] = "Assigned";
                            }

                            item.Update();
                            clearentrydetails();
                            lblErrorMessage.Text = String.Empty;
                        }
                    }
                }
                else
                {
                    lblErrorMessage.Text = errorMessage;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetCurrentDayItems(String startDate, String endDate, String searchText, SPListItemCollectionPosition itemPoistion, String paging)
        {
            try
            {
                Int32 recordsPerPage = Convert.ToInt32(ddlRecordsPerPage.SelectedValue);
                String strQuery = String.Empty;
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPGroup spGroup = web.SiteGroups["Systems Support Owners"];
                        SPUser currentUser = web.CurrentUser;
                        lblUser.Text = currentUser.Name;
                        lblGroup.Text = currentUser.Groups.Cast<SPGroup>().Any(g => g.Name.Equals(spGroup.Name)).ToString();
                        DateTime searchStartDate = new DateTime().Date;
                        DateTime searchEndDate = new DateTime().Date;
                        if (!String.IsNullOrEmpty(startDate))
                        {
                            searchStartDate = DateTime.Parse(startDate);
                        }
                        if (!String.IsNullOrEmpty(endDate))
                        {
                            searchEndDate = DateTime.Parse(endDate);
                        }
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        itemCount = CRLogList.ItemCount;
                        totalPages = itemCount / recordsPerPage;
                        #region CamlQuery
                        SPQuery query = new SPQuery();
                        if (!String.IsNullOrEmpty(startDate) && !String.IsNullOrEmpty(endDate) && !String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='CRLID'/>" +
                                                          "<Value Type='Text'>" + searchText + "</Value>" +
                                                     "</Contains>" +
                                                 "<And>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                     "</Geq>" +
                                                      "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                     "</Leq>" +
                                                  "</And>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(startDate) && !String.IsNullOrEmpty(endDate) && String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                "</Geq>" +
                                                 "<Leq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                "</Leq>" +
                                            "</And>" +
                                        "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(startDate) && String.IsNullOrEmpty(endDate) && !String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='CRLID'/>" +
                                                          "<Value Type='Text'>" + searchText + "</Value>" +
                                                     "</Contains>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                     "</Geq>" +
                                                  "</And>" +
                                         "</Where>";

                        }
                        else if (String.IsNullOrEmpty(startDate) && !String.IsNullOrEmpty(endDate) && !String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='CRLID'/>" +
                                                          "<Value Type='Text'>" + searchText + "</Value>" +
                                                     "</Contains>" +
                                                     "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                     "</Leq>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (String.IsNullOrEmpty(startDate) && String.IsNullOrEmpty(endDate) && !String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                           "<Contains>" +
                                                "<FieldRef Name='CRLID'/>" +
                                                 "<Value Type='Text'>" + searchText + "</Value>" +
                                            "</Contains>" +
                                       "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(startDate) && String.IsNullOrEmpty(endDate) && String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                                 "<Geq>" +
                                                      "<FieldRef Name='DateIn'/>" +
                                                      "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                 "</Geq>" +
                                                "</Where>";
                        }
                        else if (String.IsNullOrEmpty(startDate) && !String.IsNullOrEmpty(endDate) && String.IsNullOrEmpty(searchText))
                        {
                            strQuery = "<Where>" +
                                                 "<Leq>" +
                                                      "<FieldRef Name='Created'/>" +
                                                      "<Value Type='DateTime' IncludeTimeValue='False'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                 "</Leq>" +
                                                "</Where>";
                        }

                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.RowLimit = Convert.ToUInt32(recordsPerPage);
                        query.DatesInUtc = false;
                        query.ViewFields = String.Concat(
                             "<FieldRef Name='ID' />",
                            "<FieldRef Name='Title' />",
                                  "<FieldRef Name='CRLID' />",
                                    "<FieldRef Name='Provider' />",
                                    "<FieldRef Name='ReceipientName' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateOut' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='FirstDateofService' />",
                                    "<FieldRef Name='LastDateofService' />",
                                    "<FieldRef Name='CRLStatus' />",
                                    "<FieldRef Name='voidReason' />",
                                    "<FieldRef Name='Author' />",
                                    "<FieldRef Name='Result' />");
                        query.ViewFieldsOnly = true;
                        query.ListItemCollectionPosition = itemPoistion;
                        listColl = CRLogList.GetItems(query);
                        #endregion

                        if (listColl != null && listColl.Count > 0)
                        {
                            itemPoistion = listColl.ListItemCollectionPosition;
                            if (itemPoistion != null)
                            {
                                nextPageInfo = itemPoistion.PagingInfo;
                                ViewState["next"] = nextPageInfo;
                            }

                            DataView view = listColl.GetDataTable().DefaultView;
                            DataTable sortedCRLTable = view.ToTable();
                            ViewState["ScanList"] = sortedCRLTable;
                            grvCRLDailyView.PageSize = recordsPerPage;
                            grvCRLDailyView.DataSource = sortedCRLTable;
                            grvCRLDailyView.DataBind();
                        }
                        else
                        {
                            grvCRLDailyView.DataSource = null;
                            grvCRLDailyView.DataBind();
                        }
                        ManagePageControl(paging);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //return listColl;
        }

        public void ManagePageControl(String paging)
        {
            if (ViewState["pageIndex"] != null)
            {
                pageIndex = Convert.ToInt32(ViewState["pageIndex"]);
                if (pageIndex == 0)
                {
                    btnPrevious.Enabled = false;
                    btnPrevious.CssClass = "btnGreyedOut";
                }
                else
                {
                    btnPrevious.Enabled = true;
                    btnPrevious.CssClass = "btnSave";
                }
                if (listColl.ListItemCollectionPosition == null)
                {
                    btnNext.Enabled = false;
                    btnNext.CssClass = "btnGreyedOut";
                }
                else
                {
                    btnNext.Enabled = true;
                    btnNext.CssClass = "btnSave";
                }

            }
            else
            {
                if (listColl.Count < Convert.ToInt32(ddlRecordsPerPage.SelectedValue))
                {
                    btnNext.Enabled = false;
                    btnNext.CssClass = "btnGreyedOut";
                    btnPrevious.Enabled = false;
                    btnPrevious.CssClass = "btnGreyedOut";


                }
                else
                {
                    btnNext.Enabled = true;
                    btnNext.CssClass = "btnSave";
                    btnPrevious.Enabled = true;
                    btnPrevious.CssClass = "btnSave";
                }
                btnPrevious.Enabled = false;
                btnPrevious.CssClass = "btnGreyedOut";
            }
            //ViewState["next"] = null;
            //if (listColl.ListItemCollectionPosition != null)
            //{
            //    nextPageInfo = listColl.ListItemCollectionPosition.PagingInfo;
            //    ViewState["next"] = nextPageInfo;
            //}
            //if (ViewState["IDList"] != null)
            //{
            //    pageIndex = Convert.ToInt32(ViewState["pageIndex"]);
            //    if (pageIndex > 0)
            //    {
            //        idList = ViewState["IDList"].ToString().Remove(ViewState["IDList"].ToString().LastIndexOf(';'), 1).ToString();
            //        if (idList.Contains(";"))
            //        {
            //            ViewState["ID"] = ViewState["IDList"].ToString().Split(';')[pageIndex - 1];
            //        }
            //        else
            //        {
            //            ViewState["ID"] = idList;
            //        }
            //        prevPageInfo = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}", Convert.ToString(ViewState["ID"]));
            //    }
            //    else
            //    {
            //        ViewState["ID"] = ViewState["IDList"].ToString().Split(';')[0];
            //        prevPageInfo = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}", Convert.ToString(ViewState["ID"]));

            //    }
            //}
            //else if (ViewState["ID"] != null)
            //{
            //    prevPageInfo = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}", Convert.ToString(ViewState["ID"]));
            //}

            //ViewState["prev"] = prevPageInfo;
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            SaveCRLogEntry();
            String todaysDate = DateTime.Today.ToShortDateString();
            txtDateIn.Text = todaysDate;
            GetCurrentDayItems(todaysDate, todaysDate, txtSearchCRLID.Text, null, null);
        }

        public void clearentrydetails()
        {
            String todaysDate = DateTime.Today.ToShortDateString();
            txtAssignedTo.Text = string.Empty;
            txtDateIn.Text = todaysDate;
            txtDateOut.Text = string.Empty;
            txtFirstDateOfService.Text = string.Empty;
            txtLastDateOfService.Text = string.Empty;
            txtResult.Text = string.Empty;
            txtProvider.Text = string.Empty;
            txtRecipientName.Text = string.Empty;
            lblErrorMessage.Text = string.Empty;
            txtStartDate.Text = string.Empty;
            txtEndDate.Text = string.Empty;
            Page.Response.Redirect(siteUrl + "SitePages/Customer Review Log Entry.aspx");
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clearentrydetails();
        }

        protected void grvCRLDailyView_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            //bool IsRecordSaved = false;
            btnSave.Visible = true;
            GridViewRow row = grvCRLDailyView.Rows[e.RowIndex];
            Label lblID = (Label)row.FindControl("lblID");
            TextBox txtEditProvider = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditProvider");
            TextBox txtEditReceipientName = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditReceipientName");
            TextBox txtEditFirstDateofService = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditFirstDateofService");
            TextBox txtEditLastDateofService = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditLastDateofService");
            TextBox txtEditAssignedTo = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditAssignedTo");
            TextBox txtEditResult = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditResult");
            TextBox txtEditDateIn = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditDateIn");
            TextBox txtEditDateOut = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditDateOut");

            TextBox txtInfo = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtVoidInfo");
            DateTime tempEditFirstDateOfService;
            DateTime tempEditLastDateOfService;
            DateTime tempEditDateIn;
            DateTime tempEditDateOut;
            bool iseditFirstDateValid = (txtEditFirstDateofService.Text.Length == 0) ? true : DateTime.TryParseExact(txtEditFirstDateofService.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEditFirstDateOfService);
            bool iseditLastDateValid = (txtEditLastDateofService.Text.Length == 0) ? true : DateTime.TryParseExact(txtEditLastDateofService.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEditLastDateOfService);
            bool iseditDateInValid = (txtEditDateIn.Text.Length == 0) ? true : DateTime.TryParseExact(txtEditDateIn.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEditDateIn);
            bool iseditDateOutValid = (txtEditDateOut.Text.Length == 0) ? true : DateTime.TryParseExact(txtEditDateOut.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEditDateOut);

            String errorMessage = String.Empty;

            if (txtEditProvider.Text == "")
            {
                errorMessage = "Please Enter Provider";
            }
            else if (txtEditProvider.Text == "No match found")
            {
                errorMessage = "Please Enter Provider - No match found";
            }
            else if (txtEditReceipientName.Text == "")
            {
                errorMessage = "Please Enter Recipient";
            }
            else if (txtEditReceipientName.Text == "No match found")
            {
                errorMessage = "Please Enter Recipient - No match found";
            }
            else if (txtEditAssignedTo.Text == "No match found")
            {
                errorMessage = "Please select Assigned To - No match found is invalid";
            }
            else if (txtEditFirstDateofService.Text == "")
            {
                errorMessage = "Please enter First Date of Service";
            }
            else if (!iseditFirstDateValid)
            {
                errorMessage = "Please enter valid First Date of Service";
            }
            else if (!iseditLastDateValid)
            {
                errorMessage = "Please enter valid Last Date of Service";
            }
            else if (!iseditDateInValid)
            {
                errorMessage = "Please enter valid DateIn";
            }
            else if (!iseditDateOutValid)
            {
                errorMessage = "Please enter valid Date out";
            }
            else if (txtEditLastDateofService.Text == "")
            {
                errorMessage = "Please enter Last Date of Service";
            }
            else if (!String.IsNullOrEmpty(txtEditDateIn.Text) && !String.IsNullOrEmpty(txtEditDateOut.Text))
            {
                if (Convert.ToDateTime(txtEditDateOut.Text) < Convert.ToDateTime(txtEditDateIn.Text))
                {
                    errorMessage = "Date out should be equal or greater than Date in";
                }
            }
            if (txtInfo.Visible && txtInfo.Text.Length == 0)
            {
                errorMessage = "Please enter void reason";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPListItem item = CRLogList.GetItemById(Convert.ToInt32(lblID.Text));
                        item["DateIn"] = Convert.ToDateTime(txtEditDateIn.Text);
                        item["Provider"] = txtEditProvider.Text;
                        item["ReceipientName"] = txtEditReceipientName.Text;
                        item["FirstDateofService"] = Convert.ToDateTime(txtEditFirstDateofService.Text);
                        item["LastDateofService"] = Convert.ToDateTime(txtEditLastDateofService.Text);
                        item["AssignedTo"] = txtEditAssignedTo.Text;
                        item["Result"] = txtEditResult.Text;
                        item["voidReason"] = txtInfo.Text;
                        if (txtInfo.Text.Length != 0) // CRL Status to 'true' - only on Void condition
                        {
                            item["CRLStatus"] = "true";
                        }
                        if (!(String.IsNullOrEmpty(txtEditDateOut.Text)))
                        {
                            item["DateOut"] = Convert.ToDateTime(txtEditDateOut.Text);
                        }
                        if (txtEditAssignedTo.Text == "")
                        {
                            item["AssigneeUpdated"] = "Not Assigned";

                        }
                        else
                        {
                            item["AssigneeUpdated"] = "Assignee Edited";
                        }

                        item.Update();
                        lblErrorMessage.Text = String.Empty;
                        grvCRLDailyView.EditIndex = -1;

                        String queriedStartDate = DateTime.Today.ToShortDateString();
                        String queriedEndDate = DateTime.Today.ToShortDateString();
                        if (txtStartDate.Text.Length > 0)
                        {
                            queriedStartDate = txtStartDate.Text;
                        }
                        if (txtEndDate.Text.Length > 0)
                        {
                            queriedEndDate = txtEndDate.Text;
                        }
                        GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchCRLID.Text, null, null);
                    }
                    //IsRecordSaved = true;
                }
                //else
                //{
                //    IsRecordSaved = false;
                //    lblErrorMessage.Text = errorMessage;
                //}                
            }
            else
            {
                //IsRecordSaved = false;
                lblErrorMessage.Text = errorMessage;
            }

        }

        protected void grvCRLDailyView_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grvCRLDailyView.EditIndex = e.NewEditIndex;
            DataTable sortedCRLTable = (DataTable)ViewState["ScanList"];
            grvCRLDailyView.DataSource = sortedCRLTable;
            grvCRLDailyView.DataBind();
            if (Convert.ToString(sortedCRLTable.Rows[e.NewEditIndex]["Author"]) == lblUser.Text || lblGroup.Text == "True")
            {
                grvCRLDailyView.Rows[e.NewEditIndex].Cells[0].Enabled = true;
                grvCRLDailyView.Rows[e.NewEditIndex].FindControl("lnkVoid").Visible = true;
            }
            txtProvider.Enabled = true;
        }

        protected void grvCRLDailyView_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grvCRLDailyView.EditIndex = -1;
            TextBox txtEditDateIn = (TextBox)grvCRLDailyView.Rows[e.RowIndex].FindControl("txtEditDateIn");
            GetCurrentDayItems(txtEditDateIn.Text, txtEditDateIn.Text, txtSearchCRLID.Text, null, null);
            lblErrorMessage.Text = "";

        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            DateTime tempStartDate;
            DateTime tempEndDate;
            bool isStartDateValid = (txtStartDate.Text.Length == 0) ? true : DateTime.TryParseExact(txtStartDate.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempStartDate);
            bool isEndDateValid = (txtEndDate.Text.Length == 0) ? true : DateTime.TryParseExact(txtEndDate.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEndDate);
            String errorMessage = String.Empty;
            if (isStartDateValid && isEndDateValid)
            {
                if (!String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text))
                {
                    if (Convert.ToDateTime(txtEndDate.Text) < Convert.ToDateTime(txtStartDate.Text))
                    {
                        //grvCRLDailyView.Visible = false;
                        errorMessage = "End Date should be equal or greater than Start Date";
                    }
                }
            }
            else
            {
                //Page.Response.Redirect(siteUrl + "SitePages/Customer Review Log Entry.aspx");
                errorMessage = "Please enter valid Start/End date";
            }

            if (String.IsNullOrEmpty(errorMessage))
            {
                lblErrorMessage.Text = String.Empty;
                GetCurrentDayItems(txtStartDate.Text, txtEndDate.Text, txtSearchCRLID.Text, null, null);
            }
            else
            {
                grvCRLDailyView.DataSource = null;
                grvCRLDailyView.DataBind();
                lblErrorMessage.Text = errorMessage;
            }

        }

        protected void grvCRLDailyView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView rowView = e.Row.DataItem as DataRowView;
                if (Convert.ToString(rowView["CRLStatus"]) == "1")
                {
                    e.Row.Cells[0].Controls[0].Visible = false;
                }
                if (!String.IsNullOrEmpty(Convert.ToString(rowView["voidReason"])))
                {
                    Label lblVoided = e.Row.FindControl("lblVoided") as Label;
                    lblVoided.Visible = true;
                    e.Row.Cells[0].Controls[0].Visible = false;

                }
            }
        }

        protected void ddlRecordsPerPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            ViewState["pageIndex"] = null;
            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = null;
            }
            if (txtEndDate.Text.Length > 0 && txtStartDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length == 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = null;
            }

            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchCRLID.Text, null, null);
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            oPos = null;
            Label lblID = (Label)grvCRLDailyView.Rows[0].FindControl("lblID");
            Label lblCRLID = (Label)grvCRLDailyView.Rows[0].FindControl("lblCRLID");
            if (ViewState["pageIndex"] != null)
            {
                pageIndex = Convert.ToInt32(ViewState["pageIndex"]);
                ViewState["pageIndex"] = pageIndex - 1;
            }

            if (ViewState["itemID"] != null && pageIndex != 1)
            {
                prevPageInfo = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}&p_Title={1}&PageLastRow={2}",
                                Convert.ToString(ViewState["itemID"]), Convert.ToString(lblCRLID.Text), (pageIndex * Convert.ToInt32(ddlRecordsPerPage.SelectedValue)));
                ViewState["itemID"] = lblID.Text;
                oPos = new SPListItemCollectionPosition(prevPageInfo);
            }

            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = null;
            }
            if (txtEndDate.Text.Length > 0 && txtStartDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length == 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = null;
            }

            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchCRLID.Text, oPos, "prev");
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            if (ViewState["pageIndex"] != null)
            {
                ViewState["pageIndex"] = Convert.ToInt32(ViewState["pageIndex"]) + 1;
            }
            else
            {
                ViewState["pageIndex"] = pageIndex + 1;
            }
            Label lblID = (Label)grvCRLDailyView.Rows[0].FindControl("lblID");
            ViewState["itemID"] = lblID.Text;
            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length > 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = txtStartDate.Text;
                queriedEndDate = null;
            }
            if (txtEndDate.Text.Length > 0 && txtStartDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = txtEndDate.Text;
            }
            if (txtStartDate.Text.Length == 0 && txtEndDate.Text.Length == 0)
            {
                queriedStartDate = null;
                queriedEndDate = null;
            }
            pageInfo = ViewState["next"] as String;

            if (!String.IsNullOrEmpty(pageInfo))
            {
                oPos = new SPListItemCollectionPosition(pageInfo);
            }
            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchCRLID.Text, oPos, "next");
        }

        protected void grvCRLDailyView_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Void")
            {
                int index = Convert.ToInt32(e.CommandArgument.ToString());
                TextBox txtInfo = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtVoidInfo");
                txtInfo.Visible = true;

                TextBox txtEditProvider = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditProvider");
                txtEditProvider.Enabled = false;
                TextBox txtEditReceipientName = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditReceipientName");
                txtEditReceipientName.Enabled = false;
                TextBox txtEditFirstDateofService = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditFirstDateofService");
                txtEditFirstDateofService.Enabled = false;
                TextBox txtEditLastDateofService = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditLastDateofService");
                txtEditLastDateofService.Enabled = false;
                TextBox txtEditAssignedTo = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditAssignedTo");
                txtEditAssignedTo.Enabled = false;
                TextBox txtEditResult = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditResult");
                txtEditResult.Enabled = false;
                TextBox txtEditDateIn = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditDateIn");
                txtEditDateIn.Enabled = false;
                TextBox txtEditDateOut = (TextBox)grvCRLDailyView.Rows[index].FindControl("txtEditDateOut");
                txtEditDateOut.Enabled = false;
            }
        }
    }
}
