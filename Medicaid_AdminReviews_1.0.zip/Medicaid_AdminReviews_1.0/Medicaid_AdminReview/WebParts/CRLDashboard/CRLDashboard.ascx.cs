﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Web.UI.WebControls.WebParts;

namespace Medicaid_AdminReview.WebParts.CRLDashboard
{
    [ToolboxItemAttribute(false)]
    public partial class CRLDashboard : WebPart
    {
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";

        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CRLDashboard()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                GetCRLDailyCount();
                GetCRLMonthlyCount();
                GetCRLYearlyCount();
                //GetARDailyCount();
                //GetARMonthlyCount();
                GetARYearlyCount();
            }
        }

        public void GetCRLDailyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        DateTime todaysDate = DateTime.Today;
                        SPList CRLList = currentWeb.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        query.Query = "<Where>" +
                                                "<Eq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(todaysDate) + " </Value>" +
                                                 "</Eq>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        SPListItemCollection listColl = CRLList.GetItems(query);
                        lblCRLDaily.Text = Convert.ToString(listColl.Count);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetCRLMonthlyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        DateTime startDate = DateTime.Today;
                        DateTime endDate = DateTime.Today;
                        Int32 currentYear = startDate.Year;
                        Int32 currentMonth = startDate.Month;
                        Int32 daysInMonth = DateTime.DaysInMonth(currentYear, currentMonth);
                        DateTime.TryParse(currentYear + "-" + currentMonth + "-01", out startDate);
                        DateTime.TryParse(currentYear + "-" + currentMonth + "-" + daysInMonth, out endDate);
                        SPList CRLList = currentWeb.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        query.Query = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate) + " </Value>" +
                                                 "</Geq>" +
                                                "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate) + " </Value>" +
                                                 "</Leq>" +
                                              "</And>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        SPListItemCollection listColl = CRLList.GetItems(query);
                        lblCRLMonthly.Text = Convert.ToString(listColl.Count);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetCRLYearlyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList CRLList = currentWeb.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        DateTime startDate = DateTime.Today;
                        DateTime endDate = DateTime.Today;
                        Int32 currentYear = startDate.Year;
                        DateTime.TryParse(currentYear + "-01-01", out startDate);
                        DateTime.TryParse(currentYear + "-12-31", out endDate);
                        query.Query = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate) + " </Value>" +
                                                 "</Geq>" +
                                                "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate) + " </Value>" +
                                                 "</Leq>" +
                                              "</And>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        SPListItemCollection listColl = CRLList.GetItems(query);
                        lblCRLYearly.Text = Convert.ToString(listColl.Count);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetARDailyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList ARList = currentWeb.Lists["AR Grid List"];
                        SPQuery camlQuery = new SPQuery();
                        camlQuery.Query = "<Where>" +
                                             "<Eq>" +
                                                "<FieldRef Name='Created'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                                "<Value Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.UtcNow) + "</Value>" +
                                              "</Eq>" +
                                          "</Where>";
                        SPListItemCollection listColl = ARList.GetItems(camlQuery);

                        if (listColl.Count > 0)
                        {
                            lblARDaily.Text = Convert.ToString(listColl.Count);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetARMonthlyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList ARList = currentWeb.Lists["AR Grid List"];
                        SPQuery camlQuery = new SPQuery();
                        camlQuery.Query = "<Where>" +
                                             "<Eq>" +
                                                "<FieldRef Name='Created'/>" +   //OPR_Number is the new column in 'Scan OPR'
                                                "<Value Type='DateTime'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(DateTime.UtcNow) + "</Value>" +
                                              "</Eq>" +
                                          "</Where>";
                        SPListItemCollection listColl = ARList.GetItems(camlQuery);

                        if (listColl.Count > 0)
                        {
                            lblARDaily.Text = Convert.ToString(listColl.Count);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void GetARYearlyCount()
        {
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb currentWeb = site.OpenWeb())
                    {
                        SPList CRLList = currentWeb.Lists["AR Grid List"];
                        SPQuery query = new SPQuery();
                        //Get last and latest 5 days records and apply the condition
                        DateTime todaysDate = DateTime.Today;
                        DateTime startDate = todaysDate;
                        DateTime endDate = todaysDate;
                        Int32 currentYear = startDate.Year;
                        DateTime.TryParse(currentYear + "-01-01", out startDate);
                        DateTime.TryParse(currentYear + "-12-31", out endDate);

                        DateTime startMonthDate = todaysDate;
                        DateTime endMonthDate = todaysDate;
                        Int32 currentMonth = todaysDate.Month;
                        Int32 daysInMonth = DateTime.DaysInMonth(currentYear, currentMonth);
                        DateTime.TryParse(currentYear + "-" + currentMonth + "-01", out startMonthDate);
                        DateTime.TryParse(currentYear + "-" + currentMonth + "-" + daysInMonth, out endMonthDate);
                        query.Query = "<Where>" +
                                            "<And>" +
                                                "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(startDate) + " </Value>" +
                                                 "</Geq>" +
                                                "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='False'> " + SPUtility.CreateISO8601DateTimeFromSystemDateTime(endDate) + " </Value>" +
                                                 "</Leq>" +
                                              "</And>" +
                                         "</Where>" +
                                         "<OrderBy>" +
                                            "<FieldRef Name='ID' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        SPListItemCollection listColl = CRLList.GetItems(query);
                        if (listColl.Count > 0)
                        {
                            DataRow[] datatrows = listColl.GetDataTable().Select();
                            Int32 monthlyCount = datatrows.Where(s => Convert.ToDateTime(s["created"]) >= startMonthDate && Convert.ToDateTime(s["created"]) <= endMonthDate).Count();
                            Int32 dailyCount = datatrows.Where(s => Convert.ToDateTime(s["created"]) >= todaysDate && Convert.ToDateTime(s["created"]) < todaysDate.AddDays(1)).Count();
                            lblARDaily.Text = Convert.ToString(dailyCount);
                            lblARMonthly.Text = Convert.ToString(monthlyCount);
                            lblARYearly.Text = Convert.ToString(listColl.Count);
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
