﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;


namespace Medicaid_AdminReview.WebParts.ARGrid
{
    [ToolboxItemAttribute(false)]
    public partial class ARGrid : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        public ARGrid()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        Int32 pageIndex = 0;
        String pageInfo = String.Empty;
        String strPageInfo = String.Empty;
        DateTime searchDate = DateTime.Now;
        SPListItemCollectionPosition itemPoistion = null;
        SPListItemCollectionPosition oPos = null;
        SPListItemCollection listColl = null;
        String prevPageInfo = null;
        String nextPageInfo = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                String todaysStartDate = DateTime.Today.ToShortDateString();
                txtStartDate.Text = todaysStartDate;
                String todaysEndDate = DateTime.Today.ToShortDateString();
                //txtEndDate.Text = todaysEndDate;
                GetCurrentDayItems(todaysStartDate, todaysEndDate, txtSearchAR.Text, null, "load");
                BindCRLID();
            }

        }

        private void BindCRLID()
        {
            DropDownList ddlCRLID = (DropDownList)gvARDeatils.FooterRow.FindControl("ddlCRLID");
            ddlCRLID.DataSource = GetCRLogID("load").GetDataTable();
            ddlCRLID.DataTextField = "CRLID";
            ddlCRLID.DataValueField = "CRLID";
            ddlCRLID.DataBind();
            ddlCRLID.Items.Insert(0, "Select");
        }

        private void FirstGridViewRow() //Set First Grid Row
        {
            DataTable dt = new DataTable();
            DataRow dr = null;

            /*Start-Scan List Dev Site*/
            dt.Columns.Add(new DataColumn("Title", typeof(string))); //added
            dt.Columns.Add(new DataColumn("ARNumber", typeof(string)));
            dt.Columns.Add(new DataColumn("ARVersion", typeof(string)));
            dt.Columns.Add(new DataColumn("ID", typeof(string)));
            dt.Columns.Add(new DataColumn("ProviderID", typeof(string)));
            dt.Columns.Add(new DataColumn("Recipient", typeof(string)));
            dt.Columns.Add(new DataColumn("DOSFrom", typeof(string)));
            dt.Columns.Add(new DataColumn("DOSTo", typeof(string)));
            dt.Columns.Add(new DataColumn("DateCompleted", typeof(string)));
            dt.Columns.Add(new DataColumn("DateIn", typeof(string)));
            dt.Columns.Add(new DataColumn("Outcome", typeof(string)));
            dt.Columns.Add(new DataColumn("OutcomeReason", typeof(string)));
            dt.Columns.Add(new DataColumn("ReferredTo", typeof(string)));
            dt.Columns.Add(new DataColumn("CRLID", typeof(string)));
            dt.Columns.Add(new DataColumn("AssignedTo", typeof(string)));
            dt.Columns.Add(new DataColumn("Result", typeof(string))); //Reopenreason
            dt.Columns.Add(new DataColumn("IsReOpened", typeof(string)));

            dr = dt.NewRow();

            dr["Title"] = string.Empty;
            dr["ARNumber"] = string.Empty;
            dr["ARVersion"] = string.Empty;
            dr["ID"] = string.Empty;
            dr["ProviderID"] = string.Empty;
            dr["Recipient"] = string.Empty;
            dr["DOSFrom"] = string.Empty;
            dr["DOSTo"] = string.Empty;
            dr["DateCompleted"] = string.Empty;
            dr["DateIn"] = string.Empty;
            dr["Outcome"] = string.Empty;
            dr["OutcomeReason"] = string.Empty;
            dr["ReferredTo"] = string.Empty;
            dr["CRLID"] = string.Empty;
            dr["AssignedTo"] = string.Empty;
            dr["Result"] = string.Empty;    //Reopenreason
            dr["IsReOpened"] = "1"; //default re-open to 'no'

            dt.Rows.Add(dr);

            //ViewState["CurrentTable"] = dt;

            gvARDeatils.DataSource = dt;
            gvARDeatils.DataBind();


            //append log-in user


        }

        public String GetARID()
        {
            String ARID = String.Empty;
            DateTime todaysDate = DateTime.Now.Date;
            int ARNumber = 0;
            //String Year = DateTime.Now.Year.ToString().Substring(2, 2); //2018
            String Year = DateTime.Now.Year.ToString();
            String MonthFormat = String.Empty;

            SPListItemCollection listColl = GetMostRecentItem(todaysDate.ToShortDateString());

            if (listColl.Count > 0)
            {
                foreach (SPListItem item in listColl)
                {
                    //Compare old ReOpens with current day ARs and check the ARVersion to generate right ARnumber
                    //ARDateIn is only get todays date for AR number purpose only
                    if (DateTime.Parse(Convert.ToString(item["ARDateIn"]).Split(' ')[0]) == todaysDate && !(Convert.ToString(item["ARNumber"]).IndexOf('.') > 0)) 
                    {
                        ARID =  Convert.ToString(item["Title"]);
                        break;
                    }
                }
                if (String.IsNullOrEmpty(ARID))
                {
                    ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + "001";
                }
                else
                {
                    ARID = ARID.Substring(ARID.LastIndexOf('-') + 1);
                    ARNumber = Convert.ToInt32(ARID) + 1;
                    if (Convert.ToInt32(ARNumber) <= 9)
                        ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-00" + ARNumber;
                    else
                        ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-0" + Convert.ToInt32(ARNumber);
                }

            }
            else
            {
                ARID = "AR-" + Year + "-" + todaysDate.Month + "-" + todaysDate.Day + "-" + "001";
            }
            return ARID;
        }

        public SPListItemCollection GetCRLogID(String reqSource)
        {
            SPListItemCollection listColl = null;
            String strQuery = String.Empty;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        if (reqSource == "load")
                        {
                            strQuery = "<Where>" +
                                            "<And>" +
                                               "<IsNotNull>" +
                                                    "<FieldRef Name='AssignedTo'/>" +
                                                "</IsNotNull>" +
                                                "<Eq>" +
                                                    "<FieldRef Name='CRLStatus'/>" +
                                                    "<Value Type='Boolean'>0</Value>" +
                                                 "</Eq>" +
                                               "</And>" +
                                           "</Where>";
                        }
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat("<FieldRef Name='CRLID' />");
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = CRLogList.GetItems(query);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        public SPListItemCollection GetMostRecentItem(String todaysDate)
        {
            SPListItemCollection listItemColl;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList ARGridList = web.Lists["AR Grid List"];
                        SPQuery query = new SPQuery();
                        String strQuery = "";
                        DateTime searchDate = new DateTime().Date;
                        if (!String.IsNullOrEmpty(todaysDate))
                        {
                            searchDate = DateTime.Parse(todaysDate);
                        }

                        #region CamlQuery

                        strQuery = "<Where>" +
                                      "<And>" +
                                          "<Geq>" +
                                               "<FieldRef Name='Created'/>" +
                                               "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchDate) + "</Value>" +
                                          "</Geq>" +
                                           "<Leq>" +
                                               "<FieldRef Name='Created'/>" +
                                               "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchDate) + "</Value>" +
                                          "</Leq>" +
                                      "</And>" +
                                  "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                 "<FieldRef Name='ARNumber' />",
                                  "<FieldRef Name='ARDateIn' />",
                                 "<FieldRef Name='DateIn' />"); //ARDateIn is only get todays date for AR number purpose only
                        //"<FieldRef Name='DateIn' />"); 
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listItemColl = ARGridList.GetItems(query);
                        #endregion

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listItemColl;
        }

        public void GetCurrentDayItems(String startDate, String endDate, String serachText, SPListItemCollectionPosition itemPoistion, String searchMode)
        {
            Int32 recordsPerPage = Convert.ToInt32(ddlRecordsPerPage.SelectedValue);
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList ARGridList = web.Lists["AR Grid List"];
                        SPQuery query = new SPQuery();
                        String strQuery = "";
                        DateTime searchStartDate = new DateTime().Date;
                        DateTime searchEndDate = new DateTime().Date;
                        if (!String.IsNullOrEmpty(startDate))
                        {
                            searchStartDate = DateTime.Parse(startDate);
                        }
                        if (!String.IsNullOrEmpty(endDate))
                        {
                            searchEndDate = DateTime.Parse(endDate);
                        }
                        #region CamlQuery
                        if (!String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text) && !String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='ARNumber'/>" +
                                                          "<Value Type='Text'>" + serachText + "</Value>" +
                                                     "</Contains>" +
                                                 "<And>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                     "</Geq>" +
                                                      "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                     "</Leq>" +
                                                  "</And>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text) && String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                     "</Geq>" +
                                                      "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                     "</Leq>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtStartDate.Text) && String.IsNullOrEmpty(txtEndDate.Text) && !String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='ARNumber'/>" +
                                                          "<Value Type='Text'>" + serachText + "</Value>" +
                                                     "</Contains>" +
                                                     "<Geq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                     "</Geq>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text) && !String.IsNullOrEmpty(txtSearchAR.Text))
                        {
                            strQuery = "<Where>" +
                                                 "<And>" +
                                                     "<Contains>" +
                                                          "<FieldRef Name='ARNumber'/>" +
                                                          "<Value Type='Text'>" + serachText + "</Value>" +
                                                     "</Contains>" +
                                                     "<Leq>" +
                                                          "<FieldRef Name='Created'/>" +
                                                          "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                     "</Leq>" +
                                                  "</And>" +
                                         "</Where>";
                        }
                        else if (!String.IsNullOrEmpty(txtStartDate.Text) && String.IsNullOrEmpty(txtEndDate.Text) && String.IsNullOrEmpty(serachText))
                        {
                            strQuery = "<Where>" +
                                                "<Geq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                                "</Geq>" +
                                        "</Where>";
                        }
                        else if (String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text) && String.IsNullOrEmpty(serachText))
                        {
                            strQuery = "<Where>" +
                                                "<Leq>" +
                                                     "<FieldRef Name='Created'/>" +
                                                     "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                                "</Leq>" +
                                        "</Where>";
                        }
                        else if (String.IsNullOrEmpty(txtStartDate.Text) && String.IsNullOrEmpty(txtEndDate.Text) && !String.IsNullOrEmpty(serachText))
                        {
                            strQuery = "<Where>" +
                                           "<Contains>" +
                                                "<FieldRef Name='ARNumber'/>" +
                                                 "<Value Type='Text'>" + serachText + "</Value>" +
                                            "</Contains>" +
                                       "</Where>";
                        }
                        else
                        {
                            strQuery = "<Where>" +
                                          "<And>" +
                                              "<Geq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchStartDate) + "</Value>" +
                                              "</Geq>" +
                                               "<Leq>" +
                                                   "<FieldRef Name='Created'/>" +
                                                   "<Value Type='DateTime' IncludeTimeValue='FALSE'>" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(searchEndDate) + "</Value>" +
                                              "</Leq>" +
                                          "</And>" +
                                      "</Where>";
                        }

                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                 "<FieldRef Name='ARNumber' />",
                                 "<FieldRef Name='ARVersion' />",
                                  "<FieldRef Name='CRLID' />",
                                  "<FieldRef Name='ID' />",
                                  "<FieldRef Name='Outcome' />",
                                  "<FieldRef Name='OutcomeReason' />",
                                  "<FieldRef Name='ReferredTo' />",
                                    "<FieldRef Name='ProviderID' />",
                                    "<FieldRef Name='Recipient' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateCompleted' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='DOSFrom' />",
                                    "<FieldRef Name='DOSTo' />",
                                    "<FieldRef Name='IsReOpened' />",
                                    "<FieldRef Name='Result' />"); //Reopenreason
                        query.RowLimit = Convert.ToUInt32(recordsPerPage);
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        query.ListItemCollectionPosition = itemPoistion;
                        listColl = ARGridList.GetItems(query);
                        #endregion

                        if (listColl != null && listColl.Count > 0)
                        {
                            itemPoistion = listColl.ListItemCollectionPosition;
                            if (itemPoistion != null)
                            {
                                nextPageInfo = itemPoistion.PagingInfo;
                                ViewState["next"] = nextPageInfo;
                            }

                            DataView view = listColl.GetDataTable().DefaultView;
                            DataTable sortedCRLTable = view.ToTable();
                            ViewState["ARGridList"] = sortedCRLTable;
                            gvARDeatils.PageSize = recordsPerPage;
                            gvARDeatils.DataSource = sortedCRLTable;
                            gvARDeatils.DataBind();
                        }
                        else
                        {
                            if (searchMode == "search")
                            {
                                lblErrorMessage.Text = "No Records Found";
                            }
                            FirstGridViewRow();
                        }
                        if (searchDate < DateTime.Today)
                        {
                            gvARDeatils.FooterRow.Visible = false;
                            gvARDeatils.ShowFooter = false;
                        }
                        ManagePageControl();
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ManagePageControl()
        {
            if (ViewState["pageIndex"] != null)
            {
                pageIndex = Convert.ToInt32(ViewState["pageIndex"]);
                if (pageIndex == 0)
                {
                    btnPrevious.Enabled = false;
                    btnPrevious.CssClass = "btnGreyedOut";
                }
                else
                {
                    btnPrevious.Enabled = true;
                    btnPrevious.CssClass = "btnSave";
                }
                if (listColl.ListItemCollectionPosition == null)
                {
                    btnNext.Enabled = false;
                    btnNext.CssClass = "btnGreyedOut";
                }
                else
                {
                    btnNext.Enabled = true;
                    btnNext.CssClass = "btnSave";
                }
            }
            else
            {
                if (listColl.Count < Convert.ToInt32(ddlRecordsPerPage.SelectedValue))
                {
                    btnNext.Enabled = false;
                    btnNext.CssClass = "btnGreyedOut";
                    btnPrevious.Enabled = false;
                    btnPrevious.CssClass = "btnGreyedOut";
                }
                else
                {
                    btnNext.Enabled = true;
                    btnNext.CssClass = "btnSave";
                    btnPrevious.Enabled = true;
                    btnPrevious.CssClass = "btnSave";
                }
                btnPrevious.Enabled = false;
                btnPrevious.CssClass = "btnGreyedOut";
            }
           
        }

        public SPListItemCollection GetItemBasedonCRLID(String CRLID)
        {
            SPListItemCollection listColl = null;
            try
            {
                using (SPSite site = new SPSite(siteUrl))
                {
                    using (SPWeb web = site.OpenWeb())
                    {
                        SPList CRLogList = web.Lists["Customer Review Log"];
                        SPQuery query = new SPQuery();
                        String strQuery = "<Where>" +
                                             "<Contains>" +
                                                  "<FieldRef Name='CRLID'/>" +
                                                  "<Value Type='Text'>" + CRLID + "</Value>" +
                                             "</Contains>" +
                                            "</Where>";
                        query.Query = strQuery +
                                         "<OrderBy>" +
                                            "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                         "</OrderBy>";
                        query.ViewFields = string.Concat(
                                 "<FieldRef Name='Title' />",
                                  "<FieldRef Name='CRLID' />",
                                    "<FieldRef Name='Provider' />",
                                   "<FieldRef Name='ReceipientName' />",
                                    "<FieldRef Name='DateIn' />",
                                    "<FieldRef Name='DateOut' />",
                                    "<FieldRef Name='AssignedTo' />",
                                    "<FieldRef Name='FirstDateofService' />",
                                    "<FieldRef Name='LastDateofService' />");
                        //"<FieldRef Name='Result' />");  //Reopenreason
                        query.DatesInUtc = false;
                        query.ViewFieldsOnly = true;
                        listColl = CRLogList.GetItems(query);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listColl;
        }

        public bool SaveAREntryDetails()
        {
            try
            {
                bool IsRecordSaved = false;
                Label1.Text = "";
                Label2.Text = "";
                String errorMessage = String.Empty;
                GridViewRow row = gvARDeatils.FooterRow;
                
                DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlCRLID");
                Label txtProvider = (Label)row.FindControl("txtProvider");
                Label txtRecipient = (Label)row.FindControl("txtRecipientFooter");
                Label txtFirstDateofService = (Label)row.FindControl("txtFirstDateofService");
                Label txtLastDateofService = (Label)row.FindControl("txtLastDateofService");
                Label txtAssignedTo = (Label)row.FindControl("txtAssignedTo");
                Label txtDateIn = (Label)row.FindControl("txtDateInFooter");
                Label txtDateOut = (Label)row.FindControl("txtDateOut");
                Label txtResult = (Label)row.FindControl("txtResult"); //Reopenreason
                DropDownList ddlOutcome = (DropDownList)row.FindControl("ddlOutcomeFooter");
                              

                if (String.IsNullOrEmpty(errorMessage))
                {
                    String ARID = GetARID();
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {

                            SPList CRLogList = web.Lists["AR Grid List"]; //AR Grid List
                            SPListItemCollection listItems = CRLogList.Items;
                            SPListItem item = listItems.Add();
                            String strCRLID = ddlCRLID.SelectedValue;
                            item["Title"] = ARID;
                            item["ARNumber"] = ARID;
                            item["ARVersion"] = ARID;
                            item["CRLID"] = strCRLID;
                            item["ProviderID"] = txtProvider.Text;
                            item["Recipient"] = txtRecipient.Text;
                            item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                            if (!(String.IsNullOrEmpty(txtDateOut.Text)))
                            {
                                item["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                            }
                            item["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                            item["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                            item["AssignedTo"] = txtAssignedTo.Text;
                            item["Result"] = txtResult.Text;    //Reopenreason
                            item["Outcome"] = "Pending";
                            //item["ARDateIn"] = Convert.ToDateTime(DateTime.Today.ToShortDateString());
                            //item["OutcomeReason"] = txtOutcomeReason.Text;
                            item.Update();

                            //Update CRL Status
                            SPList CRLList = web.Lists["Customer Review Log"];
                            SPQuery query = new SPQuery();
                            String strQuery = "";
                            strQuery = "<Where>" +
                                           "<Eq>" +
                                                "<FieldRef Name='CRLID'/>" +
                                                 "<Value Type='Text'>" + strCRLID + "</Value>" +
                                            "</Eq>" +
                                       "</Where>";
                            query.Query = strQuery;
                            SPListItemCollection CRLcoll = CRLList.GetItems(query);
                            //SPListItem CRLitem = CRLcoll[0];
                            
                            foreach (SPListItem CRLitem in CRLcoll)
                            {
                                CRLitem["CRLStatus"] = true;    //Set CRLStatus to 'Yes'
                                CRLitem.Update();
                            }

                            IsRecordSaved = true;
                        }
                    }
                }
                else
                {
                    IsRecordSaved = false;
                    Label1.Text = errorMessage;
                }
                return IsRecordSaved;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void gvARDeatils_RowDeleting(object sender, System.Web.UI.WebControls.GridViewDeleteEventArgs e)
        {

        }

        protected void gvARDeatils_RowEditing(object sender, System.Web.UI.WebControls.GridViewEditEventArgs e)
        {
            gvARDeatils.EditIndex = e.NewEditIndex;
            DataTable sortedARTable = (DataTable)ViewState["ARGridList"];
            //SPListItemCollection listColl = GetCurrentDayItems(txtSubmittedDate.Text, txtSearchAR.Text);
            if (sortedARTable.Rows.Count > 0)
            {
                gvARDeatils.DataSource = sortedARTable;
                gvARDeatils.DataBind();
            }
            else
            {
                FirstGridViewRow();
            }
            BindCRLID();
        }

        protected void gvARDeatils_RowUpdating(object sender, System.Web.UI.WebControls.GridViewUpdateEventArgs e)
        {
            gvARDeatils.ShowFooter = true;
            ButtonSave.Visible = true;            

            try
            {
                String errorMessage = String.Empty;
                GridViewRow row = gvARDeatils.Rows[e.RowIndex];
                Label lblID = (Label)row.FindControl("lblID");
                DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlEditCRLID");
                Label lblARNumber = (Label)row.FindControl("lblARNumber");
                TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
                TextBox txtRecipient = (TextBox)row.FindControl("txtRecipient");
                TextBox txtFirstDateofService = (TextBox)row.FindControl("txtDOSFrom");
                TextBox txtLastDateofService = (TextBox)row.FindControl("txtDOSTo");
                TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
                TextBox txtDateIn = (TextBox)row.FindControl("txtDateIn");
                TextBox txtDateOut = (TextBox)row.FindControl("txtDateCompleted");
                TextBox txtResult = (TextBox)row.FindControl("txtResult"); //Reopenreason
                DropDownList ddlOutcome = (DropDownList)row.FindControl("ddlOutcome");
                TextBox txtOutcomeReason = (TextBox)row.FindControl("txtOutcomeReason");
                TextBox txtReferredTo = (TextBox)row.FindControl("txtReferredTo");
                DateTime tempDateOut;
                bool isDateOutValid = (txtDateOut.Text.Length == 0) ? true : DateTime.TryParseExact(txtDateOut.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempDateOut);

                if (txtResult.Visible && String.IsNullOrEmpty(txtResult.Text))
                {
                    errorMessage = "Please select reopen reason";
                }
                else if ((ddlOutcome.SelectedValue == "Approved" || ddlOutcome.SelectedValue == "Denied") && String.IsNullOrEmpty(txtOutcomeReason.Text))
                {
                    errorMessage = "Please enter outcome reason";
                }
                else if (ddlOutcome.SelectedValue == "Referred To" && String.IsNullOrEmpty(txtReferredTo.Text))
                {
                    errorMessage = "Please enter forwarded To department";
                }
                else if (ddlOutcome.SelectedValue != "Pending" && String.IsNullOrEmpty(txtAssignedTo.Text))
                {
                    errorMessage = "Please enter assigned to";
                }
                else if (!isDateOutValid)
                {
                    errorMessage = "Please enter valid Date out";
                }
                else if (!String.IsNullOrEmpty(txtDateIn.Text) && !String.IsNullOrEmpty(txtDateOut.Text))
                {
                    if (Convert.ToDateTime(txtDateOut.Text) < Convert.ToDateTime(txtDateIn.Text))
                    {
                        errorMessage = "Date out should be equal or greater than Date In";
                    }
                }
                

                if (String.IsNullOrEmpty(errorMessage))
                {
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            SPList ARGridList = web.Lists["AR Grid List"]; //AR Grid List
                            SPListItem item = ARGridList.GetItemById(Convert.ToInt32(lblID.Text));
                            if ((Convert.ToString(item["Outcome"]) != "Pending") && (Convert.ToString(item["Outcome"]) != "More Info Needed") && (Convert.ToString(item["Outcome"]) != "Referred To"))
                            {

                                SPListItemCollection listItems = ARGridList.Items;
                                SPListItem itemAdd = listItems.Add();
                                String ARNumber = lblARNumber.Text;   //AR-2018-12-21-002 
                                String ARNumVersion = ARNumber.Split('-')[4];
                                String ARNumVersionUpdated = String.Empty;
                                String prevARNumber = ARNumber;
                                if (ARNumVersion.Contains("."))
                                {
                                    ARNumVersionUpdated = ARNumVersion.Split('.')[0] + "." + (Convert.ToInt32(ARNumVersion.Split('.')[1]) + 1);
                                    ARNumber = ARNumber.Replace(ARNumVersion, ARNumVersionUpdated);
                                }
                                else
                                {
                                    ARNumber = ARNumber + ".1";
                                }

                                itemAdd["Title"] = ARNumber.Split('.')[0];
                                itemAdd["ARNumber"] = ARNumber;
                                itemAdd["ARVersion"] = ARNumber;
                                itemAdd["CRLID"] = Convert.ToString(item["CRLID"]);//ddlCRLID.SelectedValue;
                                itemAdd["ProviderID"] = txtProvider.Text;
                                itemAdd["Recipient"] = txtRecipient.Text;
                                itemAdd["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                                if (!(String.IsNullOrEmpty(txtDateOut.Text)))
                                {
                                    item["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                                }
                                itemAdd["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                                itemAdd["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                                itemAdd["AssignedTo"] = txtAssignedTo.Text;
                                //itemAdd["Result"] = txtResult.Text; //Reopenreason
                                itemAdd["Outcome"] = "Pending";
                                //itemAdd["OutcomeReason"] = txtOutcomeReason.Text;
                                itemAdd["ReferredTo"] = txtReferredTo.Text;
                                //itemAdd["IsReOpened"] = false;
                                itemAdd.Update();

                                item["IsReOpened"] = true;
                                item["Result"] = txtResult.Text; //Reopenreason
                                item.Update();

                                AddVersionedDocument(prevARNumber, ARNumber, web);
                            }
                            else
                            {
                                item["ProviderID"] = txtProvider.Text;
                                item["Recipient"] = txtRecipient.Text;
                                item["DateIn"] = Convert.ToDateTime(txtDateIn.Text);
                                if (!(String.IsNullOrEmpty(txtDateOut.Text)))
                                {
                                    item["DateCompleted"] = Convert.ToDateTime(txtDateOut.Text);
                                }
                                item["DOSFrom"] = Convert.ToDateTime(txtFirstDateofService.Text);
                                item["DOSTo"] = Convert.ToDateTime(txtLastDateofService.Text);
                                item["AssignedTo"] = txtAssignedTo.Text;
                                item["Result"] = txtResult.Text;    //Reopenreason
                                item["Outcome"] = ddlOutcome.SelectedValue;
                                item["OutcomeReason"] = txtOutcomeReason.Text;
                                item["ReferredTo"] = txtReferredTo.Text;
                                item.Update();
                            }
                        }
                    }
                    gvARDeatils.EditIndex = -1;
                    GetCurrentDayItems(txtStartDate.Text, txtEndDate.Text, txtSearchAR.Text, null, "load");
                    lblErrorMessage.Text = String.Empty;
                    BindCRLID();
                }
                else
                {
                    lblErrorMessage.Text = errorMessage;
                }                

            }

            catch (Exception ex)
            {
                throw ex;
            }            

        }

        protected void gvARDeatils_RowCancelingEdit(object sender, System.Web.UI.WebControls.GridViewCancelEditEventArgs e)
        {
            //gvARDeatils.ShowFooter = true;  //Added 7/25

            gvARDeatils.EditIndex = -1;
            GetCurrentDayItems(txtStartDate.Text, txtEndDate.Text, txtSearchAR.Text, null, "load");
            BindCRLID();
            lblErrorMessage.Text = string.Empty;
        }

        protected void gvARDeatils_RowDataBound(object sender, System.Web.UI.WebControls.GridViewRowEventArgs e)
        {
            
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DataRowView rowView = e.Row.DataItem as DataRowView;
                if (gvARDeatils.EditIndex == e.Row.RowIndex)
                {
                    DropDownList ddlCRLID = (DropDownList)e.Row.FindControl("ddlEditCRLID");
                    ddlCRLID.DataSource = GetCRLogID("edit").GetDataTable();
                    ddlCRLID.DataTextField = "CRLID";
                    ddlCRLID.DataValueField = "CRLID";
                    ddlCRLID.DataBind();
                    ddlCRLID.Items.Insert(0, "Select");
                    ddlCRLID.SelectedValue = Convert.ToString(rowView["CRLID"]);

                    DropDownList ddlOutcome = (DropDownList)e.Row.FindControl("ddlOutcome");
                    ddlOutcome.SelectedValue = Convert.ToString(rowView["Outcome"]);
                    TextBox txtOutcomeReason = (TextBox)e.Row.FindControl("txtOutcomeReason");
                    TextBox txtReferredTo = (TextBox)e.Row.FindControl("txtReferredTo");
                    TextBox txtAssignedTo = (TextBox)e.Row.FindControl("txtAssignedTo");
                    TextBox txtProvider = (TextBox)e.Row.FindControl("txtProvider");
                    TextBox txtRecipient = (TextBox)e.Row.FindControl("txtRecipient");
                    TextBox txtDOSFrom = (TextBox)e.Row.FindControl("txtDOSFrom");
                    TextBox txtDOSTo = (TextBox)e.Row.FindControl("txtDOSTo");
                    TextBox txtDateIn = (TextBox)e.Row.FindControl("txtDateIn"); 
                    TextBox txtDateCompleted = (TextBox)e.Row.FindControl("txtDateCompleted");
                    if (Convert.ToString(rowView["Outcome"]) != "Pending" && Convert.ToString(rowView["Outcome"]) != "Referred To" && Convert.ToString(rowView["Outcome"]) != "More Info Needed")
                    {
                        txtOutcomeReason.Visible = true;
                        txtOutcomeReason.Text = Convert.ToString(rowView["OutcomeReason"]);
                        txtOutcomeReason.Enabled = false;
                        ddlOutcome.Enabled = false;
                        txtReferredTo.Visible = false;
                        txtProvider.Enabled = false;
                        txtRecipient.Enabled = false;
                        txtAssignedTo.Enabled = false;
                        txtDateCompleted.Enabled = false;
                    }
                    else if (Convert.ToString(rowView["Outcome"]) == "Referred To")
                    {
                        txtOutcomeReason.Visible = false;
                        txtReferredTo.Visible = true;
                        txtReferredTo.Text = Convert.ToString(rowView["ReferredTo"]);
                        txtProvider.Enabled = false;
                        txtRecipient.Enabled = false;
                        txtAssignedTo.Enabled = false;
                    }
                    else
                    {
                        txtOutcomeReason.Visible = false;
                        txtReferredTo.Visible = false;
                        txtProvider.Enabled = false;
                        txtRecipient.Enabled = false;
                        ddlCRLID.Enabled = false;
                        txtAssignedTo.Enabled = false;
                    }
                    Label lblARNumber = (Label)e.Row.FindControl("lblARNumber");
                    lblARNumber.Text = Convert.ToString(rowView["ARNumber"]);
                    if (lblARNumber.Text.Contains(".")) //Disable CRL selection for versions
                    {
                        ddlCRLID.Enabled = false;
                        txtProvider.Enabled = false;
                        txtRecipient.Enabled = false;
                        txtDOSFrom.Enabled = false;
                        txtDOSTo.Enabled = false;
                        txtDateIn.Enabled = false;
                        txtAssignedTo.Enabled = false;                        

                    }
                    else
                    {
                        ddlCRLID.Enabled = false;
                        txtDOSFrom.Enabled = false;
                        txtDOSTo.Enabled = false;
                        txtDateIn.Enabled = false;
                        txtAssignedTo.Enabled = false;
                    }
                }

                if (!((e.Row.RowState & DataControlRowState.Edit) > 0))
                {
                    Label lblIsReOpened = (Label)e.Row.FindControl("lblIsReOpened");
                    Label lblOutcome = (Label)e.Row.FindControl("lblOutcome");
                    if (lblOutcome.Text == "Pending" && lblIsReOpened.Text == "0")
                    {
                        e.Row.Cells[0].Controls[0].Visible = true;
                        //gvARDeatils.Columns[11].Visible = true;
                    }
                    if ((lblOutcome.Text == "Approved" || lblOutcome.Text == "Denied")
                        && lblIsReOpened.Text == "0") // reopen option should be visible for approvals/denials
                    {
                        Button btnReopen = (Button)e.Row.FindControl("btnReopen");
                        btnReopen.Visible = true;
                        e.Row.Cells[0].Controls[0].Visible = false;
                    }
                    if (lblIsReOpened.Text == "1")
                    {
                        Button btnReopen = (Button)e.Row.FindControl("btnReopen");
                        btnReopen.Visible = false;
                        e.Row.Cells[0].Controls[0].Visible = false;
                    }
                    
                }

            }
        }

        protected void gvARDeatils_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {

        }

        protected void ddlCRLID_SelectedIndexChanged(object sender, EventArgs e)
        {
            DropDownList ddlCRLID = (DropDownList)sender;
            Label txtProvider = (Label)gvARDeatils.FooterRow.FindControl("txtProvider");
            Label txtRecipient = (Label)gvARDeatils.FooterRow.FindControl("txtRecipientFooter");
            Label txtDateIn = (Label)gvARDeatils.FooterRow.FindControl("txtDateInFooter");
            Label txtFirstDateofService = (Label)gvARDeatils.FooterRow.FindControl("txtFirstDateofService");
            Label txtLastDateofService = (Label)gvARDeatils.FooterRow.FindControl("txtLastDateofService");
            Label txtAssignedTo = (Label)gvARDeatils.FooterRow.FindControl("txtAssignedTo");
            Label txtDateOut = (Label)gvARDeatils.FooterRow.FindControl("txtDateOut");
            if (ddlCRLID.SelectedValue != "Select")
            {
                SPListItemCollection listColl = GetItemBasedonCRLID(ddlCRLID.SelectedValue);
                if (listColl.Count > 0)
                {
                    foreach (SPListItem item in listColl)
                    {
                        txtProvider.Text = Convert.ToString(item["Provider"]);
                        txtRecipient.Text = Convert.ToString(item["ReceipientName"]);
                        txtDateIn.Text = Convert.ToString(item["DateIn"]).Replace(" 12:00:00 AM", "");//Convert.ToString(DateTime.Today.ToString("MM/dd/yyyy"));
                        txtFirstDateofService.Text = Convert.ToString(item["FirstDateofService"]).Replace(" 12:00:00 AM","");//If the field has time value, replaced with blank
                        txtLastDateofService.Text = Convert.ToString(item["LastDateofService"]).Replace(" 12:00:00 AM", "");//If the field has time value, replaced with blank
                        txtAssignedTo.Text = Convert.ToString(item["AssignedTo"]);
                        txtDateOut.Text = Convert.ToString(item["DateOut"]).Replace(" 12:00:00 AM", "");//If the field has time value, replaced with blank
                    }
                }
            }
            else
            {
                txtProvider.Text = String.Empty;
                txtRecipient.Text = String.Empty;
                //txtDateIn.Text = String.Empty;
                txtFirstDateofService.Text = String.Empty;
                txtLastDateofService.Text = String.Empty;
                txtAssignedTo.Text = String.Empty;
                txtDateOut.Text = String.Empty;
            }

        }

        protected void ButtonSave_Click(object sender, EventArgs e)
        {
            GridViewRow row = gvARDeatils.FooterRow;
            String ddlCRLIDValue = ((DropDownList)row.FindControl("ddlCRLID")).SelectedValue;
            Label1.Text = "";
            Label2.Text = "";
            lblErrorMessage.Text = "";
            String errorMessage = String.Empty;
            Label txtDateInFooter = (Label)row.FindControl("txtDateInFooter");
            if (ddlCRLIDValue != "Select")
            {
                bool IsRecorsSaved = SaveAREntryDetails();
                if (IsRecorsSaved)
                {
                    GetCurrentDayItems(txtStartDate.Text, txtEndDate.Text,  txtSearchAR.Text, null, "load");
                    BindCRLID();
                }
            }
            else
            {
                lblErrorMessage.Text = "Please select CRL ID";
            }
        }

        protected void ButtonCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect(siteUrl + "SitePages/AR%20Grid.aspx");
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            String errorMessage = String.Empty;
            DateTime tempStartDate;
            DateTime tempEndDate;
            bool isStartDateValid = (txtStartDate.Text.Length == 0) ? true : DateTime.TryParseExact(txtStartDate.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempStartDate);
            bool isEndDateValid = (txtEndDate.Text.Length == 0) ? true : DateTime.TryParseExact(txtEndDate.Text, "M/d/yyyy", null, System.Globalization.DateTimeStyles.None, out tempEndDate);
            if (isStartDateValid && isEndDateValid)
            {
                if (!String.IsNullOrEmpty(txtStartDate.Text) && !String.IsNullOrEmpty(txtEndDate.Text))
                {
                    if (Convert.ToDateTime(txtEndDate.Text) < Convert.ToDateTime(txtStartDate.Text))
                    {
                        errorMessage = "End Date should be equal or greater than Start Date";
                    }
                }
            }
            else
            {
                errorMessage = "Please enter valid Start/End date";
            }
            if (String.IsNullOrEmpty(errorMessage))
            {
                lblErrorMessage.Text = String.Empty;
                GetCurrentDayItems(txtStartDate.Text, txtEndDate.Text, txtSearchAR.Text, null, "search");
                BindCRLID(); 
            }
            else
            {
                FirstGridViewRow();
                BindCRLID();
                lblErrorMessage.Text = errorMessage;
            }
            
        }

        protected void ddlOutcome_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            GridViewRow row = (GridViewRow)(sender as DropDownList).NamingContainer;
            String strOutcome = ((DropDownList)row.FindControl("ddlOutcome")).SelectedValue;
            TextBox txtOutcomeReason = (TextBox)row.FindControl("txtOutcomeReason");
            TextBox txtReferredTo = (TextBox)row.FindControl("txtReferredTo");
            //DropDownList ddlOutcome = (DropDownList)row.FindControl("ddlOutcome");
            //DropDownList ddlCRLID = (DropDownList)row.FindControl("ddlEditCRLID");
            TextBox txtDateOut = (TextBox)row.FindControl("txtDateCompleted");
            
            
            //if (strOutcome != "Pending" && strOutcome != "More Info Needed")
            //{
            //    txtOutcomeReason.Visible = true;
            //    txtReferredTo.Visible = false;
            //}
            if (strOutcome == "Approved" || strOutcome == "Denied")
            {
                txtOutcomeReason.Visible = true;
                txtReferredTo.Visible = false;
                txtDateOut.Text = DateTime.Today.ToShortDateString();                
            }
            else if (strOutcome == "Referred To")
            {
                txtReferredTo.Visible = true;
                txtOutcomeReason.Visible = false;
                //txtDateOut.Text = DateTime.Today.ToShortDateString();
            }            
            else
            {
                txtReferredTo.Visible = false;
                txtOutcomeReason.Visible = false;
            }            
        }

        protected void btnReopen_Click(object sender, EventArgs e)
        {
            //GridViewRow gvr = (GridViewRow)((Button)sender).Parent.Parent;
            //gvARDeatils.EditIndex = gvr.RowIndex;
        }

        protected void gvARDeatils_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Edit")
            {
                //GridViewRow gvr = (GridViewRow)((Button)sender).Parent.Parent;
                //gvARDeatils.EditIndex = gvr.RowIndex;
            }
        }

        protected void ddlEditCRLID_SelectedIndexChanged(object sender, EventArgs e)
        {
            GridViewRow row = (GridViewRow)(sender as DropDownList).NamingContainer;
            DropDownList ddlEditCRLID = (DropDownList)sender;
            if (ddlEditCRLID.SelectedValue != "Select")
            {
                SPListItemCollection listColl = GetItemBasedonCRLID(ddlEditCRLID.SelectedValue);
                if (listColl.Count > 0)
                {
                    TextBox txtProvider = (TextBox)row.FindControl("txtProvider");
                    TextBox txtRecipient = (TextBox)row.FindControl("txtRecipient");
                    TextBox txtDateIn = (TextBox)row.FindControl("txtDateIn");
                    TextBox txtFirstDateofService = (TextBox)row.FindControl("txtDOSFrom");
                    TextBox txtLastDateofService = (TextBox)row.FindControl("txtDOSTo");
                    TextBox txtAssignedTo = (TextBox)row.FindControl("txtAssignedTo");
                    TextBox txtDateOut = (TextBox)row.FindControl("txtDateCompleted");
                    //TextBox txtResult = (TextBox)row.FindControl("txtResult");  //Reopenreason

                    foreach (SPListItem item in listColl)
                    {
                        txtProvider.Text = Convert.ToString(item["Provider"]);
                        txtRecipient.Text = Convert.ToString(item["ReceipientName"]);
                        txtDateIn.Text = Convert.ToString(item["DateIn"]);
                        txtFirstDateofService.Text = Convert.ToString(item["FirstDateofService"]);
                        txtLastDateofService.Text = Convert.ToString(item["LastDateofService"]);
                        txtAssignedTo.Text = Convert.ToString(item["AssignedTo"]);
                        txtDateOut.Text = Convert.ToString(item["DateOut"]);
                        //txtResult.Text = Convert.ToString(item["Result"]); //Reopenreason
                    }
                }
            }
        }

        public void AddVersionedDocument(String prevARNumber, String ARNumber,SPWeb currentWeb)
        {
            SPList ARGridLib = currentWeb.Lists["AR Grid"];
            SPFile spFile = currentWeb.GetFile(siteUrl + ARGridLib.RootFolder + "/" + prevARNumber + ".pdf");
            Boolean IsfileExists = spFile.Exists;
            if (IsfileExists)
            {
                Uri ARGRidLibFolder = new Uri(siteUrl + ARGridLib.RootFolder);
                String filePath = siteUrl + ARGridLib.RootFolder + "/" + prevARNumber + ".pdf";
                SPFile srcFile = currentWeb.GetFile(filePath);
                SPFolder dstLibFolder = currentWeb.GetFolder(ARGRidLibFolder.AbsolutePath);
                dstLibFolder.Files.Add(ARGRidLibFolder.AbsolutePath + "/" + ARNumber + ".pdf", srcFile.OpenBinary());
            }
        }

        public String checkDocumentExists(object objARNumber)
        {
            Boolean IsfileExists = false;
            String formattedHTML = String.Empty;
            using (SPSite site = new SPSite(siteUrl))
            {
                using (SPWeb currentWeb = site.OpenWeb())
                {
                    String ARNumber = Convert.ToString(objARNumber);
                    SPList ARGridLib = currentWeb.Lists["AR Grid"];
                    SPFile spFile = currentWeb.GetFile(siteUrl + ARGridLib.RootFolder + "/" + ARNumber + ".pdf");
                    IsfileExists = spFile.Exists;
                    if (IsfileExists)
                    {
                        formattedHTML = "<img class='divImageAtt' src='/teams/FiscalAgent/syssupport/SiteAssets/Images/attachment.png'/><a class='divARLink' href='" + string.Format("/teams/FiscalAgent/syssupport/ARGrid/{0}.pdf", ARNumber) + "'>"+ ARNumber + "</a>";
                    }
                    else
                    {
                        //formattedHTML = "< asp:Label ID = 'lblARNumber' runat = 'server' Text = '"+ ARNumber + "' ></ asp:Label >";
                        formattedHTML = ARNumber;
                    }
               }
            }
            return formattedHTML;
        }

        protected void ddlRecordsPerPage_SelectedIndexChanged(object sender, EventArgs e)
        {
            ViewState["pageIndex"] = null;
            //String todaysDate = DateTime.Today.ToShortDateString();
            //txtSubmittedDate.Text = todaysDate;
            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
            }
            if (txtEndDate.Text.Length > 0)
            {
                queriedEndDate = txtEndDate.Text;
            }
            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchAR.Text, null, "load");
           
            BindCRLID();
            Label txtDateInFooter = (Label)gvARDeatils.FooterRow.FindControl("txtDateInFooter");
            txtDateInFooter.Text = DateTime.Today.ToShortDateString(); 
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            oPos = null;
            Label lblID = (Label)gvARDeatils.Rows[0].FindControl("lblID");
            Label lblARNumber = (Label)gvARDeatils.Rows[0].FindControl("lblARNumber");
            if (ViewState["pageIndex"] != null)
            {
                pageIndex = Convert.ToInt32(ViewState["pageIndex"]);
                ViewState["pageIndex"] = pageIndex - 1;
            }

            if (ViewState["itemID"] != null && pageIndex != 1)
            {
                prevPageInfo = String.Format("PagedPrev=TRUE&Paged=TRUE&p_ID={0}&p_Title={1}&PageLastRow={2}",
                                Convert.ToString(ViewState["itemID"]), Convert.ToString(lblARNumber.Text), (pageIndex * Convert.ToInt32(ddlRecordsPerPage.SelectedValue)));
                ViewState["itemID"] = lblID.Text;
                oPos = new SPListItemCollectionPosition(prevPageInfo);
            }

            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
            }
            if (txtEndDate.Text.Length > 0)
            {
                queriedEndDate = txtEndDate.Text;
            }

            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchAR.Text, oPos, "load");
            BindCRLID();
            Label txtDateInFooter = (Label)gvARDeatils.FooterRow.FindControl("txtDateInFooter");
            txtDateInFooter.Text = DateTime.Today.ToShortDateString();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            if (ViewState["pageIndex"] != null)
            {
                ViewState["pageIndex"] = Convert.ToInt32(ViewState["pageIndex"]) + 1;
            }
            else
            {
                ViewState["pageIndex"] = pageIndex + 1;
            }
            Label lblID = (Label)gvARDeatils.Rows[0].FindControl("lblID");
            ViewState["itemID"] = lblID.Text;
            String queriedStartDate = DateTime.Today.ToShortDateString();
            String queriedEndDate = DateTime.Today.ToShortDateString();
            if (txtStartDate.Text.Length > 0)
            {
                queriedStartDate = txtStartDate.Text;
            }
            if (txtEndDate.Text.Length > 0)
            {
                queriedEndDate = txtEndDate.Text;
            }
            pageInfo = ViewState["next"] as String;

            if (!String.IsNullOrEmpty(pageInfo))
            {
                oPos = new SPListItemCollectionPosition(pageInfo);
            }
            GetCurrentDayItems(queriedStartDate, queriedEndDate, txtSearchAR.Text, oPos, "load");
            BindCRLID();
            Label txtDateInFooter = (Label)gvARDeatils.FooterRow.FindControl("txtDateInFooter");
            txtDateInFooter.Text = DateTime.Today.ToShortDateString();
        }
    }
}

