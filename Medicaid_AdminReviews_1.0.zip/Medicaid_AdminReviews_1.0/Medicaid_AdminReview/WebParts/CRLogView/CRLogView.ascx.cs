﻿using Microsoft.SharePoint;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.WebControls;
using Medicaid_AdminReview.Utility;
using System.Web.Services;

namespace Medicaid_AdminReview.WebParts.CRLogView
{
    [ToolboxItemAttribute(false)]
    public partial class CRLogView : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]

        String siteUrl = SPContext.Current.Site.Url + "/syssupport/";
        Int32 pageIndex = 0;    //Page Index
        Int32 itemCount = 0;
        Int32 totalPages = 0;
        String strPageInfo = String.Empty;
        List<CRLSearchEntity> searchEntity = new List<CRLSearchEntity>();
        DateTime tempDate;
        DateTime tempDate1;
        DateTime tempDate2;
        DateTime tempDate3;
        public CRLogView()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                grvCRLDailyView.DataSource = GetYearlyCRLItems(null, "load");
                grvCRLDailyView.DataBind();
            }
        }

        public List<CRLSearchEntity> GetYearlyCRLItems(string paging, string searchString)
        {
            bool isDueDateValid = (txtDateIn.Text == "Date In" || txtDateIn.Text.Length == 0) ? true : DateTime.TryParse(txtDateIn.Text, out tempDate);
            bool isDueDateValid1 = (txtDateOut.Text == "Date Out" || txtDateOut.Text.Length == 0) ? true : DateTime.TryParse(txtDateOut.Text, out tempDate1);
            bool isDueDateValid2 = (txtFirstDateOfService.Text == "DOS From" || txtFirstDateOfService.Text.Length == 0) ? true : DateTime.TryParse(txtFirstDateOfService.Text, out tempDate2);
            bool isDueDateValid3 = (txtLastDateOfService.Text == "DOS To" || txtLastDateOfService.Text.Length == 0) ? true : DateTime.TryParse(txtLastDateOfService.Text, out tempDate3);
            if (isDueDateValid && isDueDateValid1 && isDueDateValid2 && isDueDateValid3)
            {
                try
                {
                    Int32 dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                    pageIndex = 0;
                    using (SPSite site = new SPSite(siteUrl))
                    {
                        using (SPWeb web = site.OpenWeb())
                        {
                            lblErrorMsg.Text = String.Empty;
                            List<String> objColumns = new List<String>();
                            SPList CRLogList = web.Lists["Customer Review Log"];
                            SPQuery query = new SPQuery();
                            String strQuery = "";

                            if (txtCRLID.Text != "CRL ID" && txtCRLID.Text.Length > 0)
                            {
                                objColumns.Add("CRLID;Text;Contains;" + txtCRLID.Text.Trim());
                            }
                            if (txtProvider.Text != "Billing Provider" && txtProvider.Text.Length > 0)
                            {
                                objColumns.Add("Provider;Text;Contains;" + txtProvider.Text.Trim());
                            }
                            if (txtRecipientName.Text != "Recipient ID" && txtRecipientName.Text.Length > 0)
                            {
                                objColumns.Add("ReceipientName;Text;Contains;" + txtRecipientName.Text.Trim());
                            }
                            if (txtAssignedTo.Text != "Assigned To" && txtAssignedTo.Text.Length > 0)
                            {
                                objColumns.Add("AssignedTo;Text;Contains;" + txtAssignedTo.Text.Trim());
                            }
                            if (txtResult.Text != "Result" && txtResult.Text.Length > 0)
                            {
                                objColumns.Add("Result;Text;Contains;" + txtResult.Text.Trim());
                            }
                            if (txtDateIn.Text != "Date In" && txtDateIn.Text.Length > 0)
                            {
                                objColumns.Add("DateIn;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateIn.Text).Date));
                            }
                            if (txtDateOut.Text != "Date Out" && txtDateOut.Text.Length > 0)
                            {
                                objColumns.Add("DateOut;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtDateOut.Text).Date));
                            }
                            if ((txtFirstDateOfService.Text != "DOS From" && txtFirstDateOfService.Text.Length > 0) && (txtLastDateOfService.Text != "DOS To" && txtLastDateOfService.Text.Length > 0))
                            {
                                objColumns.Add("FirstDateofService;DateTime;Geq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtFirstDateOfService.Text).Date));
                                objColumns.Add("LastDateofService;DateTime;Leq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtLastDateOfService.Text).Date));
                            }
                            else
                            {
                                if (txtFirstDateOfService.Text != "DOS From" && txtFirstDateOfService.Text.Length > 0)
                                {
                                    objColumns.Add("FirstDateofService;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtFirstDateOfService.Text).Date));
                                }
                                if (txtLastDateOfService.Text != "DOS To" && txtLastDateOfService.Text.Length > 0)
                                {
                                    objColumns.Add("LastDateofService;DateTime;Eq;" + SPUtility.CreateISO8601DateTimeFromSystemDateTime(Convert.ToDateTime(txtLastDateOfService.Text).Date));
                                }
                            }
                            if (objColumns.Count > 0)
                            {
                                query.Query = CreateCAMLQuery(objColumns, "And", true);
                            }
                            else
                            {
                                //query.Query = "<OrderBy><FieldRef Name='CREATED' Ascending='FALSE'/></OrderBy>";

                                query.Query = strQuery +
                                             "<OrderBy>" +
                                                "<FieldRef Name='Created' Ascending='FALSE'/>" +
                                             "</OrderBy>";
                            }

                            query.ViewFields = string.Concat(
                                        "<FieldRef Name='Title' />",
                                        "<FieldRef Name='Provider' />",
                                        "<FieldRef Name='ReceipientName' />",
                                        "<FieldRef Name='DateIn' />",
                                        "<FieldRef Name='DateOut' />",
                                        "<FieldRef Name='Created' />",
                                        "<FieldRef Name='AssignedTo' />",
                                        "<FieldRef Name='FirstDateofService' />",
                                        "<FieldRef Name='LastDateofService' />",
                                        "<FieldRef Name='Result' />");
                            SPListItemCollection listColl = CRLogList.GetItems(query);
                            Int32 CRLListCount = listColl.Count;
                            if (listColl != null && CRLListCount > 0)
                            {
                                dropdownPageSize = Convert.ToInt32(ddlRowCount.SelectedValue);
                                Int32 totalPages = CRLListCount / Convert.ToInt32(dropdownPageSize);
                                totalPages = ((totalPages * Convert.ToInt32(dropdownPageSize)) == CRLListCount) ? totalPages : (totalPages + 1);

                                if (paging == null)
                                {
                                    ViewState["pageindex"] = 0;
                                }
                                if (paging == "next")
                                {
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex >= 0)
                                    {
                                        pageIndex = ((pageIndex++) + dropdownPageSize);
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (paging == "prev")
                                {
                                    btnNext.Enabled = true;
                                    pageIndex = Convert.ToInt32(ViewState["pageindex"]);
                                    if (pageIndex > 0)
                                    {
                                        pageIndex = pageIndex - dropdownPageSize;
                                    }
                                    ViewState["pageindex"] = pageIndex;
                                }
                                if (CRLListCount > dropdownPageSize)
                                {
                                    btnNext.Visible = true;
                                    btnPrevious.Visible = true;
                                    btnPrevious.Enabled = false;
                                }
                                if ((paging == null) || (paging == "prev" && pageIndex == 0))
                                {
                                    btnPrevious.Enabled = false;
                                    btnNext.Enabled = true;
                                }
                                else
                                {
                                    btnPrevious.Enabled = true;
                                }
                                if (paging == "next" && (pageIndex + dropdownPageSize) == totalPages * dropdownPageSize)
                                {
                                    btnNext.Enabled = false;
                                    btnNext.ForeColor = System.Drawing.Color.Gray;
                                    btnPrevious.Enabled = true;
                                }
                                if (totalPages == 1)
                                {
                                    btnPrevious.Enabled = false;
                                    btnPrevious.ForeColor = System.Drawing.Color.Black;
                                    btnNext.Enabled = false;
                                }
                                IEnumerable<SPListItem> scanListCollection = listColl.Cast<SPListItem>();
                                //lblRecordCount.Text = Convert.ToString(scanListCollection.Count());
                                if (searchString == "load")
                                {
                                    scanListCollection = scanListCollection.Where(s => Convert.ToDateTime(s["Created"]) >= DateTime.Today).Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));
                                }
                                else
                                {
                                    scanListCollection = scanListCollection.Skip(pageIndex).Take(Convert.ToInt32(dropdownPageSize));
                                }

                                foreach (SPListItem item in scanListCollection)
                                {
                                    searchEntity.Add(new CRLSearchEntity
                                    {
                                        //ID = Convert.ToInt32(item["ID"]),
                                        Title = Convert.ToString(item["Title"]),
                                        AssignedTo = Convert.ToString(item["AssignedTo"]),
                                        Provider = Convert.ToString(item["Provider"]),
                                        ReceipientName = Convert.ToString(item["ReceipientName"]),
                                        //Recipient = Convert.ToString(item["Recipient"]),
                                        DateIn = Convert.ToDateTime(item["DateIn"]),
                                        DateOut = Convert.ToDateTime(item["DateOut"]),
                                        FirstDateofService = Convert.ToDateTime(item["FirstDateofService"]),
                                        LastDateofService = Convert.ToDateTime(item["LastDateofService"]),
                                        Result = Convert.ToString(item["Result"])
                                    });
                                }
                                ViewState["pageSort"] = searchString;
                            }
                            else
                            {
                                grvCRLDailyView.DataSource = null;
                                grvCRLDailyView.DataBind();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                lblErrorMsg.Text = "Enter a valid date";
            }
            return searchEntity;
        }
        public static string CreateCAMLQuery(List<string> parameters, string orAndCondition, bool isIncludeWhereClause)
        {
            StringBuilder sb = new StringBuilder();

            if (parameters.Count == 0)
            {
                AppendEQ(sb, "all");
            }

            int j = 0;
            for (int i = 0; i < parameters.Count; i++)
            {
                if (!string.IsNullOrEmpty(parameters[i].Split(';')[3]))
                {
                    AppendEQ(sb, parameters[i]);

                    if (i > 0 && j > 0)
                    {
                        sb.Insert(0, "<" + orAndCondition + ">");
                        sb.Append("</" + orAndCondition + ">");
                    }
                    j++;
                }
            }
            if (isIncludeWhereClause)
            {
                sb.Insert(0, "<Where>");
                sb.Append("</Where><OrderBy><FieldRef Name='ID' Ascending='FALSE'/></OrderBy>");
            }
            return sb.ToString();
        }

        public static void AppendEQ(StringBuilder sb, string value)
        {
            string[] field = value.Split(';');

            sb.AppendFormat("<{0}>", field[2].ToString());
            sb.AppendFormat("<FieldRef Name='{0}'/>", field[0].ToString());
            sb.AppendFormat("<Value Type='{0}' IncludeTimeValue='False'>{1}</Value>", field[1].ToString(), field[3].ToString());
            sb.AppendFormat("</{0}>", field[2].ToString());
        }

        public void clearLogdetails()
        {
            txtAssignedTo.Text = string.Empty;
            txtDateIn.Text = string.Empty;
            txtDateOut.Text = string.Empty;
            txtFirstDateOfService.Text = string.Empty;
            txtLastDateOfService.Text = string.Empty;
            txtResult.Text = string.Empty;
            txtProvider.Text = string.Empty;
            txtRecipientName.Text = string.Empty;
            Page.Response.Redirect(siteUrl + "/SitePages/Customer Review Log Search.aspx");
        }

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            //GetYearlyCRLItems();
            grvCRLDailyView.DataSource = GetYearlyCRLItems(null, "search");
            grvCRLDailyView.DataBind();
        }

        protected void btnClear_Click(object sender, EventArgs e)
        {
            clearLogdetails();
        }

        protected void grvCRLDailyView_Sorting(object sender, GridViewSortEventArgs e)
        {
            SortColumn(e.SortExpression);
        }

        private string GetSortDirection(string column)
        {
            string sortDirection = "ASC";
            string sortExpression = ViewState["SortExpression"] as string;

            if (sortExpression != null)
            {
                if (sortExpression == column)
                {
                    string lastDirection = ViewState["SortDirection"] as string;
                    if ((lastDirection != null) && (lastDirection == "ASC"))
                    {
                        sortDirection = "DESC";
                    }
                }
            }

            ViewState["SortDirection"] = sortDirection;
            ViewState["SortExpression"] = column;

            return sortDirection;
        }

        public void SortColumn(String sortExpression)
        {
            String sortSearchString = String.Empty;
            if (Convert.ToString(ViewState["pageSort"]) == "load")
            {
                sortSearchString = "load";
            }
            else
            {
                sortSearchString = "search";
            }
            List<CRLSearchEntity> CRLSearchEntityList = GetYearlyCRLItems(null, sortSearchString);
            String sortDirection = GetSortDirection(sortExpression);
            switch (sortExpression)
            {
                case "Provider":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.Provider).ToList() : CRLSearchEntityList.OrderByDescending(x => x.Provider).ToList();
                    break;
                case "ReceipientName":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.ReceipientName).ToList() : CRLSearchEntityList.OrderByDescending(x => x.ReceipientName).ToList();
                    break;
                case "AssignedTo":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.AssignedTo).ToList() : CRLSearchEntityList.OrderByDescending(x => x.AssignedTo).ToList();
                    break;
                case "DateIn":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.DateIn).ToList() : CRLSearchEntityList.OrderByDescending(x => x.DateIn).ToList();
                    break;
                case "DateOut":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.DateOut).ToList() : CRLSearchEntityList.OrderByDescending(x => x.DateOut).ToList();
                    break;
                case "FirstDateofService":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.FirstDateofService).ToList() : CRLSearchEntityList.OrderByDescending(x => x.FirstDateofService).ToList();
                    break;
                case "LastDateofService":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.LastDateofService).ToList() : CRLSearchEntityList.OrderByDescending(x => x.LastDateofService).ToList();
                    break;
                case "Result":
                    grvCRLDailyView.DataSource = (sortDirection == "ASC") ? CRLSearchEntityList.OrderBy(x => x.Result).ToList() : CRLSearchEntityList.OrderByDescending(x => x.Result).ToList();
                    break;
            }
            grvCRLDailyView.DataBind();
        }

        public string ProcessDateTime(object value)
        {
            if (Convert.ToString(value) == "1/1/0001")
            {
                value = String.Empty;
            }

            return Convert.ToString(value);
        }

        protected void btnPrevious_Click(object sender, EventArgs e)
        {
            grvCRLDailyView.DataSource = GetYearlyCRLItems("prev", "prev");
            grvCRLDailyView.DataBind();
        }

        protected void btnNext_Click(object sender, EventArgs e)
        {
            grvCRLDailyView.DataSource = GetYearlyCRLItems("next", "next");
            grvCRLDailyView.DataBind();
        }

        //[WebMethod]
        //public string test()
        //{
        //    txtAssignedTo.Text = "test";
        //    return "test";
        //}
    }
}
