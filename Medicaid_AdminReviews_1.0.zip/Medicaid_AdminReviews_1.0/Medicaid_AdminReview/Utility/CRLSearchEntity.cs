﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;

namespace Medicaid_AdminReview.Utility
{
    public class CRLSearchEntity
    {
        public string Title { get; set; }
        public string Provider { get; set; }
        public string ReceipientName { get; set; }
        public string AssignedTo { get; set; }
        public string Recipient { get; set; }
        public DateTime DateIn { get; set; }
        public DateTime DateOut { get; set; }
        public DateTime FirstDateofService { get; set; }
        public DateTime LastDateofService { get; set; }
        public string Result { get; set; }
        
    }
}
